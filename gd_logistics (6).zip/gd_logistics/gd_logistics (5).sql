-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2023 at 06:12 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gd_logistics`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login_details`
--

CREATE TABLE `admin_login_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf32_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `aadhar_no` bigint(20) DEFAULT NULL,
  `blood_group` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `date_of_birth` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `staff_type` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `designation` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `experience_year` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `phone_no` bigint(20) DEFAULT NULL,
  `alternate_phone_no` bigint(20) DEFAULT NULL,
  `email` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `alternate_email` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `medical_history` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `city_id` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `state_id` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `pin_code` bigint(20) DEFAULT NULL,
  `profile_pic` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf32_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf32_unicode_ci NOT NULL,
  `user_role` varchar(255) COLLATE utf32_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `admin_login_details`
--

INSERT INTO `admin_login_details` (`id`, `user_id`, `first_name`, `middle_name`, `last_name`, `gender`, `aadhar_no`, `blood_group`, `date_of_birth`, `staff_type`, `role`, `designation`, `experience_year`, `phone_no`, `alternate_phone_no`, `email`, `alternate_email`, `medical_history`, `address`, `city_id`, `state_id`, `pin_code`, `profile_pic`, `username`, `password`, `user_role`, `created_at`, `updated_at`) VALUES
(1, 10000, 'GD', 'xyz', 'Logistics', 'Male', 264151414147, 'AB+', '2008-01-05', 'Mangment', 'admin', '1', '5', 8956231111, 9895212555, 'admin@gmail.com', 'adminxyz@gmail.com', 'xyz', 'abc', 'Nagpur', 'Maharashtra', 440001, '10000profile_pic_446936.jpg', 'GD Logistics', '$2a$04$/PQ5GlhowMBFd7TbPV74YucAEOB6wJB9xbL8CGQnddAKlyTzCQ3/y', 'admin', '2021-12-02 08:28:56', '2022-11-29 14:37:43');

-- --------------------------------------------------------

--
-- Table structure for table `bilti_details`
--

CREATE TABLE `bilti_details` (
  `id` int(11) NOT NULL,
  `load_type` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `insurance_company` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `from_bilti` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `policy_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `to_bilti` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `tbb_for` varchar(100) COLLATE utf32_unicode_ci DEFAULT NULL,
  `consignor_company_name` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `consignor_gst_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `consignor_phone_no` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `consignor_policy_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `consignor_policy_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `policy_file` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `consignee_company_name` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `consignee_gst_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `consignee_phone_no` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `packages` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `packing_type` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `e_way_bill_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `invoice_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `declared_value` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `valid_upto` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `lorry_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `description` text CHARACTER SET latin1 DEFAULT NULL,
  `actual_wt` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `charge_wt` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `vs_code` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `con_date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `con_pan_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `con_gst_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `freight` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `rate_one` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `amount_one` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `door_delivery` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `rate_two` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `amount_two` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `local_collection` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `rate_three` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `amount_three` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `lr_charge` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `rate_four` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `amount_four` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `sub_charge` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `rate_five` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `amount_five` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `gst_charge` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `rate_six` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `amount_six` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `grand_total` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `grand_rate` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `grand_amount` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `amount_in_word` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `basis_of_bkg` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `gst_pay` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `for_acknowledment` text CHARACTER SET latin1 DEFAULT NULL,
  `con_status` int(2) NOT NULL DEFAULT 0,
  `from_address` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `to_address` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `kh_address` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `copy_type` varchar(100) COLLATE utf32_unicode_ci DEFAULT NULL,
  `door_dilivery` varchar(100) COLLATE utf32_unicode_ci DEFAULT NULL,
  `consignment_copy` varchar(100) COLLATE utf32_unicode_ci DEFAULT NULL,
  `to_addr` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `from_address_indore` varchar(100) COLLATE utf32_unicode_ci DEFAULT NULL,
  `from_addr` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `e_way_bill_no_two` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `e_way_bill_no_three` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `consignor_address` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `consignee_address` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `created_mili_second` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `bilti_details`
--

INSERT INTO `bilti_details` (`id`, `load_type`, `insurance_company`, `from_bilti`, `policy_no`, `to_bilti`, `tbb_for`, `consignor_company_name`, `consignor_gst_no`, `consignor_phone_no`, `consignor_policy_name`, `consignor_policy_no`, `policy_file`, `consignee_company_name`, `consignee_gst_no`, `consignee_phone_no`, `packages`, `packing_type`, `e_way_bill_no`, `invoice_no`, `declared_value`, `valid_upto`, `lorry_no`, `description`, `actual_wt`, `charge_wt`, `vs_code`, `con_date`, `con_pan_no`, `con_gst_no`, `freight`, `rate_one`, `amount_one`, `door_delivery`, `rate_two`, `amount_two`, `local_collection`, `rate_three`, `amount_three`, `lr_charge`, `rate_four`, `amount_four`, `sub_charge`, `rate_five`, `amount_five`, `gst_charge`, `rate_six`, `amount_six`, `grand_total`, `grand_rate`, `grand_amount`, `amount_in_word`, `basis_of_bkg`, `gst_pay`, `for_acknowledment`, `con_status`, `from_address`, `to_address`, `kh_address`, `copy_type`, `door_dilivery`, `consignment_copy`, `to_addr`, `from_address_indore`, `from_addr`, `e_way_bill_no_two`, `e_way_bill_no_three`, `consignor_address`, `consignee_address`, `is_deleted`, `created_at`, `updated_at`, `created_mili_second`) VALUES
(1, '', '', 'Nagpur', '', '', 'Consignor', '1', 'GFDSHSHBVFDHGBF', '7889632445', NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', NULL, '', '', '50012', '2023-03-14', 'AAKCG1444K', 'U60210MH2022PTC393571', 'Freight', '0', '0', 'Door Delivery', NULL, '0', 'Local Collection', NULL, '0', 'LR Charge', NULL, '0', 'Sub Charge', NULL, '0', 'GST Charge', NULL, '0', 'Grand Total', NULL, '', NULL, NULL, NULL, ' szdfgh', 0, 'Guru Drashti Logistics Pvt.Ltd. Nagpur', 'Door Delivery', 'Consignment Copy Attached', 'Lorry Copy', '', '', 'Godown Delivery', '32, Tiware complex, TT Nager, Near Kataria Complex, Ring Road, Dewas Naka, Indore- 455001', 'Without Consginment Copy Attached', '', '', 'hf', '', 0, '2023-03-14 12:20:14', '2023-04-21 08:54:03', 1678732200),
(2, '', '', 'Select', '', '', NULL, '2', 'GFDSHSHBVFDHGBF', '5555555555', NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', '2023-03-14', 'AAKCG1444K', 'U60210MH2022PTC393571', 'Freight', '0', '0', 'Door Delivery', NULL, '0', 'Local Collection', NULL, '0', 'LR Charge', NULL, '0', 'Sub Charge', NULL, '0', 'GST Charge', NULL, '0', 'Grand Total', NULL, '', NULL, NULL, NULL, ' ', 0, 'Guru Drashti Logistics Pvt.Ltd. Nagpur', 'Door Delivery', 'Consignment Copy Attached', '', 'Select', 'Select', 'Godown Delivery', '32, Tiware complex, TT Nager, Near Kataria Complex, Ring Road, Dewas Naka, Indore- 455001', 'Without Consginment Copy Attached', '', '', 'sdf', '', 0, '2023-03-14 12:21:55', NULL, 1678732200);

-- --------------------------------------------------------

--
-- Table structure for table `consignment_update_details`
--

CREATE TABLE `consignment_update_details` (
  `id` int(11) NOT NULL,
  `ee_id` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `consignment_date` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `vs_code` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `consignment_time` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `consignment_status` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `status` int(2) NOT NULL DEFAULT 0,
  `consignment_from` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `consignment_to` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `lorry_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_details`
--

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL,
  `invoice_pan_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `invoice_gst` varchar(255) CHARACTER SET latin1 NOT NULL,
  `address` varchar(255) CHARACTER SET latin1 NOT NULL,
  `bill_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `bill_date` varchar(255) CHARACTER SET latin1 NOT NULL,
  `invoice_bill_date` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `owner_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `customer_address` varchar(255) CHARACTER SET latin1 NOT NULL,
  `gst_no` varchar(255) NOT NULL,
  `booking_station` varchar(255) CHARACTER SET latin1 NOT NULL,
  `vs_code` varchar(255) CHARACTER SET latin1 NOT NULL,
  `consignment_date` varchar(255) CHARACTER SET latin1 NOT NULL,
  `destination` varchar(255) CHARACTER SET latin1 NOT NULL,
  `truck_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `charge_weight_mt` varchar(255) CHARACTER SET latin1 NOT NULL,
  `rate` varchar(255) CHARACTER SET latin1 NOT NULL,
  `invoice_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `freight_amount` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_nopad_ci NOT NULL,
  `unloading_charge` varchar(255) CHARACTER SET latin1 NOT NULL,
  `total_amount` varchar(255) CHARACTER SET latin1 NOT NULL,
  `in_words` varchar(255) CHARACTER SET latin1 NOT NULL,
  `payment_status` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `cgst_igst` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `cgst_igst_amount` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `sgst` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `sgst_amount` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `all_total_amount` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `gst_amount` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `detention` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `two_total_amount` varchar(100) DEFAULT NULL,
  `other_charge` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `tbb_for` varchar(255) DEFAULT NULL,
  `booking_address_nagpur` varchar(100) DEFAULT NULL,
  `booking_address_indore` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `is_deleted` int(2) NOT NULL DEFAULT 0,
  `created_mili_second` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoice_details`
--

INSERT INTO `invoice_details` (`id`, `invoice_pan_no`, `invoice_gst`, `address`, `bill_no`, `bill_date`, `invoice_bill_date`, `owner_name`, `customer_address`, `gst_no`, `booking_station`, `vs_code`, `consignment_date`, `destination`, `truck_no`, `charge_weight_mt`, `rate`, `invoice_no`, `freight_amount`, `unloading_charge`, `total_amount`, `in_words`, `payment_status`, `cgst_igst`, `cgst_igst_amount`, `sgst`, `sgst_amount`, `all_total_amount`, `gst_amount`, `detention`, `remarks`, `two_total_amount`, `other_charge`, `tbb_for`, `booking_address_nagpur`, `booking_address_indore`, `created_at`, `updated_at`, `is_deleted`, `created_mili_second`) VALUES
(1, '', '', '', '75001', '', '2023-04-21', '1', 'hf', 'GFDSHSHBVFDHGBF', 'Nagpur', '50012', '2023-03-14', '', '', '', '0', '', '0', '0', '', '', 'Unpaid', '2.5', '', '2.5', '', NULL, '', '0', '', 'NaN', '0', 'Consignor', 'Guru Drashti Logistics Pvt.Ltd. Nagpur', '32, Tiware complex, TT Nager, Near Kataria Complex, Ring Road, Dewas Naka, Indore- 455001', '2023-04-21 09:27:05', NULL, 0, 1682015400);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_dynamic_details`
--

CREATE TABLE `invoice_dynamic_details` (
  `id` int(11) NOT NULL,
  `invoice_id` int(2) DEFAULT NULL,
  `booking_station_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `vs_code_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `consignment_date_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `destination_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `truck_no_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `charge_weight_mt_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `rate_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `invoice_no_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `freight_amount_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `unloading_charge_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `total_amount_one` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `is_deleted` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lorry_challan_details`
--

CREATE TABLE `lorry_challan_details` (
  `id` int(11) NOT NULL,
  `lorry_hire_contact_no` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `lorry_hire_date` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `from_lorry` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `to_lorry` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `lorry_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `challan_no` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `vs_code` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `package` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `actual_weight` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `charge_weight` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `owner_details` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `driver_details` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `broker_details` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `rate_per_ton` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `hire_charge_wt` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `cash_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `cheque_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `cheque_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `advance_date` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `final_rate_per_ton` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `final_rate_charge_wt` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `payment_cash_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `payment_cheque_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `payment_cheque_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `payment_date` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `lorry_hire` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `lorry_amount_rs` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `other_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `other_amount_rs` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `total_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `total_amount_rs` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `adv_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `adv_amount_rs` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `net_balance` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `net_balance_rs` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `balance_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `ab_balance_rs` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `ab_other_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `ab_total_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `deduction` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `deduction_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `deduction_net_balance` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `net_deduction_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `rc` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `enclose_insurance` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `permit` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `pan` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `driver_lic` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `owner_name` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `owner_mobile_no` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `owner_alt_mobile_no` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `owner_address` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `broker_name` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `broker_mobile_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `broker_alt_mobile_no` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `broker_address` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `driver_name` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `driver_mobile_no` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `driver_alt_mobile_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `driver_address` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `mode_of_payment` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `mode_of_payment_one` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `tds` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `shortage` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `damage` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `damage_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `qq_total_amount` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `lorry_type` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `created_mili_second` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `lorry_challan_details`
--

INSERT INTO `lorry_challan_details` (`id`, `lorry_hire_contact_no`, `lorry_hire_date`, `from_lorry`, `to_lorry`, `lorry_no`, `challan_no`, `vs_code`, `package`, `actual_weight`, `charge_weight`, `owner_details`, `driver_details`, `broker_details`, `rate_per_ton`, `hire_charge_wt`, `cash_amount`, `cheque_amount`, `cheque_no`, `advance_date`, `final_rate_per_ton`, `final_rate_charge_wt`, `payment_cash_amount`, `payment_cheque_amount`, `payment_cheque_no`, `payment_date`, `lorry_hire`, `lorry_amount_rs`, `other_amount`, `other_amount_rs`, `total_amount`, `total_amount_rs`, `adv_amount`, `adv_amount_rs`, `net_balance`, `net_balance_rs`, `balance_amount`, `ab_balance_rs`, `ab_other_amount`, `ab_total_amount`, `deduction`, `deduction_amount`, `deduction_net_balance`, `net_deduction_amount`, `rc`, `enclose_insurance`, `permit`, `pan`, `driver_lic`, `owner_name`, `owner_mobile_no`, `owner_alt_mobile_no`, `owner_address`, `broker_name`, `broker_mobile_no`, `broker_alt_mobile_no`, `broker_address`, `driver_name`, `driver_mobile_no`, `driver_alt_mobile_no`, `driver_address`, `mode_of_payment`, `mode_of_payment_one`, `tds`, `shortage`, `damage`, `damage_amount`, `qq_total_amount`, `lorry_type`, `is_deleted`, `created_at`, `updated_at`, `created_mili_second`) VALUES
(1, '60003', '2023-03-20', 'nagpur', 'delhi', 'MH40', 'dsf', '50001', '30', '11', '22', NULL, NULL, NULL, '14', '25', '100', '20', '300', '', NULL, NULL, '', '0', '', NULL, 'Lorry Hire', '350', 'Other Amount', '10', 'Total Amount', '350', 'Adv. Amount', '120', 'Net Balance', '230', NULL, NULL, '0', NULL, 'Deduction', '', 'Net Balance', '', 'nn', 'hh', 'jj', 'nn', 'uu', 'khushbu', '4444444444', '5555555555', 'dttdyt', '', '8888888888', '7777777777', 'hdtyfu', 'ee', '5555555555', '2222222222', 'www', NULL, NULL, '0', '0', '0', '', '', 'Advance', 0, '2023-03-20 07:27:40', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `m_broker_details`
--

CREATE TABLE `m_broker_details` (
  `id` int(11) NOT NULL,
  `broker_code` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `broker_name` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `state_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `mobile_no` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `alt_mobile_no` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `contact_person` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `lorry_type` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `bank_name` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `account_no` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `ifsc_code` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `m_consignee_details`
--

CREATE TABLE `m_consignee_details` (
  `id` int(11) NOT NULL,
  `customer_code` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `company_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `mobile_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `contact_person` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `owner_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `gst_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `email_id` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `alternate_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `m_consignor_details`
--

CREATE TABLE `m_consignor_details` (
  `id` int(11) NOT NULL,
  `customer_code` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `contact_person` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `owner_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `gst_no` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `email_id` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `alternate_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `m_consignor_details`
--

INSERT INTO `m_consignor_details` (`id`, `customer_code`, `customer_name`, `mobile_no`, `contact_person`, `owner_name`, `gst_no`, `email_id`, `address`, `alternate_no`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, '11', 'khushbu', '7889632445', 'priyanka', 'khushbu', 'GFDSHSHBVFDHGBF', 'amika@gmail.com', 'hf', '5555555555', 0, '2023-03-14 12:19:47', NULL),
(2, '12', 'priyanka', '5555555555', '5555555555', 'khushbu', 'GFDSHSHBVFDHGBF', 'sakshi@gmsil.com', 'sdf', '7896321545', 0, '2023-03-14 12:21:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `m_lorry_owner_details`
--

CREATE TABLE `m_lorry_owner_details` (
  `id` int(11) NOT NULL,
  `lorry_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `chesis_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `insurance_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `expiry_date` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `fitness_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `insurance_pdf` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `engine_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `fitnes_pdf` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `fitness_expire_date` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `owner_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `owner_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `alternate_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `address` text CHARACTER SET latin1 DEFAULT NULL,
  `pan_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `pancard_pdf` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `aadhar_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `aadhar_pdf` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `rc` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `permit` varchar(100) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `id` int(11) NOT NULL,
  `invoice_id` varchar(200) CHARACTER SET latin1 DEFAULT NULL,
  `mode_of_payment` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `date` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `amount` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `cheque_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `bank_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `transaction_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `created_mili_second` varchar(255) COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_receipt_details`
--

CREATE TABLE `payment_receipt_details` (
  `id` int(11) NOT NULL,
  `receipt_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `receipt_date` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `receipt_type` varchar(100) DEFAULT NULL,
  `owner_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `customer_address` varchar(255) DEFAULT NULL,
  `gst_no` varchar(255) DEFAULT NULL,
  `ttb_for` varchar(255) DEFAULT NULL,
  `from_payment_receipt` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `to_payment_receipt` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `vs_code` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `party_date` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `wt` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `package` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `bill_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `bill_date` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `payment_type` varchar(100) DEFAULT NULL,
  `payment_rs_one` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `payment_rs_two` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `payment_rs_three` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `payment_rs_four` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `payment_rs_five` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `payment_rs_six` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `date` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `amount` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `cheque` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `bank_name` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `transaction_no` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `cash` varchar(100) DEFAULT NULL,
  `rtgs` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `mode_of_payment` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `bb_date` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_mili_second` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment_receipt_details`
--

INSERT INTO `payment_receipt_details` (`id`, `receipt_no`, `receipt_date`, `receipt_type`, `owner_name`, `customer_address`, `gst_no`, `ttb_for`, `from_payment_receipt`, `to_payment_receipt`, `vs_code`, `party_date`, `wt`, `package`, `bill_no`, `bill_date`, `payment_type`, `payment_rs_one`, `payment_rs_two`, `payment_rs_three`, `payment_rs_four`, `payment_rs_five`, `payment_rs_six`, `date`, `amount`, `cheque`, `bank_name`, `transaction_no`, `cash`, `rtgs`, `mode_of_payment`, `bb_date`, `is_deleted`, `created_at`, `created_mili_second`, `updated_at`) VALUES
(1, '40001', '2023-04-25', '', '1', 'hf', 'GFDSHSHBVFDHGBF', NULL, 'Nagpur', '', '50012', NULL, '', '', '', '', '', '0', '0', '0', '', '0', '', NULL, NULL, '', '', NULL, '', '', NULL, '', 0, '2023-04-25 07:17:38', '1682361000', NULL),
(2, '40002', '2023-04-25', '', '1', 'hf', 'GFDSHSHBVFDHGBF', NULL, 'Nagpur', '', '50012', NULL, '', '', '', '', '', '0', '0', '0', '', '0', '', NULL, NULL, '', '', NULL, '', '', NULL, '', 0, '2023-04-25 07:18:45', '1682361000', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `settings_details`
--

CREATE TABLE `settings_details` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `pan_no` varchar(10) COLLATE utf32_unicode_ci DEFAULT NULL,
  `gst_no` varchar(15) COLLATE utf32_unicode_ci DEFAULT NULL,
  `cin_no` varchar(21) COLLATE utf32_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `settings_details`
--

INSERT INTO `settings_details` (`id`, `company_name`, `email`, `mobile_no`, `pan_no`, `gst_no`, `cin_no`, `address`, `website`, `logo`, `updated_at`) VALUES
(1, 'Guru Drashti Logistics Private Limited', 'ngp@gdlogistics.in', '9399319239', 'BCTPB7019L', '44DDDDD4444K444', '444444444444444444444', 'Plot No 11, Shivaji Nagar, Hingna Road, Waddhamana, Nagpur- 440023', 'www.gdlogistics.in', '1logo_861170.jpg', '2023-03-13 09:17:02');

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `id` int(11) NOT NULL,
  `staff_id` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `middle_name` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `aadhar_no` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf32_unicode_ci DEFAULT NULL,
  `alternate_mobile_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `pan_no` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `permnant_address` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `profile_pic` varchar(255) COLLATE utf32_unicode_ci DEFAULT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `name`, `is_deleted`) VALUES
(1, 'Andaman & Nicobar Islands', 0),
(2, 'Andhra Pradesh', 0),
(3, 'Arunachal Pradesh', 0),
(4, 'Assam', 0),
(5, 'Bihar', 0),
(6, 'Chandigarh', 0),
(7, 'Chhattisgarh', 0),
(8, 'Dadra & Nagar Haveli', 0),
(9, 'Daman & Diu', 0),
(10, 'Delhi', 0),
(11, 'Goa', 0),
(12, 'Gujarat', 0),
(13, 'Haryana', 0),
(14, 'Himachal Pradesh', 0),
(15, 'Jammu & Kashmir', 0),
(16, 'Jharkhand', 0),
(17, 'Karnataka', 0),
(18, 'Kerala', 0),
(19, 'Lakshadweep', 0),
(20, 'Madhya Pradesh', 0),
(21, 'Maharashtra', 0),
(22, 'Manipur', 0),
(23, 'Meghalaya', 0),
(24, 'Mizoram', 0),
(25, 'Nagaland', 0),
(26, 'Odisha', 0),
(27, 'Puducherry', 0),
(28, 'Punjab', 0),
(29, 'Rajasthan', 0),
(30, 'Sikkim', 0),
(31, 'Tamil Nadu', 0),
(32, 'Tripura', 0),
(33, 'Uttar Pradesh', 0),
(34, 'Uttarakhand', 0),
(35, 'West Bengal', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `first_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `last_name` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `username` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `user_role` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `is_deleted` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `first_name`, `last_name`, `email`, `username`, `password`, `user_role`, `is_deleted`) VALUES
(1, '10000', 'GD', 'Logistics', NULL, '9399319239', '$2a$04$N400caiDW3R.nTHPKEipS.b9r5zxIIxykPFcV9y051OMGNyfGYTma', 'admin', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login_details`
--
ALTER TABLE `admin_login_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bilti_details`
--
ALTER TABLE `bilti_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `consignment_update_details`
--
ALTER TABLE `consignment_update_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_dynamic_details`
--
ALTER TABLE `invoice_dynamic_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lorry_challan_details`
--
ALTER TABLE `lorry_challan_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_broker_details`
--
ALTER TABLE `m_broker_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_consignee_details`
--
ALTER TABLE `m_consignee_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_consignor_details`
--
ALTER TABLE `m_consignor_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_lorry_owner_details`
--
ALTER TABLE `m_lorry_owner_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_receipt_details`
--
ALTER TABLE `payment_receipt_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings_details`
--
ALTER TABLE `settings_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_details`
--
ALTER TABLE `staff_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login_details`
--
ALTER TABLE `admin_login_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bilti_details`
--
ALTER TABLE `bilti_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `consignment_update_details`
--
ALTER TABLE `consignment_update_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoice_details`
--
ALTER TABLE `invoice_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `invoice_dynamic_details`
--
ALTER TABLE `invoice_dynamic_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lorry_challan_details`
--
ALTER TABLE `lorry_challan_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `m_broker_details`
--
ALTER TABLE `m_broker_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `m_consignee_details`
--
ALTER TABLE `m_consignee_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `m_consignor_details`
--
ALTER TABLE `m_consignor_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `m_lorry_owner_details`
--
ALTER TABLE `m_lorry_owner_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_details`
--
ALTER TABLE `payment_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_receipt_details`
--
ALTER TABLE `payment_receipt_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings_details`
--
ALTER TABLE `settings_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `staff_details`
--
ALTER TABLE `staff_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
