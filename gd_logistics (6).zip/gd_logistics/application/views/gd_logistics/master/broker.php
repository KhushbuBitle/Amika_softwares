<div class="content-wrapper">
   <div class="container-xxl flex-grow-1 container-p-y">
      <?php if(!empty($this->session->flashdata('success_message'))){ ?>
      <div class="row mt-3">
         <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
            <div class="alert alert-success alert-dismissible">
               <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
            </div>      
         </div> 
      </div>
      <?php } ?> 
      <div class="card">
         <div class="card-header">
            <div class="row">
               <div class="col-md-8 col-sm-8 col-xs-8 col-lg-8">
                  <h5>Broker List</h5>
               </div>
               <div class="col-sm-4">
               <a href="" class="btn btn-primary btn-md doctor_btn" data-bs-target="#modaltop_one" role="button" data-bs-toggle="modal" style="margin-left:85px;">Add Broker</a>
               </div>
            </div>
         </div> 
         <hr>
         <div class="table-responsive text-nowrap"> 
            <table class="table datatableid"> 
               <thead>
                  <tr>
                     <th>SR NO.</th>
                     <th>BROKER NAME</th>
                     <th>STATE NAME</th>
                     <th>ACTION</th> 
                  </tr>
               </thead>  
               <tbody>
                        <?php
                        if (!empty($info)) {
                           $i = 1;
                           foreach ($info as $key) { ?>  
                              <tr>

                                 <td><?php echo $i; ?></td>
                                 <td><?php echo $key->broker_name; ?></td>  
                                 <td>
                                    <?php $demo = $key->state_name; 
                                    //$demo;

                                    //$demo_one = explode('_',$demo);
                                    //$demo_one is [0] = 1, [1] = '', [2] = 2

                                    $demo_one = explode(',', $demo);
                                    $demo_oned = array();
                                    for ($i = 0; $i < count($demo_one); $i++) {
                                       $demo_one[$i] =  trim($demo_one[$i], "_");
                                       foreach ($state as $rowv) {
                                          if($rowv['id'] ==  $demo_one[$i])
                                          {
                                             $demo_oned[$i] = $rowv['name'];
                                          }
                                       }
                                    }
                                    //$demo_one is [0] = 1, [1] = 2

                                    $a = implode(",", $demo_one); 
                                    $a1 = implode(",", $demo_oned);
                                    echo $a1;
                                    ?>

                                 </td>    
                                 <td>   
                                 
                          
                                    <a href=" " role="button" class="btn btn-sm rounded-pill btn-info" data-bs-target="#modaltop" onclick="get_area('<?php echo $key->broker_code; ?>', '<?php echo $a; ?>','<?php echo $key->broker_name; ?>','<?php echo $key->mobile_no;?>','<?php echo $key->alt_mobile_no; ?>','<?php echo $key->contact_person; ?>','<?php echo $key->lorry_type; ?>','<?php echo $key->address; ?>','<?php echo $key->bank_name; ?>','<?php echo $key->account_no; ?>','<?php echo $key->ifsc_code; ?>', '<?php echo $key->id; ?>','m_broker_details')" data-bs-toggle="modal"><i class="bx bx-edit-alt me-2"></i></a>
                                    <a href=" " role="button" class="btn btn-sm rounded-pill btn-danger" onclick="delete_broker('<?php echo $key->id;?>','m_broker_details')" data-bs-toggle="modal"><i class="bx bx-trash me-2"></i></a>
                                   
                      
                                 </td>   
                              </tr>
                           <?php $i++; 
                           }
                        } else { ?>
                           <tr>
                              <td colspan="4" class="text-center text-xs">No Data Found</td>  
                           </tr>
                        <?php } ?>
                     </tbody>
                <tfoot class="table-border-bottom-0">
                      <tr>
                     <th>SR NO.</th>
                     <th>BROKER NAME</th>    
                     <th>STATE NAME</th>
                     <th>ACTION</th> 
                      </tr>
                    </tfoot>
            </table> 
         </div>
      </div>
      <!--/ Basic Bootstrap Table -->    
   </div>
   <!-- / Content -->
   <!-- Modal -->
   <!-- this is used for edit -->
 <div class="modal modal-top fade" id="modaltop" role="dialog">
      <div class="modal-dialog modal-lg">
         <form class="modal-content" action="<?php echo base_url().'master/broker'; ?>" method="post" id="add_man1">
            <div class="modal-header">
               <h5 class="modal-title" id="modalTopTitle">Consignor</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal"
                  aria-label="Close"
                  ></button>
            </div>
            <div class="modal-body">  
            <input type="hidden" name="id" id="id1"> 
               <div class="row">
               <div class="col mb-3">
                     <label>Broker Code</label>
                     <input type="text" id="broker_code1" name="broker_code" class="form-control form-control-alternative" value="<?php echo $broker_code; ?>" readonly> 
                  </div>
                  <div class="col mb-3">
                     <label>Broker Name</label>
                     <input type="text" id="broker_name1" name="broker_name" 
                       class="form-control form-control-alternative"> 
                  </div>
                  </div>
                  <div class="row">
                  <div class="col mb-3">
                     <label>Mobile No.</label>
                     <input type="text" id="mobile_no1" name="mobile_no" class="form-control form-control-alternative" minlength="10" maxlength="10">  
                  </div> 
                  <div class="col mb-3">
                     <label>Alternate Mobile No.</label>
                     <input type="text" id="alt_mobile_no1" name="alt_mobile_no" class="form-control form-control-alternative" minlength="10" maxlength="10">  
                  </div> 
                  <div class="col mb-3">
                     <label>Contact Person</label>
                     <input type="text" id="contact_person1" name="contact_person" class="form-control form-control-alternative">   
                  </div>  
               </div>
               <div class="row">
                  <div class="col mb-3"> 
                     <label>Lorry Type</label>
                     <input type="text" id="lorry_type1" name="lorry_type" class="form-control form-control-alternative">  
                  </div>  
                  <div class="col mb-3"> 
                     <label>Address</label>
                     <textarea type="text" id="address1" name="address" class="form-control form-control-alternative"></textarea>  
                  </div>   
               </div>
                  <div class="row mt-3">   
                   <div class="col mb-3">
                     <label>State</label>  
                     <select id="selectd" class="select2 form-select" multiple>
                           <option value="">Select</option>
                           <?php if(!empty($state)){
                              foreach($state as $row){?>
                           <option value="<?php echo $row['id'];?>">
                              <?php echo $row['name'];?> 
                           </option>
                           <?php } } ?>     
                        </select> 
                        <input type="text" hidden name="state_name" id="state_name_one1">    
                  </div>        
               </div>  
               <h5>Bank Details</h5>
               <div class="row">
                  <div class="col mb-3"> 
                     <label>Bank Name</label>
                     <input type="text" id="bank_name1" name="bank_name" class="form-control form-control-alternative">  
                  </div>  
                  <div class="col mb-3"> 
                     <label>Account No.</label>
                     <input type="text" id="account_no1" name="account_no" class="form-control form-control-alternative"> 
                  </div>   
                  <div class="col mb-3"> 
                     <label>IFSC Code</label>
                     <input type="text" id="ifsc_code1" name="ifsc_code" class="form-control form-control-alternative"> 
                  </div>   
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
               Close
               </button>
               <button type="submit" class="btn btn-primary" id="submit1" name="submit_form">Submit</button>
            </div>
         </form>
      </div>
   </div> 
   <!-- this is used for add -->
   <div class="modal modal-top fade" id="modaltop_one" role="dialog">
      <div class="modal-dialog modal-lg">
         <form class="modal-content" action="<?php echo base_url().'master/broker'; ?>" method="post" id="add_man">
            <div class="modal-header">
               <h5 class="modal-title" id="modalTopTitle">Consignor</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal"
                  aria-label="Close"
                  ></button>
            </div>
            <div class="modal-body">  
            <input type="hidden" name="id" id="id">
               <div class="row">
               <div class="col mb-3">
                     <label>Broker Code</label>
                     <input type="text" id="broker_code" name="broker_code" class="form-control form-control-alternative" value="<?php echo $broker_code; ?>" readonly> 
                  </div>
                  <div class="col mb-3">
                     <label>Broker Name</label>  
                     <input type="text" id="broker_name" name="broker_name" 
                     class="form-control form-control-alternative"> 
                  </div>
                  </div>
                  <div class="row">
                  <div class="col mb-3">
                     <label>Mobile No.</label>
                     <input type="text" id="mobile_no" name="mobile_no" class="form-control form-control-alternative" minlength="10" maxlength="10">  
                  </div> 
                  <div class="col mb-3">
                     <label>Alternate Mobile No.</label>
                     <input type="text" id="alt_mobile_no" name="alt_mobile_no" class="form-control form-control-alternative" minlength="10" maxlength="10">  
                  </div> 
                  <div class="col mb-3">
                     <label>Contact Person</label>
                     <input type="text" id="contact_person" name="contact_person" class="form-control form-control-alternative">   
                  </div>  
               </div>
               <div class="row">
                  <div class="col mb-3"> 
                     <label>Lorry Type</label>
                     <input type="text" id="lorry_type" name="lorry_type" class="form-control form-control-alternative">  
                  </div>  
                  <div class="col mb-3"> 
                     <label>Address</label>
                     <textarea type="text" id="address" name="address" class="form-control form-control-alternative"></textarea>  
                  </div>   
               </div>
                  <div class="row mt-3">    
                   <div class="col mb-3"> 
                     <label>State</label>  
                     <select id="state_name" class="select2 form-select" multiple>
                           <option value="">Select</option>
                           <?php if(!empty($state)){
                              foreach($state as $row){?>
                           <option value="<?php echo $row['id'];?>">
                              <?php echo $row['name'];?> 
                           </option>
                           <?php } } ?>     
                        </select> 
                        <input type="text" hidden  name="state_name" id="state_name_one">    
                  </div>        
               </div>  
               
               <h5>Bank Details</h5>
               <div class="row">
                  <div class="col mb-3"> 
                     <label>Bank Name</label>
                     <input type="text" id="bank_name" name="bank_name" class="form-control form-control-alternative">  
                  </div>  
                  <div class="col mb-3"> 
                     <label>Account No.</label>
                     <input type="text" id="account_no" name="account_no" class="form-control form-control-alternative"> 
                  </div>   
                  <div class="col mb-3"> 
                     <label>IFSC Code</label>
                     <input type="text" id="ifsc_code" name="ifsc_code" class="form-control form-control-alternative"> 
                  </div>   
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
               Close
               </button>
               <button type="submit" class="btn btn-primary" id="submit" name="submit_form">Submit</button>
            </div>
         </form>
      </div>
   </div>
</div>
</div>
</div>
</div>   
<script>
  function get_area(broker_code, man_pow, broker_name, mobile_no, alt_mobile_no, contact_person, lorry_type, address, bank_name, account_no, ifsc_code, id, table_name) {
      $.each(man_pow.split(","), function(i,e){
            $("#selectd option[value='" + e + "']").prop("selected", true);
         });  
         //$(".select2").select2();       
         $("#id1").val(id);
         $("#state_name_one1").val(man_pow);  
         $("#broker_code1").val(broker_code);   
         $("#broker_name1").val(broker_name); 
         $("#mobile_no1").val(mobile_no); 
         $("#alt_mobile_no1").val(alt_mobile_no); 
         $("#contact_person1").val(contact_person);     
         $("#lorry_type1").val(lorry_type);   
         $("#address1").val(address);
         $("#bank_name1").val(bank_name); 
         $("#account_no1").val(account_no);
         $("#ifsc_code1").val(ifsc_code);        
      }
   function clear(elements) {
         var errors = 0;
         $.each(elements, function(index, element){  
             $('#modaltop' + element).val('');
             errors++;
         });
     }
     function delete_broker(id,table_name){
     var del =confirm("Do you want to delete this?")
          if (del) {
          $.ajax({
          url:'<?php echo base_url(strtolower($controller_name).'/delete_data/');?>'+id+'/'+table_name,      
           type: "POST",
           data:{id:id},
         success: function(response){  
         alert(response);  
           location.reload()      
         }
         });
           }
   }
   </script>
   <script>
   $('#add_man').on('click', function(e) {
      // e.preventDefault();
      var a = $('#state_name').val();
      //alert(a);
      $('#state_name_one').val(a); 
      /// $("#add_man").submit();
   })
   $('#submit').on('mouseover', function(e) {
      // e.preventDefault();
      var a = $('#state_name').val();
      //alert(a);
      $('#state_name_one').val(a);
      /// $("#add_man").submit();   
   })

   $('#add_man1').on('click', function(e) {
      // e.preventDefault();
      var a = $('#selectd').val();
      //alert(a);
      $('#state_name_one1').val(a);
      /// $("#add_man").submit();
   })
   $('#submit1').on('mouseover', function(e) {
      // e.preventDefault();
      var a = $('#selectd').val();
      //alert(a);
      $('#state_name_one1').val(a);
      /// $("#add_man").submit(); 
   })
</script>
