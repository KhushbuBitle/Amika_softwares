<div class="content-wrapper">
   <div class="container-xxl flex-grow-1 container-p-y">
      <?php if(!empty($this->session->flashdata('success_message'))){ ?>
      <div class="row mt-3">
         <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
            <div class="alert alert-success alert-dismissible">
               <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
            </div>      
         </div> 
      </div>
      <?php } ?> 
      <div class="card">
         <div class="card-header">  
            <div class="row">
               <div class="col-md-8 col-sm-8 col-xs-8 col-lg-8">
                  <h5>Consignee List</h5>
               </div>
               <div class="col-sm-4">
                  <a href="" role="button" class="btn btn-primary btn-md doctor_btn" data-bs-toggle="modal" onclick="get_area('0');">Add Consignee</a>
               </div>
            </div>
         </div> 
         <hr>
         <div class="table-responsive text-nowrap"> 
            <table class="table datatableid"> 
               <thead>
                  <tr>
                     <th>SR NO.</th>
                     <th>NAME</th>
                     <th>MOBILE NO</th>
                     <th>CONTACT PERSON</th>
                     <th>ACTION</th>
                  </tr>
               </thead>     
               <tbody>
                  <?php if(!empty($info)){ $i=1; foreach($info as $key){?>
                  <tr>
                     <td><?php echo $i;?></td>
                     <td><?php echo $key->company_name;?></td> 
                     <td><?php echo $key->mobile_no;?></td>
                     <td><?php echo $key->contact_person;?></td>       
                     <td>
                     <!-- <button type="button" class="btn rounded-pill btn-primary">Primary</button> -->
                                                                                                                                                                                  
                              <a href=" " role="button" class="btn btn-sm rounded-pill btn-info" data-bs-toggle="modal" onclick="get_area('<?php echo $key->id;?>','m_consignee_details')"><i class="bx bx-edit-alt me-2"></i></a>
                              <a href=" " role="button" class="btn btn-sm rounded-pill btn-danger" onclick="delete_consignee('<?php echo $key->id;?>','m_consignee_details')" data-bs-toggle="modal"><i class="bx bx-trash me-2"></i></a>
                           
                     </td>
                  </tr>
                  <?php $i++; } }else{ ?>
                  <tr>
                     <td colspan="4" class="text-center text-xs">No Data Found</td>
                  </tr>
                  <?php }  ?>
               </tbody>
                <tfoot class="table-border-bottom-0">
                      <tr>
                     <th>SR NO.</th>
                     <th>NAME</th>
                     <th>MOBILE NO</th> 
                     <th>CONTACT PERSON</th>  
                     <th>ACTION</th>
                      </tr>
                    </tfoot>
            </table> 
         </div>
      </div>
      <!--/ Basic Bootstrap Table -->    
   </div>
   <!-- / Content -->
   <!-- Modal -->
   <div class="modal modal-top fade" id="modaltop" role="dialog">
      <div class="modal-dialog modal-lg">
         <form class="modal-content" action="<?php echo base_url().'master/consignee'; ?>" method="post">
            <div class="modal-header">
               <h5 class="modal-title" id="modalTopTitle">Consignee</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal"
                  aria-label="Close"
                  ></button>
            </div>
            <div class="modal-body">  
               <input type="hidden" name="id" id="id">    
               <div class="row">
                  <div class="col mb-3">
                     <label>Customer Code</label>
                     <input type="text" id="customer_code" name="customer_code" 
                      value="<?php echo $customer_code; ?>" class="form-control form-control-alternative" readonly> 
                  </div>
                  <div class="col mb-0">
                     <label>Company Name</label>
                     <input type="text" id="company_name" name="company_name" class="form-control form-control-alternative">
                  </div>
                  <div class="col mb-0">
                     <label>Mobile no.</label>
                     <input type="text" id="mobile_no" name="mobile_no" minlength="10" maxlength="10" class="form-control form-control-alternative">
                  </div>
               </div>
               <div class="row">   
                  <div class="col mb-0">
                     <label>Contact Person</label>
                     <input type="text" id="contact_person" name="contact_person"  class="form-control form-control-alternative">
                  </div>
                  <div class="col mb-0">
                     <label>Owner Name</label>
                     <input type="text" id="owner_name" name="owner_name"  class="form-control form-control-alternative">
                  </div>
                  <div class="col mb-0">   
                     <label>GST No.</label>
                     <input type="text" id="gst_no" name="gst_no" minlength="15" maxlength="15" Onchange="validate_gst_number(this)" oninput="this.value = this.value.toUpperCase()" class="form-control form-control-alternative">
                     <span id="gst_msg" style="color:red;"></span>
                  </div>   
                  
               </div>  
               <div class="row mt-3">    
                   <div class="col mb-0">
                     <label>Email Id</label>
                     <input type="email" id="email_id" name="email_id" class="form-control form-control-alternative">
                  </div>  
                  <div class="col mb-0">
                     <label>Alternate Mobile No.</label>
                     <input type="text" id="alternate_no" minlength="10" maxlength="10" name="alternate_no" class="form-control form-control-alternative">
                  </div>
                  <div class="col mb-0">
                     <label>Address</label>
                     <textarea type="text" id="address" name="address" class="form-control form-control-alternative"></textarea>
                  </div>   
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
               Close
               </button>
               <button type="submit" class="btn btn-primary" name="submit_form">Submit</button>
            </div>
         </form>
      </div>
   </div>
</div>
</div>
</div>
</div>   
<script>
   function get_area(id,table_name){
   if(id==0){
      clear(['id','customer_code','company_name','mobile_no','contact_person','owner_name','gst_no','email_id','address','alternate_no']);   
          $("#modaltop").modal('show');
          
      }else{
          var url = '<?php echo base_url($controller_name.'/get_single_data/');?>'+id+'/'+table_name;
          $.get(url, function(response) {
              var data = JSON.parse(response);
              $("#id").val(id);
              $("#customer_code").val(data.customer_code);
              $("#company_name").val(data.company_name);
              $('#mobile_no').val(data.mobile_no);
              $('#contact_person').val(data.contact_person); 
              $('#owner_name').val(data.owner_name);    
              $('#gst_no').val(data.gst_no);
              $('#email_id').val(data.email_id);  
              $('#address').val(data.address);
              $('#alternate_no').val(data.alternate_no);

          });
          $("#modaltop").modal('show'); 
      }
   }
   function clear(elements) {  
         var errors = 0;
         $.each(elements, function(index, element){
             $('#modaltop' + element).val('');
             errors++;
         });
     }
     function delete_consignee(id,table_name){
     var del =confirm("Do you want to delete this?")
          if (del) {
          $.ajax({
          url:'<?php echo base_url(strtolower($controller_name).'/delete_data/');?>'+id+'/'+table_name,      
           type: "POST",
           data:{id:id},
         success: function(response){  
         alert(response);  
           location.reload() 
         }
         });
           }
   }
    function validate_gst_number(gst) {
       let gstnumber = $(gst).val();
       var regex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{1}[A-Z0-9]{1}[A-Z0-9]{1}$/;
       if (!gstnumber.match(regex)) {
         document.getElementById("gst_msg").innerHTML = "**Invalid GST number ";
       }
       else {
         document.getElementById("gst_msg").innerHTML = "";
       }
   }
</script>
