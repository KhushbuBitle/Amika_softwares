<div class="content-wrapper">
   <div class="container-xxl flex-grow-1 container-p-y">
      <?php if(!empty($this->session->flashdata('success_message'))){ ?>
      <div class="row mt-3">
         <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
            <div class="alert alert-success alert-dismissible">
               <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
            </div>     
         </div>
      </div>
      <?php } ?>
      <div class="card">
         <div class="card-header">             
            <div class="row">
               <div class="col-md-8 col-sm-8 col-xs-8 col-lg-8">
                  <h5>Lorry Owner List</h5> 
               </div>
               <div class="col-sm-4">
                  <a href="" role="button" class="btn btn-primary btn-md doctor_btn" data-bs-toggle="modal" onclick="get_area('0');">Add Lorry Owner</a>      
               </div>  
            </div>
         </div>       
         <hr>
         <div class="table-responsive text-nowrap">
            <table class="table datatableid">      
               <thead>  
                  <tr>
                     <th>SR NO.</th>
                     <th>LORRY NO.</th>
                     <th>OWNER NAME</th>
                     <th>MOBILE NO.</th>  
                     <th>INSURANCE EXPIRE DATE</th>
                     <th>FITNESS EXPIRE DATE</th>
                     <th>ACTION</th>  
                  </tr>
               </thead>  
               <tbody>
                  <?php if(!empty($info)){ $i=1; foreach($info as $key){?>
                  <tr>
                     <td><?php echo $i;?></td>
                     <td><?php echo $key->lorry_no;?></td>
                     <td><?php echo $key->owner_name;?></td>
                     <td><?php echo $key->owner_no; ?></td>
                     <td><?php
                     if(date('d-m-Y',strtotime($key->expiry_date)) == "01-01-1970"){
                        echo "";
                     }else{
                        echo date('d-m-Y',strtotime($key->expiry_date));
                     }
                      ?></td>
                      <td>
                         <?php
                     if(date('d-m-Y',strtotime($key->expiry_date)) == "01-01-1970"){
                        echo "";
                     }else{
                        echo date('d-m-Y',strtotime($key->expiry_date));
                     }
                      ?>
                      </td>
                      <td>
                        
                          
                              <a href=" " role="button" class="btn btn-sm rounded-pill btn-info"  data-bs-toggle="modal" onclick="get_area('<?php echo $key->id;?>','m_lorry_owner_details')"><i class="bx bx-edit-alt me-2"></i></a>
                              <a href=" " role="button" class="btn btn-sm rounded-pill btn-danger" onclick="delete_lorry_owner('<?php echo $key->id;?>','m_lorry_owner_details')" data-bs-toggle="modal"><i class="bx bx-trash me-2"></i></a>
                          
                     </td>
                  </tr>
                  <?php $i++; } }else{ ?>
                  <tr>
                     <td colspan="6" class="text-center text-xs">No Data Found</td>
                  </tr>
                  <?php }  ?>
               </tbody>  
                <tfoot class="table-border-bottom-0">
                      <tr>
                     <th>SR NO.</th>
                     <th>LORRY NO.</th>
                     <th>OWNER NAME</th>
                     <th>MOBILE NO.</th>
                     <th>INSURANCE EXPIRE DATE</th>
                     <th>FITNESS EXPIRE DATE</th>
                     <th>ACTION</th>    
                      </tr>
                    </tfoot>
            </table> 
         </div>   
      </div>
      <!--/ Basic Bootstrap Table -->       
   </div>
   <!-- / Content --> 
   <!-- Modal -->
   <div class="modal modal-top fade" id="modaltop" role="dialog">
      <div class="modal-dialog modal-lg">  
         <form class="modal-content" action="<?php echo base_url().'master/lorry_owner'; ?>" method="post" enctype="multipart/form-data">
            <div class="modal-header">   
               <h5 class="modal-title" id="modalTopTitle">Lorry Owner</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal"
                  aria-label="Close"  
                  ></button>    
            </div>
            <div class="modal-body">  
               <input type="hidden" name="id" id="id" >
               <div class="row">
                  <div class="col mb-0">
                     <label>Lorry/Truck No.</label>
                     <input type="text" id="lorry_no" name="lorry_no" class="form-control form-control-alternative"> 
                  </div>
                  <div class="col mb-0"> 
                     <label>Chasis No.</label>
                     <input type="text" id="chesis_no" name="chesis_no" class="form-control form-control-alternative" minlength="17" maxlength="17">
                  </div>   
                  <div class="col mb-0">
                     <label>Engine No.</label>
                     <input type="text" id="engine_no" name="engine_no" class="form-control form-control-alternative" minlength="10" maxlength="10"> 
                  </div>   
               </div>
               <div class="row mt-2">   
               <div class="col mb-0">    
                     <label>Insurance No.</label>
                     <input type="text" id="insurance_no" name="insurance_no" class="form-control form-control-alternative">
                  </div>    
                  <div class="col mb-0">
                     <label>Insurance Expiry Date</label>
                     <input type="date" id="expiry_date" name="expiry_date"  class="form-control form-control-alternative">
                  </div>  
                  <div class="col mb-0">      
                     <label>Insurance Attachment</label>
                     <input type="file" id="insurance_pdf" name="insurance_pdf" onchange="insurance_validation(this.id,2048,'KB');" class="form-control form-control-alternative">  
                  </div> 
               </div>   
                  <div class="row mt-2">
                   <div class="col mb-0">  
                     <label>Fitness Certificate No</label>
                     <input type="text" id="fitness_no" name="fitness_no" class="form-control form-control-alternative">   
                  </div>
                  <div class="col mb-0">
                     <label>Fitness Expire Date</label>
                     <input type="date" id="fitness_expire_date" name="fitness_expire_date" class="form-control form-control-alternative"> 
                  </div>
                  <div class="col mb-0">  
                     <label>Fitness Certificate Attachment</label>
                     <input type="file" id="fitnes_pdf" name="fitnes_pdf" onchange="fitness_validation(this.id,2048,'KB');" class="form-control form-control-alternative"> 
                  </div>  
               </div>
                <div class="row mt-2">  
                  <div class="col mb-0">  
                     <label>Owner Name</label>
                     <input type="text" id="owner_name" name="owner_name" class="form-control form-control-alternative"> 
                  </div>
                   <div class="col mb-0">  
                     <label>Mobile No.</label> 
                     <input type="text" id="owner_no" name="owner_no" minlength="10" maxlength="10" class="form-control form-control-alternative"> 
                  </div>
                  <div class="col mb-0">  
                     <label>Alternate Mobile No.</label> 
                     <input type="text" id="alternate_no" name="alternate_no" minlength="10" maxlength="10" class="form-control form-control-alternative"> 
                  </div>  
               </div>
                <div class="row mt-2">  
                  <div class="col-sm-6 mb-0">  
                     <label>Address</label>
                     <textarea type="text" id="address" name="address" class="form-control form-control-alternative"></textarea>
                  </div>     
                  <div class="col-sm-3 mb-0">  
                     <label>RC</label>
                      <input type="text" id="rc" name="rc" class="form-control form-control-alternative">
                  </div> 
                  <div class="col-sm-3 mb-0">  
                     <label>Permit</label>
                      <input type="text" id="permit" name="permit" class="form-control form-control-alternative">
                  </div>     
               </div>
                <div class="row mt-2">  
                   <div class="col mb-0">  
                     <label>PAN No.</label> 
                     <input type="text" id="pan_no" name="pan_no" minlength="10"
                     maxlength="10" oninput="this.value = this.value.toUpperCase()"  Onchange="validatePanNumber(this)" class="form-control form-control-alternative"> 
                      <span id="pan_msg" style="color:red;"></span> 
                  </div>
                   <div class="col mb-0">    
                     <label>Pancard Attachment</label>
                     <input type="file" id="pancard_pdf" name="pancard_pdf" onchange="pancard_validation(this.id,2048,'KB');" class="form-control form-control-alternative">
                  </div> 
               </div>   
                <div class="row mt-2">           
                  <div class="col mb-0">  
                     <label>Aadhar No.</label> 
                     <input type="text" id="aadhar_no" name="aadhar_no" minlength="12" maxlength="12" class="form-control form-control-alternative">  
                  </div>  
                  <div class="col mb-0">    
                     <label>Aadhar Attachment</label>
                     <input type="file" id="aadhar_pdf" name="aadhar_pdf" onchange="aadhar_validation(this.id,2048,'KB');" class="form-control form-control-alternative">
                  </div> 
               </div>             
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
               Close
               </button>
               <button type="submit" class="btn btn-primary" name="submit_form">Submit</button>
            </div>
         </form>
      </div>
   </div>
</div>
</div>
</div>
</div>   
<script>  
   function get_area(id,table_name){
   if(id==0){
      clear(['id','lorry_no','chesis_no','insurance_no','expiry_date','engine_no','fitness_expire_date','fitness_no','owner_name','owner_no','alternate_no','pan_no','aadhar_no','insurance_pdf','fitnes_pdf','pancard_pdf','aadhar_pdf']);  
          $("#modaltop").modal('show');  
          
      }else{
          var url = '<?php echo base_url($controller_name.'/get_single_data/');?>'+id+'/'+table_name;
          $.get(url, function(response) {
              var data = JSON.parse(response); 
              $("#id").val(id);
              $("#lorry_no").val(data.lorry_no);
              $("#chesis_no").val(data.chesis_no);
              $('#insurance_no').val(data.insurance_no);
              $('#expiry_date').val(data.expiry_date);
              $('#engine_no').val(data.engine_no);
              $('#fitness_no').val(data.fitness_no);
              $('#fitness_expire_date').val(data.fitness_expire_date);
              $('#owner_name').val(data.owner_name); 
              $('#owner_no').val(data.owner_no);
              $('#alternate_no').val(data.alternate_no);
              $('#address').val(data.address);
              $('#pan_no').val(data.pan_no);  
              $('#aadhar_no').val(data.aadhar_no);
              $('#rc').val(data.rc);  
              $('#permit').val(data.permit);   
              $('#insurance_pdf').val(data.insurance_pdf);
              $('#fitnes_pdf').val(data.fitnes_pdf);  
              $('#pancard_pdf').val(data.pancard_pdf);
              $('#aadhar_pdf').val(data.aadhar_pdf); 

           });
          $("#modaltop").modal('show');    
      }
   }
   function clear(elements) {
         var errors = 0;
         $.each(elements, function(index, element){
             $('#modaltop' + element).val('');
             errors++;
         });
     }
     function delete_lorry_owner(id,table_name){
     var del =confirm("Do you want to delete this?")
          if (del) {
          $.ajax({
          url:'<?php echo base_url(strtolower($controller_name).'/delete_data/');?>'+id+'/'+table_name,      
           type: "POST",
           data:{id:id},
         success: function(response){  
         alert(response);  
           location.reload() 
         }
         });
           }
   } 
    function validatePanNumber(pan){
       let pannumber = $(pan).val();
       var regex = /[A-Z]{5}\d{4}[A-Z]{1}/;
       if (!pannumber.match(regex)) {
          document.getElementById("pan_msg").innerHTML = "**Invalid pan number";
       }
       else{
         document.getElementById("pan_msg").innerHTML = "";
      }  
   }
   function insurance_validation(cid, sz, a) {
       var controllerID = cid;
       var fileSize = sz;
       var extation = a;
       if (window.ActiveXObject) {
           var fso = new ActiveXObject("Scripting.FileSystemObject");
           var filepath = document.getElementById('insurance_pdf').value;
           var thefile = fso.getFile(filepath);
           var sizeinbytes = thefile.size;
       } else {
           var sizeinbytes = document.getElementById('insurance_pdf').files[0].size;
       }
       var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
       fSize = sizeinbytes;
       i = 0;
       while (fSize > 900) {
           fSize /= 1024;
           i++; 
       }
       var fup = document.getElementById('insurance_pdf');
       var fileName = fup.value;
       var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
       if (ext == "jpeg" || ext == "jpg" || ext == "png" || ext == "pdf") {
           var fs = Math.round(fSize);
           if (fs < fileSize && fSExt[i] == extation) {
               return true;
           } else {
               alert("Please enter the image size upto 2MB");
               document.getElementById('insurance_pdf').value = '';
               return false;
           }
       } else {
           alert("Must be jpg,png,pdf and jpeg images ONLY"); 
           document.getElementById('insurance_pdf').value = '';
           return false;
       }
   }    
    function fitness_validation(cid, sz, a) {
       var controllerID = cid;
       var fileSize = sz;
       var extation = a;
       if (window.ActiveXObject) {
           var fso = new ActiveXObject("Scripting.FileSystemObject");
           var filepath = document.getElementById('fitnes_pdf').value;
           var thefile = fso.getFile(filepath);
           var sizeinbytes = thefile.size;
       } else {
           var sizeinbytes = document.getElementById('fitnes_pdf').files[0].size;
       }
       var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
       fSize = sizeinbytes;
       i = 0;
       while (fSize > 900) {
           fSize /= 1024;
           i++; 
       }
       var fup = document.getElementById('fitnes_pdf');
       var fileName = fup.value;
       var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
       if (ext == "jpeg" || ext == "jpg" || ext == "png" || ext == "pdf") {
           var fs = Math.round(fSize);
           if (fs < fileSize && fSExt[i] == extation) {
               return true;
           } else {
               alert("Please enter the image size upto 2MB");
               document.getElementById('fitnes_pdf').value = '';
               return false;
           }
       } else {
           alert("Must be jpg,png,pdf and jpeg images ONLY"); 
           document.getElementById('fitnes_pdf').value = '';
           return false;
       }
   }   
    function pancard_validation(cid, sz, a) {
       var controllerID = cid;
       var fileSize = sz;
       var extation = a;
       if (window.ActiveXObject) {
           var fso = new ActiveXObject("Scripting.FileSystemObject");
           var filepath = document.getElementById('pancard_pdf').value;
           var thefile = fso.getFile(filepath);
           var sizeinbytes = thefile.size;
       } else {
           var sizeinbytes = document.getElementById('pancard_pdf').files[0].size;
       }
       var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
       fSize = sizeinbytes;
       i = 0;
       while (fSize > 900) {
           fSize /= 1024;
           i++; 
       }
       var fup = document.getElementById('pancard_pdf');
       var fileName = fup.value;
       var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
       if (ext == "jpeg" || ext == "jpg" || ext == "png" || ext == "pdf") {
           var fs = Math.round(fSize);
           if (fs < fileSize && fSExt[i] == extation) {
               return true;
           } else {
               alert("Please enter the image size upto 2MB");
               document.getElementById('pancard_pdf').value = '';
               return false;
           }
       } else {
           alert("Must be jpg,png,pdf and jpeg images ONLY"); 
           document.getElementById('pancard_pdf').value = '';
           return false;
       }
   }   
   function aadhar_validation(cid, sz, a) {
       var controllerID = cid;
       var fileSize = sz;
       var extation = a;
       if (window.ActiveXObject) {
           var fso = new ActiveXObject("Scripting.FileSystemObject");
           var filepath = document.getElementById('aadhar_pdf').value;
           var thefile = fso.getFile(filepath);
           var sizeinbytes = thefile.size;
       } else {
           var sizeinbytes = document.getElementById('aadhar_pdf').files[0].size;
       }
       var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
       fSize = sizeinbytes;
       i = 0;
       while (fSize > 900) {
           fSize /= 1024;
           i++; 
       }
       var fup = document.getElementById('aadhar_pdf');
       var fileName = fup.value;
       var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
       if (ext == "jpeg" || ext == "jpg" || ext == "png" || ext == "pdf") {
           var fs = Math.round(fSize);
           if (fs < fileSize && fSExt[i] == extation) {
               return true;
           } else {
               alert("Please enter the image size upto 2MB");
               document.getElementById('aadhar_pdf').value = '';
               return false;
           }
       } else {
           alert("Must be jpg,png,pdf and jpeg images ONLY"); 
           document.getElementById('aadhar_pdf').value = '';
           return false;
       }
   }   
</script>