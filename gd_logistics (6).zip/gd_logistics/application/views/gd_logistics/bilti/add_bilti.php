<div class="content-wrapper">
   <div class="container-xxl flex-grow-1 container-p-y">
      <!-- Basic Layout -->
      <div class="row">
         <div class="col-xl">
            <div class="card mb-4">  
               <div class="card-header d-flex justify-content-between align-items-center">
                  <h5 class="mb-0">Bilti</h5>       
               </div>   
               <div class="card-body"> 
                  <form>
                      <?php $load_type = array('FTL','LTL','SUN'); ?>
                     <div class="row">
                        <div class="col-sm-4">  
                           <div class="form-group">
                              <label class="floating-label" for="Text">Load Type</label> 
                     <select  name="load_type" id="load_type" class="form-select">
                        <option value="">Select</option>
                        <?php for($i=0;$i<count($load_type);$i++){?>
                        <option value="<?php echo $load_type[$i]; ?>" ><?php echo $load_type[$i]; ?></option>
                        <?php } ?>
                     </select>
                           </div>
                        </div>
                        <div class="col-sm-4">  
                           <div class="form-group">
                              <label class="floating-label" for="Text">Insurance Company</label>
                              <input type="text" class="form-control" id="insurance_company" name="insurance_company">
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">From</label>
                              <input type="text" class="form-control" id="from" name="from">
                           </div>
                        </div>   
                        </div>
                      <p class="mt-3"><u>AT OWNER'S RISK</u></p> 
                     <div class="row">
                        <div class="col-sm-4">  
                           <div class="form-group">
                              <label class="floating-label" for="Text">Policy No.</label>
                              <input type="text" class="form-control" id="last_name" name="last_name">
                           </div>
                        </div>
                        <div class="col-sm-4"> 
                           <div class="form-group">
                              <label class="floating-label" for="Text">To</label>
                              <input type="text" class="form-control" id="to" name="to">        
                           </div>
                        </div>
                     </div> 
                      <p class="mt-2"><u>CONSIGNOR</u></p>
                     <div class="row">  
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Company Name</label>
                              <input type="text" class="form-control" id="c_company_name" name="c_company_name">
                           </div>   
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST NO.</label>
                                 <input type="text" class="form-control" id="c_gst_no" name="c_gst_no" minlength="15" maxlength="15">   
                           </div> 
                        </div>
                         <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Phone No.</label>
                                 <input type="text" class="form-control" id="c_phone_no" name="c_phone_no" minlength="10" maxlength="10">   
                           </div> 
                        </div>
                     </div>
                     <p class="mt-2"><u>CONSIGNEE</u></p>
                     <div class="row">    
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Company Name</label>
                              <input type="text" class="form-control" id="cn_company_name" name="cn_company_name">
                           </div>   
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST NO.</label>
                                 <input type="text" class="form-control" id="cn_gst_no" name="cn_gst_no" minlength="15" maxlength="15">   
                           </div>  
                        </div> 
                         <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Phone No.</label>
                                 <input type="text" class="form-control" id="cn_phone_no" name="cn_phone_no" minlength="10" maxlength="10">   
                           </div> 
                        </div>
                     </div>  
                     <div class="row mt-3">    
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">PKGS</label>
                              <input type="text" class="form-control" id="pkgs" name="pkgs">
                           </div>   
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Packing Type</label>
                                 <input type="text" class="form-control" id="packing_type" name="packing_type">   
                           </div>  
                        </div>  
                         <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">E Way Bill No.</label>
                                 <input type="text" class="form-control" id="e_way_bill_no" name="e_way_bill_no">   
                           </div>  
                        </div>
                     </div>  
                     <div class="row mt-3">    
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Invoice No.</label>
                              <input type="text" class="form-control" id="invoice_no" name="invoice_no">
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Declared Value</label>
                                 <input type="text" class="form-control" id="declared_value" name="declared_value">   
                           </div>  
                        </div>  
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Valid Upto</label>
                                 <input type="text" class="form-control" id="valid_upto" name="valid_upto">     
                           </div>  
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Lorry No.</label>
                                 <input type="text" class="form-control" id="lorry_no" name="lorry_no">      
                           </div>   
                        </div>
                     </div>  
                     <div class="row mt-3">    
                        <div class="col-sm-6">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Description</label>
                              <input type="text" class="form-control" id="invoice_no" name="invoice_no">
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Actual Wt.</label>
                                 <input type="text" class="form-control" id="actual_wt" name="actual_wt">   
                           </div>  
                        </div>  
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Charge Wt.</label>
                                 <input type="text" class="form-control" id="charge_wt" name="charge_wt">     
                           </div>      
                        </div>
                     </div>
                     <p class="mt-2"><u>CONSIGNMENT NOTE NO</u></p>
                     <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">VS</label>
                              <input type="text" class="form-control" id="vs_code" name="vs_code">
                           </div>     
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">DATE</label>
                                 <input type="date" class="form-control" id="con_date" name="con_date">   
                           </div>  
                        </div> 
                         <div class="col-sm-3">    
                           <div class="form-group">
                              <label class="floating-label" for="Text">Pan No.</label>
                                 <input type="text" class="form-control" id="con_pan_no" name="con_pan_no" minlength="10" maxlength="10">   
                           </div> 
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST No.</label>
                                 <input type="text" class="form-control" id="con_gst_no" name="con_gst_no" minlength="15" maxlength="15">   
                           </div> 
                        </div>
                     </div>  
                     <div class="row mt-3">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Freight</label>
                              <input type="text" class="form-control" id="freight" name="freight" value="Freight" readonly>
                           </div>              
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate</label>
                                 <input type="text" class="form-control" id="fr_rate" name="fr_rate">   
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount</label>
                                 <input type="text" class="form-control" id="fr_amount" name="fr_amount">   
                           </div> 
                        </div> 
                     </div>   
                      <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Door Delivery</label>
                              <input type="text" class="form-control" id="door_delivery" name="door_delivery" value="Door Delivery" readonly>
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate</label>
                                 <input type="text" class="form-control" id="door_rate" name="door_rate">   
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount</label>
                                 <input type="text" class="form-control" id="door_amount" name="door_amount">   
                           </div> 
                        </div>
                     </div>      
                     <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Local Collection</label>
                              <input type="text" class="form-control" id="door_delivery" name="door_delivery" value="Local Collection" readonly>
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate</label>
                                 <input type="text" class="form-control" id="local_rate" name="local_rate">   
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount</label>
                                 <input type="text" class="form-control" id="local_amount" name="local_amount">   
                           </div> 
                        </div>   
                     </div> 
                     <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">LR Charge</label>
                              <input type="text" class="form-control" id="lr_charge" name="lr_charge" value="LR Charge" readonly>
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate</label>
                                 <input type="text" class="form-control" id="lr_rate" name="lr_rate">    
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount</label>
                                 <input type="text" class="form-control" id="lr_amount" name="lr_amount">   
                           </div> 
                        </div>   
                     </div>     
                     <div class="row">       
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Sub Charge</label>
                              <input type="text" class="form-control" id="sub_charge" name="sub_charge" value="Sub Charge" readonly>
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate</label>
                                 <input type="text" class="form-control" id="sub_rate" name="sub_rate">    
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount</label>
                                 <input type="text" class="form-control" id="sub_amount" name="sub_amount">   
                           </div> 
                        </div>   
                     </div> 
                      <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST Charge</label>
                              <input type="text" class="form-control" id="gst_charge" name="gst_charge" value="GST Charge" readonly>  
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate</label>
                                 <input type="text" class="form-control" id="gst_rate" name="gst_rate">    
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount</label>
                                 <input type="text" class="form-control" id="gst_amount" name="gst_amount">   
                           </div>   
                        </div>   
                     </div> 
                     <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Grand Total</label>
                              <input type="text" class="form-control" id="grand_total" name="grand_total" value="Grand Total" readonly>  
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate</label>
                                 <input type="text" class="form-control" id="grand_rate" name="grand_rate">    
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount</label>
                                 <input type="text" class="form-control" id="grand_amount" name="grand_amount">   
                           </div>   
                        </div>   
                     </div>
                     <div class="row">     
                        <div class="col-sm-12">     
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount In Words</label>
                              <input type="text" class="form-control" id="amount_in_word" name="amount_in_word">  
                           </div>   
                        </div>   
                     </div>   
                     <div class="row mt-3">        
                        <div class="col-sm-4">    
                           <div class="form-group">
                              <label class="floating-label" for="Text">Basis Of BKG</label><br> 
                             <label class="radio-inline"><input type="radio" name="basis_of_bkg" value="to_pay">To PAY</label>
                             <label class="radio-inline"><input type="radio" name="basis_of_bkg" value="tbb">TBB</label>
                             <label class="radio-inline"><input type="radio" name="basis_of_bkg" value="paid">PAID</label>
                           </div>   
                        </div>  
                        <div class="col-sm-4">    
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST PAY</label><br> 
                             <label class="radio-inline"><input type="radio" name="gst_pay" value="consignor">Consignor</label>
                             <label class="radio-inline"><input type="radio" name="gst_pay" value="consignee">Consignee</label>
                             <label class="radio-inline"><input type="radio" name="gst_pay" value="ntc">NTC</label>
                           </div>   
                        </div>
                     </div>
                     <div class="row mt-3">  
                        <div class="col-sm-12">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">For Acknowledment</label>
                              <textarea type="text" class="form-control" id="for_acknowledment" name="for_acknowledment"> </textarea> 
                           </div>          
                        </div> 
                     </div>           
                     <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'staff';?>" class="btn btn-secondary me-md-2">BACK</a>
                        <button type="submit" name="submit_form" class="btn btn-primary">SAVE</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>