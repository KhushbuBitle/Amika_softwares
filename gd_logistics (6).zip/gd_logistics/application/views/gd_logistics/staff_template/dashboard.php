<?php $this->load->view('gd_logistics/template/headerscript'); ?>
<?php $this->load->view('gd_logistics/template/sidebar'); ?>
<?php $this->load->view('gd_logistics/template/staff_topbar'); ?>
<?php $this->load->view('gd_logistics/staff_template/'.$page_name); ?>
<?php $this->load->view('gd_logistics/template/footerscript'); ?>         
