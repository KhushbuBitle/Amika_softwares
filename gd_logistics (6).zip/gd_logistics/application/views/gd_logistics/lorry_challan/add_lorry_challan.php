<div class="content-wrapper">
   <div class="container-xxl flex-grow-1 container-p-y">
      <!-- Basic Layout -->
      <div class="row">
         <div class="col-xl">
            <div class="card mb-4">  
               <div class="card-header d-flex justify-content-between align-items-center">
                  <h5 class="mb-0">Lorry Challan</h5>
               </div>   
               <div class="card-body">
                  <form>
                     <div class="row">
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Lorry Hire Contact No.</label>
                              <input type="text" class="form-control" id="lorry_hire_contact_no" name="lorry_hire_contact_no">
                           </div>
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Date</label>
                              <input type="date" class="form-control" id="date" name="date">
                           </div>
                        </div>
                     </div>
                     <div class="row mt-3">
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">From(State,City)</label>
                              <input type="text" class="form-control" id="from" name="from">
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">To(sate,City)</label>
                              <input type="text" class="form-control" id="to" name="to">
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Lorry No.</label>
                              <input type="text" class="form-control" id="lorry_no" name="lorry_no">
                           </div>
                        </div>
                     </div>
                     <div class="row mt-3">
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Challan No.</label>
                              <input type="text" class="form-control" id="challan_no" name="challan_no">
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">CNS No.</label>
                              <input type="text" class="form-control" id="cns_no" name="cns_no">          
                           </div>
                        </div>
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Pkg.</label>
                              <input type="text" class="form-control" id="package" name="package">
                           </div>
                        </div>
                     </div>
                     <div class="row mt-3">  
                        <div class="col-sm-6">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Act. Wt.</label>
                              <textarea type="text" class="form-control" id="owner_details" name="owner_details"></textarea>
                           </div>
                        </div>
                        <div class="col-sm-6">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Charge Wt.</label>
                              <input type="text" class="form-control" id="charge_wt" name="charge_wt">
                           </div>
                        </div>
                     </div>
                      <div class="row mt-3">  
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Owner Details</label>
                              <textarea type="text" class="form-control" id="owner_details" name="owner_details"></textarea>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Driver Details</label>
                              <textarea type="text" class="form-control" id="driver_details" name="driver_details"></textarea>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Broker Details</label>
                              <textarea type="text" class="form-control" id="broker_details" name="broker_details"></textarea>
                           </div>
                        </div>
                     </div> 
                       <p class="mt-3" style="font-weight: bold;"><u>Hire Particulars</u></p> 
                      <div class="row mt-3">     
                        <div class="col-sm-6">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate Per Ton</label>
                              <input type="text" class="form-control" id="rate_per_ton" name="rate_per_ton">
                           </div>
                        </div>
                        <div class="col-sm-6">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Charge Wt.</label>
                              <input type="text" class="form-control" id="hire_charge_wt" name="hire_charge_wt">
                           </div>
                        </div>
                     </div>
                      <p class="mt-3" style="font-weight: bold;"><u>Advance Detail</u></p> 
                      <div class="row mt-3">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Cash Amount</label>
                              <input type="text" class="form-control" id="cash_amount" name="cash_amount">
                           </div>
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Cheque Amount</label>
                              <input type="text" class="form-control" id="cheque_amount" name="cheque_amount">
                           </div>
                        </div>
                          <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Cheque No.</label>
                              <input type="text" class="form-control" id="cheque_no" name="cheque_no">
                           </div>
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Date</label>
                              <input type="date" class="form-control" id="advance_date" name="advance_date">
                           </div>
                        </div>
                     </div>
                     <div class="row mt-3">     
                        <div class="col-sm-12">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">In Words</label>
                              <input type="text" class="form-control" id="in_words" name="in_words">
                           </div>
                        </div>
                     </div>
                     <p class="mt-3" style="font-weight: bold;"><u>Final Payment Particulars</u></p> 
                      <div class="row mt-3">     
                        <div class="col-sm-6">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate Per Ton</label>
                              <input type="text" class="form-control" id="final_rate_per_ton" name="final_rate_per_ton">
                           </div>
                        </div>
                        <div class="col-sm-6">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Charge Wt.</label>
                              <input type="text" class="form-control" id="final_rate_charge_wt" name="final_rate_charge_wt">
                           </div>
                        </div>
                     </div>
                     <p class="mt-3" style="font-weight: bold;"><u>Payment Details</u></p> 
                      <div class="row mt-3">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Cash Amount</label>
                              <input type="text" class="form-control" id="payment_cash_amount" name="payment_cash_amount">
                           </div>
                        </div>
                         <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Cheque Amount</label>
                              <input type="text" class="form-control" id="payment_cheque_amount" name="payment_cheque_amount">
                           </div>
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Cheque No.</label>
                              <input type="text" class="form-control" id="payment_cheque_no" name="payment_cheque_no">
                           </div>
                        </div>
                         <div class="col-sm-3">     
                           <div class="form-group">
                              <label class="floating-label" for="Text">Date</label>
                              <input type="date" class="form-control" id="payment_date" name="payment_date">
                           </div>
                        </div>
                     </div>
                     <div class="row mt-3">     
                        <div class="col-sm-12">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">In Words</label>
                              <input type="text" class="form-control" id="payment_in_words" name="payment_in_words">
                           </div>
                        </div>
                     </div>    
                     <div class="row mt-5">     
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Lorry Hire</label>
                              <input type="text" class="form-control" id="lorry_hire" name="lorry_hire" value="Lorry Hire" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="lorry_amount_rs" name="lorry_amount_rs">
                           </div>
                        </div>
                     </div> 
                     <div class="row">     
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Other Amount</label>
                              <input type="text" class="form-control" id="other_amount" name="other_amount" value="Other Amount" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="other_amount_rs" name="other_amount_rs">
                           </div>
                        </div>
                     </div>  
                      <div class="row">     
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Total Amount</label>
                              <input type="text" class="form-control" id="total_amount" name="total_amount" value="Total Amount" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="total_amount_rs" name="total_amount_rs">
                           </div>
                        </div>
                     </div> 
                      <div class="row">     
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Adv. Amount</label>
                              <input type="text" class="form-control" id="net_amount" name="net_amount" value="Adv. Amount" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="adv_amount_rs" name="adv_amount_rs">
                           </div>
                        </div>
                     </div>
                     <div class="row">     
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Net Balance</label>
                              <input type="text" class="form-control" id="net_balance" name="net_balance" value="Net Balance" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="net_balance_rs" name="net_balance_rs">
                           </div>
                        </div>
                     </div>  
                      <div class="row mt-5">     
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Balance Amount</label>
                              <input type="text" class="form-control" id="balance_amount" name="balance_amount" value="Balance Amount" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="ab_balance_rs" name="ab_balance_rs">
                           </div>
                        </div>
                     </div>  
                     <div class="row">     
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Other Amount</label>
                              <input type="text" class="form-control" id="ab_other_amount" name="ab_other_amount" value="Other Amount" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="ab_other_amount" name="ab_other_amount">
                           </div>
                        </div>
                     </div>
                      <div class="row">     
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Total Amount</label>
                              <input type="text" class="form-control" id="ab_total_amount" name="ab_total_amount" value="Total Amount" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="ab_total_amount" name="ab_total_amount">
                           </div>
                        </div>
                     </div>  
                      <div class="row">     
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Deduction</label>
                              <input type="text" class="form-control" id="deduction" name="deduction" value="Deduction" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="deduction_amount" name="deduction_amount">
                           </div>
                        </div>
                     </div> 
                        <div class="row">      
                        <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Net Balance</label>
                              <input type="text" class="form-control" id="deduction" name="deduction_net_balance" value="Net Balance" readonly>
                           </div>
                        </div>
                         <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Amount Rs.</label>
                              <input type="text" class="form-control" id="net_deduction_amount" name="net_deduction_amount">
                           </div>
                        </div>
                     </div>  
                      <p class="mt-5" style="font-weight: bold;"><u>Enclose Paper</u></p> 
                      <div class="row mt-3">     
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">RC</label>
                              <input type="text" class="form-control" id="rc" name="rc">
                           </div>
                        </div>
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Insurance</label>
                              <input type="text" class="form-control" id="enclose_insurance" name="enclose_insurance">
                           </div>
                        </div>
                         <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Permit</label>
                              <input type="text" class="form-control" id="permit" name="permit">
                           </div>
                        </div>
                         <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Pan</label>
                              <input type="text" class="form-control" id="pan" name="pan">
                           </div>
                        </div>
                         <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Driver Lic</label>
                              <input type="text" class="form-control" id="driver_lic" name="driver_lic">
                           </div>
                        </div>
                     </div>
                     <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'staff';?>" class="btn btn-secondary me-md-2">BACK</a>
                        <button type="submit" name="submit_form" class="btn btn-primary">SAVE</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>