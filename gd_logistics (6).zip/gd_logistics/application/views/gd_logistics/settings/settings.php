 <!-- Content wrapper -->
 <div class="content-wrapper">              
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
                <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span>Company Settings</h4>      
              <div class="row">  
                <!-- Form controls --> 
                <div class="col-md-12">          
                  <div class="card mb-4">
                    <!-- <h5 class="card-header">Settings</h5> -->
                    <form method="POST" action="<?= base_url().'settings/update_settings/'.$info->id;?>" enctype="multipart/form-data">
                    <div class="card-body"> 
                    <input type="hidden" name="id" id="id" value="<?= $info->id;?>">
                    <div class="row">   
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Company Name</label>
                                        <input type="text" class="form-control" id="company_name" name="company_name"
                                         value="<?= $info->company_name;?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Email ID</label>
                                        <input type="email" class="form-control " id="email" name="email" value="<?= $info->email;?>">
                                    </div>
                                </div>  
                            </div>  
                            <div class="row mt-3">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Mobile Number</label>
                                        <input type="text" class="form-control " id="mobile_no" name="mobile_no"  minlength="10" maxlength="10" value="<?= $info->mobile_no;?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Website</label>
                                        <input type="text" class="form-control " id="website" name="website" value="<?= $info->website;?>"
                                          >
                                    </div>
                                </div> 
                            </div>

						<div class="row mt-3">
							<div class="col-sm-4">
								<div class="form-group">
									<label class="floating-label" for="Text">PAN</label>
									<input type="text" required class="form-control " id="mobile_no" name="pan_no"  minlength="10" maxlength="10" value="<?= $info->pan_no;?>">
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label class="floating-label" for="Text">GST</label>
									<input type="text" required class="form-control " id="website" name="gst_no" value="<?= $info->gst_no;?>"
									>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label class="floating-label" for="Text">CIN</label>
									<input type="text" class="form-control " id="website" name="cin_no" value="<?= $info->cin_no;?>"
									>
								</div>
							</div>
						</div>

                            <div class="row mt-3">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                         <label class="floating-label" for="Text">Address</label>
                                <textarea type="text" class="form-control" id="address " name="address"><?= $info->address;?></textarea>
                                    </div>
                                </div>
                                
                            </div>    
                            
                           
                            <div class="row mt-3" style="margin-left:1px;">
                                <div class="col-md-6">
                                <label class="floating-label" for="Text">Logo</label>
                                <div class="input-group cust-file-button ">
                                    <div class="custom-file">
                                        <label class="custom-file-label" for="inputGroupFile04">Choose file</label>
                                        <input type="file" class="form-control" id="logo" name="logo" onchange="document.getElementById('preview_profile_pic').src = window.URL.createObjectURL(this.files[0])" >  
                                    </div>
                                </div>  
                            </div>
                                    <div class="col-md-6">
                                        <label>Preview:</label> <br>
                                        <img src="<?= document_url('settings_logo/').$info->logo; ?>" id="preview_profile_pic" style="max-width:200px;max-height: 200px;">
                                    </div>
                                </div>
                            </div>
                                <div class="d-grid mt-3 gap-2 d-md-flex justify-content-md-end">
                                    <button class="btn btn-primary" name="submit_form" id="submit_form" type="submit">UPDATE</button>
                                </div>
                    </div>
                   </form>
                  </div>
                </div>
              </div>
            </div>
