<div class="content-wrapper">
   <div class="container-xxl flex-grow-1 container-p-y">
      <!-- Basic Layout -->
      <div class="row">
         <div class="col-xl">
            <div class="card mb-4">
               <div class="card-header d-flex justify-content-between align-items-center">
                  <h5 class="mb-0">Staff</h5>     
               </div>     
               <div class="card-body">
                  <form action="<?php echo base_url().'staff/update_staff/'.$info->id;?>" enctype="multipart/form-data" method="POST">
                     <div class="row">
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">First Name</label>
                              <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $info->first_name; ?>">
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Middle Name</label>
                              <input type="text" class="form-control" id="middle_name" name="middle_name" value="<?php echo $info->middle_name; ?>">
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Last Name</label>
                              <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $info->last_name; ?>">  
                           </div>
                        </div>
                     </div>
                     <div class="row mt-3">
                        <div class="col-sm-2">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Gender</label>
                              <select name="gender" id="gender"
                                             class="form-control form-control-alternative " value="<?php echo $info->gender;?>">
                                             <option>Select</option>
                                            <option value="Male" <?php if($info->gender == "Male"){ echo "selected";}?>>Male</option>
                                            <option value="Female" <?php if($info->gender == "Female"){ echo "selected";}?>>Female 
                                        </option>
                                         </select>
                           </div>
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Mobile No.</label>
                              <input type="text" class="form-control" id="mobile_no" name="mobile_no" minlength="10" maxlength="10"  value="<?php echo $info->mobile_no; ?>">
                           </div>
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Alternate Mobile No.(Home)</label>
                              <input type="text" class="form-control" id="alternate_mobile_no" name="alternate_mobile_no" minlength="10" maxlength="10" value="<?php echo $info->alternate_mobile_no; ?>">
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Email Id</label>
                              <input type="email" class="form-control" id="email" name="email" value="<?php echo $info->email; ?>">        
                           </div>
                        </div>
                     </div>
                     <div class="row mt-3">
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Aadhar No.</label>
                              <input type="text" class="form-control" id="aadhar_no" name="aadhar_no" value="<?php echo $info->aadhar_no; ?>">
                           </div>
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Pan No.</label>
                              <input type="text" class="form-control" id="pan_no" name="pan_no" minlength="10" maxlength="10" value="<?php echo $info->pan_no; ?>">
                           </div>
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Current Address</label>
                              <textarea type="text" class="form-control" id="address" name="address"><?php echo $info->address; ?></textarea>     
                           </div>
                        </div>
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Permnant Address</label>
                              <textarea type="text" class="form-control" id="permnant_address" name="permnant_address"><?php echo $info->permnant_address; ?></textarea>   
                           </div>
                        </div>
                     </div>
                     <div class="row mt-3">
                        <div class="col-md-6">
                           <label>Profile Attachment</label>
                           <input type="file" name="profile_pic" class="form-control dropzone" id="profile_pic" onchange="document.getElementById('preview_profile_pic').src = window.URL.createObjectURL(this.files[0])">    
                        </div>
                        <div class="col-md-6">
                           <label>Preview:</label> <br>
                            <img src="<?php echo document_url('staff_profile_pic/').$info->profile_pic; ?>" id="preview_profile_pic" style="max-width:200px;max-height: 200px;">
                        </div>
                     </div>
                     <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'staff';?>" class="btn btn-secondary me-md-2">BACK</a>
                        <button type="submit" name="submit_form" class="btn btn-primary">SAVE</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>