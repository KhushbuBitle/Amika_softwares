<?php $this->load->view('gd_logistics/template/headerscript'); ?>
<?php $this->load->view('gd_logistics/template/sidebar'); ?>
<?php $this->load->view('gd_logistics/template/topbar'); ?>
<?php $this->load->view('gd_logistics/staff/'.$page_name); ?>
<?php $this->load->view('gd_logistics/template/footerscript'); ?>  
