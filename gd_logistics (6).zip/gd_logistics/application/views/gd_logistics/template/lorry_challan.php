<!-- Content wrapper -->
<div class="content-wrapper">
<!-- Content -->
<div class="container-xxl flex-grow-1 container-p-y">
   <?php if(!empty($this->session->flashdata('success_message'))){ ?>
   <div class="row mt-3">
      <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
         <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
         </div>      
      </div>          
   </div>
   <?php } ?>
   <!-- Basic Bootstrap Table -->
   <div class="card">
      <div class="card-header">
         <div class="row">
            <div class="col-md-8 col-sm-8 col-xs-8 col-lg-8">
               <h5>Lorry Challan List</h5>
            </div>
            <div class="col-sm-4">
               <a href="<?php echo base_url().'admin/add_lorry_challan'; ?>"
                  class="btn btn-primary doctor_btn">Add Lorry Challan</a>
            </div>
         </div> 
      </div>
      <hr>
      <div class="table-responsive text-nowrap">
         <table class="table datatableid">
            <thead>
               <tr>
                  <th>SR.</th> 
                  <th>LH CONTRACT NO.</th> 
                  <th>LORRY NO.</th>
                  <th>LORRY OWNER</th>  
                  <th>LORRY OWNER MOB.</th>
                  <th>DRIVER</th>
                  <th>DRIVER MOB.</th>
                  <th>ACTION</th>    
               </tr>
            </thead>
            <tbody class="table-border-bottom-0">
               <?php if(!empty($lorry)){ $i=1; foreach($lorry as $key){?>
               <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $key->lorry_hire_contact_no;?></td>
                  <td><?php echo $key->lorry_no; ?></td>
                  <td><?php echo $key->owner_name; ?></td>
                  <td><?php echo $key->owner_mobile_no; ?></td>
                  <td><?php echo $key->driver_name; ?></td>
                  <td><?php echo $key->driver_mobile_no; ?></td>
                  <td>
                    
                       
                           <a class="btn btn-sm rounded-pill btn-warning" href="<?php echo base_url('admin/view_lorry_challan/'.$key->id); ?>"
                              ><i class='bx bx-street-view me-2'></i></i></a>
                           <a class="btn btn-sm rounded-pill btn-info" href="<?php echo base_url('admin/edit_lorry_challan/'.$key->id); ?>"
                              ><i class="bx bx-edit-alt me-2"></i></a>
                           <a class="btn btn-sm rounded-pill btn-danger" onclick='return checkdelete()' href="<?php echo base_url('admin/delete_lorry_challan/'.$key->id); ?>"
                              ><i class="bx bx-trash me-2"></i></a> 
                           
                  </td>  
               </tr>
               <?php $i++; } }else{ ?>
               <tr>
                  <td colspan="4" class="text-center text-xs">No Data Found</td>
               </tr>
               <?php }  ?>
            </tbody>
         </table>
      </div>
   </div>
   <!--/ Basic Bootstrap Table -->
</div>
<!-- / Content -->