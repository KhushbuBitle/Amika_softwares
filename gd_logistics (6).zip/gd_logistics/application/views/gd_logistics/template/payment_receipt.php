<!-- Content wrapper -->
<?php $CI =&get_instance(); ?>
<div class="content-wrapper">
<!-- Content -->
<div class="container-xxl flex-grow-1 container-p-y">
   <?php if(!empty($this->session->flashdata('success_message'))){ ?>
   <div class="row mt-3">
      <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
         <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
         </div>          
      </div>          
   </div>
   <?php } ?>
   <!-- Basic Bootstrap Table -->     
   <div class="card"> 
      <div class="card-header">
         <div class="row">
            <div class="col-md-8 col-sm-8 col-xs-8 col-lg-8">
               <h5>Payment Receipt</h5>
            </div>
            <div class="col-sm-4">
                <a href="<?php echo base_url().'admin/add_payment_receipt'; ?>"
                  class="btn btn-primary doctor_btn">Add Receipt</a> 
            </div>
         </div>
      </div>
      <hr>
      <div class="table-responsive text-nowrap">     
         <table class="table datatableid">  
            <thead>
               <tr>
                  <th>SR.NO.</th>
                  <th>Receipt No</th>
                  <th>Party Name</th>
                  <th>Bill No.</th>
                  <!-- <th>Net Amount</th> -->   
                  <!-- <th>STATUS</th> -->
                  <th>ACTION</th>      
               </tr>
            </thead>
            <tbody class="table-border-bottom-0">    
               <?php if(!empty($info)){ $i=1; foreach($info as $key){?>
               <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $key->receipt_no;?></td>  
                  <td>
                     <?php if($key->tbb_for == 'Consignor'){?>
                        <?php echo $CI->seees_customer_name('m_consignor_details',$key->owner_name);?>
                    <?php }else{ ?>
                        <?php echo $CI->seees_consignee_name('m_consignee_details',$key->owner_name);?>
                    <?php }   
                     ?>
                  </td>
                  <td><?php echo $key->bill_no; ?></td>    
                  <!-- <td><?php //echo $key->?></td> -->
                  <!-- <td><a href="" role="button" class="btn btn-primary btn-md doctor_btn" data-bs-toggle="modal" onclick="get_area('<?php echo $key->id;?>');">Add Consignor</a></td> -->
                  <td> 
                    
                        
                           <a class="btn btn-sm rounded-pill btn-warning" href="<?php echo base_url('admin/view_payment_receipt/'.$key->id); ?>"
                              ><i class='bx bx-street-view me-2'></i></i></a>
                            <a class="btn btn-sm rounded-pill btn-info" href="<?php echo base_url('admin/edit_payment_receipt/'.$key->id); ?>"
                              ><i class="bx bx-edit-alt me-2"></i></a> 
                           <a class="btn btn-sm rounded-pill btn-danger" onclick='return checkdelete()' href="<?php echo base_url('admin/delete_payment_receipt/'.$key->id); ?>"
                              ><i class="bx bx-trash me-2"></i></a>  
                         
                  </td>  
               </tr>
               <?php $i++; } }else{ ?>
               <tr>
                  <td colspan="4" class="text-center text-xs">No Data Found</td>
               </tr>
               <?php }  ?>
            </tbody>
         </table>
      </div>
   </div>
   <!--/ Basic Bootstrap Table --> 
</div>
<!-- / Content -->
<div class="modal modal-top fade" id="modaltop" role="dialog">
      <div class="modal-dialog modal-lg modal-content">
         <!-- <form class="modal-content" action="<?php //echo base_url().'master/consignor'; ?>" method="post"> -->
            <div class="modal-header">
               <h2>Payment Details</h2>
               <button type="button" class="btn-close" data-bs-dismiss="modal"
                  aria-label="Close"
                  ></button>
            </div>
            <hr style="border:1px solid grey;width:100%;background-color:grey;"/>
         <div id="payment_data">
      
         </div>
            <!-- <div class="modal-footer">
               <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
               Close
               </button> 
               <button type="submit" class="btn btn-primary" name="submit_form">Submit</button>
            </div> -->
         <!-- </form> -->
      </div>
   </div>  
   <script>
//Confirmed and reject fields showing
function changeSearchstatus(type){
      if (type == "Cash") {    
         document.getElementById('transaction_details').style.display = "none";
         document.getElementById('bank_details').style.display = "none";
         document.getElementById('cheque_no_details').style.display = "none";
         document.getElementById('date_details').style.display = "block";
        document.getElementById('amount_details').style.display = "block";
      }
      if (type == "Cash") {  
         document.getElementById('transaction_details').style.display = "none";
         document.getElementById('bank_details').style.display = "none";
         document.getElementById('cheque_no_details').style.display = "none";
        document.getElementById('date_details').style.display = "block";
        document.getElementById('amount_details').style.display = "block";
      }
       if (type == "Cheque") {  
         document.getElementById('transaction_details').style.display = "none";
         document.getElementById('bank_details').style.display = "block";
         document.getElementById('cheque_no_details').style.display = "block";
        document.getElementById('date_details').style.display = "block";
        document.getElementById('amount_details').style.display = "block";
      }  
      if (type == "Cheque"){
         document.getElementById('transaction_details').style.display = "none";
         document.getElementById('bank_details').style.display = "block";
         document.getElementById('cheque_no_details').style.display = "block";
        document.getElementById('date_details').style.display = "block";
        document.getElementById('amount_details').style.display = "block";
      }
      if (type == "Online") {
         document.getElementById('transaction_details').style.display = "block";
        document.getElementById('date_details').style.display = "block";
        document.getElementById('amount_details').style.display = "block";
        document.getElementById('bank_details').style.display = "none";
         document.getElementById('cheque_no_details').style.display = "none";
      }
      if (type == "Online") {  
         document.getElementById('transaction_details').style.display = "block";
        document.getElementById('date_details').style.display = "block";
        document.getElementById('amount_details').style.display = "block";
        document.getElementById('bank_details').style.display = "none";
         document.getElementById('cheque_no_details').style.display = "none";
      }
      if (type == "NEFT/RTGS") {
         document.getElementById('transaction_details').style.display = "block";
        document.getElementById('date_details').style.display = "block";
        document.getElementById('amount_details').style.display = "block";
        document.getElementById('bank_details').style.display = "none";
         document.getElementById('cheque_no_details').style.display = "none";
      }
      if (type == "NEFT/RTGS") {  
         document.getElementById('transaction_details').style.display = "block";
        document.getElementById('date_details').style.display = "block";
        document.getElementById('amount_details').style.display = "block";
        document.getElementById('bank_details').style.display = "none";
         document.getElementById('cheque_no_details').style.display = "none";
      }
   }
   </script>
   <script>  
   function get_area(id){
      clear(['id','invoice_id','mode_of_payment','date','amount','cheque_no','bank_name','transaction_no']);
          $("#modaltop").modal('show');
         var doctor_name_id =  id;
          $.ajax({
            type:"GET",
            url: '<?php echo base_url();?>admin/get_payment_data',
            data: {"id": doctor_name_id},
            dataType:'html',
            success: function(data){
              //  alert(data);
                $('#payment_data').html(data);   
            }
        });
   }
   function clear(elements) {
         var errors = 0;
         $.each(elements, function(index, element){
             $('#modaltop' + element).val('');
             errors++;
         });
     }
  </script>