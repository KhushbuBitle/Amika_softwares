<?php $CI =&get_instance(); ?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <?php if(!empty($this->session->flashdata('success_message'))){ ?>
        <div class="row mt-3">
            <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert"
                        aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
                </div>
            </div>
        </div> 
        <?php } ?>
        <!-- Basic Bootstrap Table -->
        <div class="card">
            <div class="card-header"></div>
            <div class="card-body">
                <div class="card-title">
                    <h4 class="text-center title-2">Lorry Hire Report</h4>
                </div>
                <form method="GET" name="my_form" action="<?php echo base_url().'admin/lorry_hire_payment_report';?>"
                    class="mt-3">
                    <div class="row">

                        <div class="col-4">
                            <div class="form-group">
                                <label for="cc-payment" class="control-label mb-1">Lorry Type</label>
                                <select name="name" id="name" class="form-select" value="<?php echo $_GET['name']; ?>">
                                    <option>Select</option>
                                    <option value="Advance" <?php if($_GET['name'] == "Advance"){ echo "selected";}?>>
                                        Advance</option>
                                    <option value="Lorry Hire Payment"
                                        <?php if($_GET['name'] == "Lorry Hire Payment"){ echo "selected";}?>>Lorry Hire
                                        Payment</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-2 mt-4">
                            <div class="form-group">
                                <input id="search_code" name="search_code" value="Search" type="submit"
                                    class="form-control" style="background-color: #696cff;color: white;">
                            </div>
                        </div>
                    </div>
                </form>
             </div>

            <!--/ Basic Bootstrap Table -->

            <!-- / Content -->
            <div class="row ">
                <div class="col-7">
                    <h4 class="mb-0"></h4>
                </div>
                <div class="col-5 text-right">
                    <button class="btn btn-animated from-top" style="background-color:#fc6e26; color:white;"
                        onClick="printdiv('print_character');"><span>PRINT</span></button>
                    <button type="submit" class="btn" style="background-color:#1e3d8d; color:white;"
                        data-toggle="tooltip" data-placement="bottom" title="Downlod in CSV"
                        onclick="download_csv('csv_download_table')" id="download_data">DOWNLOAD
                        CSV</button>
                    <input type="button" class="btn" value="Back" onclick="goBack()"
                        style="background-color: #fc6e26;color: white;">
                </div>
            </div>
            <div class="table-responsive p-4" id="print_character">
                <div class="ed border-dark">
                    <table width='100%' border='1' id="csv_download_table" class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th class="text-center">Sr.No.</th>
                                <th class="text-center">LORRY TYPE</th>
                                <th class="text-center">LH CONTRACT NO.</th>
                                <th class="text-center">LORRY NO.</th>
                                <th class="text-center">LORRY OWNER</th>
                                <th class="text-center">LORRY OWNER MOB.</th>
                                <th class="text-center">DRIVER</th>
                                <th class="text-center">DRIVER MOB.</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php   
                     if(!empty($report)){  
                        $i=1; foreach($report as $key){?>
                            <tr class="text-center">
                                <td class="text-center"><?php echo $i;?></td>
                                <td class="text-center"><?php echo $key->lorry_type;?></td>
                                <td class="text-center"><?php echo $key->lorry_hire_contact_no;?></td>
                                <td class="text-center"><?php echo $key->lorry_no;?></td>
                                <td class="text-center"><?php echo $key->owner_name; ?></td>
                                <td class="text-center"><?php echo $key->owner_mobile_no;?></td>
                                <td class="text-center"><?php echo $key->driver_name; ?></td>
                                <td class="text-center"><?php echo $key->driver_mobile_no; ?></td>
                            </tr>
                            <?php $i++; } }else{ ?> 
                            <tr>
                                <td colspan="10" class="text-center text-xs">No Data Found</td>
                            </tr>
                            <?php } ?>    
                        </tbody>
                    </table>
                </div>
            </div> 
        </div>
    </div>
</div>