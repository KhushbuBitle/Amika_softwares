<div class="content-wrapper">
   <div class="container-xxl flex-grow-1 container-p-y">
      <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span>Payment Receipt</h4>
      <!-- Basic Layout -->  
      <div class="row">
         <div class="col-xl">
            <div class="card mb-4">  
               <div class="card-header d-flex justify-content-between align-items-center">
                  <h5 class="mb-0">Payment Receipt</h5>  
               </div>   
               <div class="card-body">    
                  <form action="<?php echo base_url().'admin/update_payment_receipt/'.$info->id; ?>" enctype="multipart/form-data" method="POST">
                     <div class="row">
                     <?php $receipt_type = array('Customer Copy','File Copy'); ?>
                      <?php $payment_type = array('Full Payment','Partially Payment','Payment Done'); ?>    
                     <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">No.</label>
                              <input type="text" class="form-control" id="receipt_no" name="receipt_no" value="<?php echo $info->receipt_no; ?>" readonly>
                           </div>
                        </div>
                     <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">CNS No.</label>
                              <input type="text" class="form-control" id="vs_code" name="vs_code" value="<?php echo $info->vs_code; ?>" style="border:1px solid red;">
                           </div>
                        </div> 
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Receipt Type</label> 
                     <select name="receipt_type" id="receipt_type" class="form-select">
                     <option value="">Select</option>
                        <?php foreach ($receipt_type as $value) {?>
                        <option value="<?php echo $value; ?>" <?php if(@$info->receipt_type==$value){ echo 'selected';}?>> <?php echo $value; ?></option>
                        <?php } ?>
                     </select>
                           </div>         
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Date</label>
                              <input type="date" class="form-control" id="receipt_date" name="receipt_date" value="<?php echo $info->date; ?>">
                           </div>  
                        </div>  
                     </div>
                  <p class="mt-3" style="font-weight: bold;"><u>Money Receipt</u></p> 
                  <div class="row mt-3">       
                        <div class="col-sm-4">
                           <div class="form-group">
                              <?php if($invoice_details->tbb_for == 'Consignor'){ ?>
                              <label class="floating-label" for="Text">Customer Name</label>
                              <select name="owner_name" id="owner_name" class="select2 form-select">
                        <option value="">Select</option>
                        <?php if(!empty($company_name)){
                           foreach($company_name as $row){
                              if($info->owner_name==$row['id']){$s="selected";}else{$s="";}?>
                        <option value="<?php echo $row['id'];?>" <?php echo $s;?>>
                           <?php echo $row['customer_name'];?> 
                        </option>
                        <?php } } ?>   
                     </select>
                     <?php }else{ ?>
                        <select name="owner_name" id="owner_name" class="select2 form-select">
                        <option value="">Select</option>
                        <?php if(!empty($company)){
                           foreach($company as $row){
                              if($info->owner_name==$row['id']){$s="selected";}else{$s="";}?>
                        <option value="<?php echo $row['id'];?>" <?php echo $s;?>>
                           <?php echo $row['company_name'];?>
                        </option>
                        <?php } } ?>     
                     </select>

                        <?php } ?>
                           </div> 
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Customer Address</label>
                              <textarea type="text" class="form-control" id="customer_address" name="customer_address"><?php echo $info->customer_address; ?></textarea>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST No.</label>
                              <input type="text" class="form-control" id="gst_no" name="gst_no" value="<?php echo $info->gst_no; ?>">
                           </div>
                        </div> 
                     </div>  
                      <div class="row mt-3">       
                      <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">From(City,State)</label>
                              <input type="text" class="form-control" id="from_payment_receipt" name="from_payment_receipt" value="<?php echo $info->from_payment_receipt; ?>">  
                           </div>   
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">To(City,State)</label>
                              <input type="text" class="form-control" id="to_payment_receipt" name="to_payment_receipt" value="<?php echo $info->to_payment_receipt; ?>" style="border-color:red;">
                           </div>    
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Date</label>
                              <input type="date" class="form-control" id="date" name="date" value="<?php echo $info->date; ?>">
                           </div>
                        </div>  
                     </div>
                     <div class="row mt-3">
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Weight</label>
                              <input type="text" class="form-control" id="wt" name="wt" value="<?php echo $info->wt; ?>">
                           </div>
                        </div>  
                         <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Package</label>
                              <input type="text" class="form-control" id="package" name="package" value="<?php echo $info->package; ?>">
                           </div>
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Bill No./Freight Bill</label>
                              <input type="text" class="form-control" id="bill_no" name="bill_no" value="<?php echo $info->bill_no; ?>" style="border-color:red;">
                           </div>
                        </div> 
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Date</label>
                              <input type="date" class="form-control" id="bill_date" name="bill_date" value="<?php echo $info->bill_date; ?>">
                           </div> 
                        </div>   
                     </div>
                     <div class="row mt-3">
                      <div class="col-sm-2">    
                           <div class="form-group">
                              <label class="floating-label" for="Text">Cash</label>
                              <input type="text" class="form-control" id="cash" name="cash" value="<?php echo $info->cash; ?>">
                           </div>
                        </div> 
                        <div class="col-sm-2">    
                           <div class="form-group">
                              <label class="floating-label" for="Text">Cheque</label>
                              <input type="text" class="form-control" id="cheque" name="cheque" value="<?php echo $info->cheque; ?>">
                           </div>
                        </div> 
                        <div class="col-sm-3">    
                           <div class="form-group">
                              <label class="floating-label" for="Text">RTGS</label>
                              <input type="text" class="form-control" id="rtgs" name="rtgs" value="<?php echo $info->rtgs; ?>">
                           </div>
                        </div> 
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Date</label>
                              <input type="date" class="form-control" id="bb_date" name="bb_date" value="<?php echo $info->bb_date; ?>">
                           </div>
                        </div>  
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Bank Name</label>
                              <input type="text" class="form-control" id="bank_name" name="bank_name" value="<?php echo $info->bank_name; ?>">
                           </div> 
                        </div>     
                     </div>
                     <div class="row mt-3">
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Mode Of Payment</label>
                                <select name="payment_type" id="payment_type" class="form-select">  
                        <option value="">Select</option>
                        <?php foreach ($payment_type as $value) {?>
                        <option value="<?php echo $value; ?>" <?php if(@$info->payment_type==$value){ echo 'selected';}?>> <?php echo $value; ?></option>  
                        <?php } ?>
                     </select>
                           </div>    
                        </div>    
                     </div>
                      <div class="row mt-2">
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="freight" name="freight" value="Freight" readonly>
                           </div>
                        </div>      
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="payment_rs_one" name="payment_rs_one" placeholder="Rs." value="<?php echo $info->payment_rs_one; ?>" style="border-color:red;">
                           </div>
                        </div> 
                     </div>
                     <div class="row">
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="freight" name="freight" value="Hamali Charge" readonly>
                           </div>
                        </div>      
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="payment_rs_two" name="payment_rs_two" placeholder="Rs." value="<?php echo $info->payment_rs_two; ?>">
                           </div>
                        </div> 
                     </div>
                     <div class="row">
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="d_del_charge" name="d_del_charge" value="D.Del.Charge" readonly>
                           </div>
                        </div>      
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="payment_rs_three" name="payment_rs_three" placeholder="Rs." value="<?php echo $info->payment_rs_one; ?>">
                           </div>
                        </div> 
                     </div>
                    
                    
                     <div class="row">  
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="bill_amount" name="bill_amount" value="Bill Amount" readonly>
                           </div>
                        </div>      
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="payment_rs_four" name="payment_rs_four" placeholder="Rs." value="<?php echo $info->payment_rs_four; ?>" style="border-color:red;">
                           </div> 
                        </div>
                      </div> 
                      <div class="row">
                        <div class="col-sm-2">     
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="tds" name="tds" value="TDS" readonly>
                           </div>
                        </div>      
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="payment_rs_five" name="payment_rs_five" placeholder="Rs." value="<?php echo $info->payment_rs_five; ?>">
                           </div>
                        </div> 
                     </div>
                     <div class="row">
                        <div class="col-sm-2">     
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="net_amount" name="net_amount" value="Net Amount" readonly>
                           </div>
                        </div>      
                        <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="payment_rs_six" name="payment_rs_six" placeholder="Rs." value="<?php echo $info->payment_rs_six; ?>" style="border-color:red;">
                           </div>
                        </div> 
                     </div>
                     
                           
                     <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'admin/payment_receipt';?>" class="btn btn-secondary me-md-2">BACK</a>
                        <button type="submit" name="submit_form" class="btn btn-primary">Update</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<script>
$('#payment_rs_four').click(function(){
   var a = parseInt($('#payment_rs_one').val());
   var b = parseInt($('#payment_rs_two').val());
   var c = parseInt($('#payment_rs_three').val());
   $('#payment_rs_four').val(a + b + c);
   
})
</script>
<script>
$('#payment_rs_six').click(function(){
   var a = parseInt($('#payment_rs_four').val());
   var b = parseInt($('#payment_rs_five').val());
   $('#payment_rs_six').val(a - b);
   
})
</script>
<script type="text/javascript">              
   /*auto fill form*/  
   $("#vs_code").change(function() {
      var vs_code  = $("#vs_code").val();
      var controller_name = '<?php echo $controller_name; ?>';
      var type = 'vs_code';   
      $.ajax({
           type: "POST",
           url: '<?php echo base_url($controller_name.'/get_bilti_data_payment');?>',
           data:{vs_code:vs_code,type:type},
           success: function(response){
           var data = JSON.parse(response); 
           if(typeof data === 'object' && data !== null){
             $('#party_name').val(data.consignor_company_name);
             $('#from_payment_receipt').val(data.from_bilti); 
             $('#to_payment_receipt').val(data.to_bilti);
             $('#date').val(data.con_date);
             $('#package').val(data.packages);  
             $('#wt').val(data.charge_wt);          
            }     
      }});  
   });
</script>          
<script type="text/javascript">               
   /*auto fill form*/  
   $("#bill_no").change(function() {
      var bill_no  = $("#bill_no").val();
      //alert(bill_no);
      var controller_name = '<?php echo $controller_name; ?>';
      var type = 'bill_no';    
      $.ajax({
           type: "POST",
           url: '<?php echo base_url($controller_name.'/get_invoice_bill_data');?>',
           data:{bill_no:bill_no,type:type},
           success: function(response){
           var data = JSON.parse(response); 
           if(typeof data === 'object' && data !== null){ 
             $('#bill_date').val(data.invoice_bill_date);       
                     
            }     
      }});
   });
</script>       

