<!DOCTYPE html>
<html
  lang="en"
  class="light-style customizer-hide"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
    <title>Shipment & Container Tracking</title>  
    <meta name="description" content="" />
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />
    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/css/pages/page-auth.css" />
    <!-- Helpers -->
    <script src="<?php echo base_url();?>assets/vendor/js/helpers.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <style>
table, th, td {
  border: 1px solid gray !important;  
}
</style>
  </head>
 <body style="background-image: url('<?php echo base_url(); ?>assets/img/tracking_bg.jpg');background-size:cover; height:auto; width:100%;">         
    <div class="container-fluid">
      <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner" style="max-width:1000px;">
          <div class="card">
            <div class="card-body">  
                <h3 style="text-align:center;color:#f88502;" class="text-uppercase">Guru Drashti Logistics Pvt.Ltd.</h3> 
                <hr>
			  <?php 
                        $msg = $this->session->flashdata('msg');
                        if($msg != "") {
                        ?> 
                     <div class="alert alert-success alert-dismissible">
                       <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
                        <?php echo $msg; ?> 
                     </div>
                     <?php
                        }
            ?>
                <br>
                <table width='100%' id="csv_download_table" class="table">
               <thead class="thead-light">
                  <tr>
                     <td colspan="15">
                        <center>
                        <h4>Tracking</h4>     
                     </td> 
                  </tr>
                  <tr class="text-center">
                     <th class="text-center">Date</th>
                     <th class="text-center">Time</th>
                     <th class="text-center">Lorry No</th>
                     <th class="text-center">From</th>
                     <th class="text-center">To</th>
                     <th class="text-center" style="color:red">Current Status</th> 
                   
                     
                  </tr>        
               </thead>                            
               <tbody>        
                  <?php   
                     if(!empty($report)){   
                        $i=1; foreach($report as $key){?>
                  <tr> 
                     <td class="text-center"><?php 
                        if(date('d-m-Y',strtotime($key->consignment_date)) == "01-01-1970"){  
                           echo "";
                        }else{
                        echo date('d-m-Y',strtotime($key->consignment_date)); 
                        }?></td>
                     <td class="text-center"><?php echo $key->consignment_time; ?></td>
                     <td class="text-center"><?php echo $key->lorry_no; ?></td>
                     <td class="text-center"><?php echo $key->consignment_from; ?></td>
                     <td class="text-center"><?php echo $key->consignment_to; ?></td>
                     <td class="text-center"><?php echo $key->consignment_status; ?></td>
                     
                   
                     
                    
                  </tr>
                 
                 

                  <?php $i++; } }else{ ?>              
                  <tr>
                     <td colspan="10" class="text-center text-xs">No Data Found</td>
                  </tr>
                  <?php } ?> 
                
                 
               </tbody>
            </table>
<br>
              <p class="text-center">
			  <a href="https://amikasoftwares.com/" style="font-size:13px; color:">Designed & Developed by Amika Softwares</a>
              </p>
            </div>   
          </div>
        </div> 
      </div>
    </div>
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo base_url();?>assets/vendor/libs/jquery/jquery.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/libs/popper/popper.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/js/bootstrap.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="<?php echo base_url();?>assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="<?php echo base_url();?>assets/js/main.js"></script>
    <!-- Page JS -->
    <!-- Place this tag in your head or just before your close body tag. -->
    <!-- <script async defer src="https://buttons.github.io/buttons.js"></script> -->
  </body>
</html>
