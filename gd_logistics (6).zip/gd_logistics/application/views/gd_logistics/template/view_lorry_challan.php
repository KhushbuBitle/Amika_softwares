<?php $CI =&get_instance(); ?>
<style type="text/css">
   .radio-group {
  padding-left: 10px;
  margin-top: 10px;
  margin-bottom: 20px;
}
.radio-group label::after {
  content:'\00a0\00a0\00a0\00a0'; /* eq &nbsp; x 4 */
}
.hrBorder{
   margin: 0px !important;       
}
.hr-line {
    position: relative;
    display: inline-block;
    margin-left: 5px;
    margin-right: 5px;
    width: 100%;
    border-bottom: 1px solid #7A7A7A;
}
</style>   
<div class="content-wrapper">  
   <div class="container-xxl flex-grow-1 container-p-y">
       <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span>Lorry Challan</h4>
      <!-- Basic Layout -->           
      <div class="row">   
         <div class="col-xl">  
            <div class="card mb-4"> 
              <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'admin/lorry_challan';?>" class="btn btn-secondary me-md-2">BACK</a>
                        
                     </div>
            <form method="POST" action="<?php echo base_url().'prescription/receipt';?>" id="print_character">    
               <div class="card-body">   
               <div  style="height:90%;"> 
             <table  class="table table-bordered">          
                <tbody>    
                  <tr>
                <td class="abc" colspan="6">

                                                <div class="row">
                                                    <div class="col-3">
                                                        <img src="<?php echo document_url('settings_logo/').$info_one->logo; ?>"
                                                            width="75%" height="75%" style="margin-right:40%;text-align:center;">
                                                    </div>
                                                    <div class="col-9 mt-4">
                                                        <span class="text-center text-uppercase"
                                                            style="font-size:20px;color:red;font-weight:bold;"><b>
                                                                <center><?php echo $info_one->company_name; ?></center>
                                                            </b></span>
                                                        <h6 class="text-center" style="font-size:14px;">
                                                            <?php echo $info_one->address; ?><br>
                                                            <span class="text-center" style="font-size:13px;">Mobile :
                                                                <?php echo $info_one->mobile_no; ?></span> &nbsp;&nbsp;
                                                            <span class="text-center" style="font-size:13px;">Email :
                                                                <?php echo $info_one->email; ?> </span>
                                                        </h6>
                                                    </div>


                                                </div> 

                                            </td> 
                 <td colspan="6">  
                 <span class="text-center" style="color:red;"><b>Lorry Hire Contract No. :</span><span style="font-size:13px;color:red;"> <?php echo $lorry->lorry_hire_contact_no; ?></span></b> <br>
                  <span><strong>Date</strong></span> <span><?php 
                        if(date('d-m-Y',strtotime($lorry->lorry_hire_date)) == "01-01-1970"){  
                           echo "";
                        }else{
                        echo date('d-m-Y',strtotime($lorry->lorry_hire_date));   
                        }?></span>  
                  </td>
                  </tr>
                <tr>
                <td class="abc" colspan="3">From : <?php echo $lorry->from_lorry; ?></span>
                </td>
                <td colspan="3"><strong>Lorry No.</strong></td>
                 <td colspan="1"><strong>Challan No.</strong></td>
                  <td colspan="2"><strong>CNS No.</strong></td>
                  <td colspan="1"><strong>Pkg.</strong></td>
                  <td colspan="1"><strong>Act.Wt.</strong></td>
                   <td colspan="1"><strong>Charge Wt.</strong></td>
               
                </tr>
                 <tr>
                <td class="abc" colspan="3">To : <?php echo $lorry->to_lorry; ?></span>
                </td>
                <td colspan="3"><?php echo $lorry->lorry_no; ?></td>
                 <td colspan="1"><?php echo $lorry->challan_no; ?></td>
                  <td colspan="2"><?php echo $lorry->vs_code; ?></td>
                  <td colspan="1"><?php echo $lorry->package; ?></td>
                  <td colspan="1"><?php echo $lorry->actual_weight; ?></td>
                   <td colspan="1"><?php echo $lorry->charge_weight; ?></td>
               
                </tr> 
                <tr class="text-right">  
                <td colspan="4"><h6 style="text-align:center;font-weight:bold;">Owner Detail</h6>
                <span style="font-weight:bold;">Name  : </span><span><?php echo $lorry->owner_name; ?></span><br> 
                <span style="font-weight:bold;">Mobile No.  : </span><span><?php echo $lorry->owner_mobile_no; ?></span><br>
                <span style="font-weight:bold;">Alternate Mob. No.  :</span></span><?php echo $lorry->owner_alt_mobile_no; ?></span><br>
                <span style="font-weight:bold;">Address  : </span><span><?php echo $lorry->owner_address; ?></span>    
                
                </td> 
                 <td colspan="4"><h6 style="text-align:center;font-weight:bold;">Driver Detail</h6>
                   <span style="font-weight:bold;">Name :</span><span><?php echo $lorry->driver_name; ?></span><br>
                <span style="font-weight:bold;">Mobile No. :</span><span><?php echo $lorry->driver_mobile_no; ?></span><br>
                <span style="font-weight:bold;">Alternate Mob. No. :</span><span><?php echo $lorry->driver_alt_mobile_no; ?></span><br>
                <span style="font-weight:bold;">Address :</span><span><?php echo $lorry->driver_address; ?></span>
                   </td>
                  <td colspan="4"><h6 style="text-align:center;">Broker Detail</h6>
                    <span style="font-weight:bold;">Name : </span><span><?php echo $CI->seees_broker_name('m_broker_details',$lorry->broker_name);?></span><br>
                    <span style="font-weight:bold;">Mobile No. :</span><span><?php echo $lorry->broker_mobile_no; ?></span><br>
                    <span style="font-weight:bold;">Alternate Mob. No. :</span><span><?php echo $lorry->broker_alt_mobile_no; ?></span><br>
                    <span style="font-weight:bold;">Address : </span><span><?php echo $lorry->broker_address; ?></span>
                    </td> 
               
                </tr>
                 <tr class="text-center">
                  <td colspan="8"><b>Hire Particulars</b></td>
                  <!-- <td colspan="2"></td> -->
                   <td colspan="4">
                   <strong>Amount Rs.</strong><br>
                  </td>
                </tr>
                 <tr>  
                 <td colspan="2"><strong>Rate Per Ton</strong></td>
                 <td colspan="2"><?php echo $lorry->rate_per_ton; ?></td>
                 <td colspan="2"><strong>Charge Wt.</strong></td> 
                 <td colspan="2"><?php echo $lorry->hire_charge_wt; ?></td> 
                 <td colspan="3"><strong>Lorry Hire</strong></td>  
                 <td colspan="1"> <?php echo $lorry->lorry_amount_rs; ?></td>  
                </tr>

                <tr class="text-center"> 
                  <td colspan="8"><b>Advance Detail</b></td>
                   <td colspan="3" style="text-align:left;"><strong>Other Amount</strong></td>
                   <td colspan="1"><?php echo $lorry->other_amount_rs;?></td>
                </tr>
                 <tr>
                 <td colspan="2"><strong>Cash Amt.</strong></td>
                 <td colspan="1"><strong>Cheque Amt.</strong></td>
                 <td colspan="3"><strong>Cheque No.</strong></td> 
                 <td colspan="2"><strong>Date</strong></td>
                 <td colspan="3"><strong>Total Amount</strong></td> 
                 <td colspan="1"><?php echo $lorry->total_amount_rs;?></td>  
                </tr> 
                <tr>
                 <td colspan="2"><?php echo $lorry->cash_amount; ?></td> 
                 <td colspan="1"><?php echo $lorry->cheque_amount; ?></td>
                 <td colspan="3"><?php echo $lorry->cheque_no; ?></td> 
                 <td colspan="2"><?php 
                        if(date('d-m-Y',strtotime($lorry->advance_date)) == "01-01-1970"){  
                           echo "";
                        }else{
                        echo date('d-m-Y',strtotime($lorry->advance_date));   
                        }?></td> 
                  <td colspan="3"><strong>Adv. Amount</strong></td> 
                  <td colspan="1"><?php echo $lorry->adv_amount_rs; ?></td>    
                </tr>
                <tr>
                <td colspan="8"><strong>In Words: <?php
                           $number = $lorry->net_balance_rs;   
                              $no = floor($number);
                              $point = round($number - $no, 2) * 100;  
                              $hundred = null;
                              $digits_1 = strlen($no);
                              $i = 0;
                              $str = array();
                              $words = array('0' => '', '1' => 'One', '2' => 'Two',
                               '3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
                               '7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
                               '10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
                               '13' => 'Thirteen', '14' => 'Fourteen',
                               '15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
                               '18' => 'Eighteen', '19' =>'Ninteen', '20' => 'Twenty',
                               '30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
                               '60' => 'Sixty', '70' => 'Seventy',
                               '80' => 'Eighty', '90' => 'Ninty'); 
                              $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
                              while ($i < $digits_1) {
                                $divider = ($i == 2) ? 10 : 100;
                                $number = floor($no % $divider);
                                $no = floor($no / $divider);
                                $i += ($divider == 10) ? 1 : 2;
                                if ($number) {
                                   $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                                   $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                                   $str [] = ($number < 21) ? $words[$number] .
                                       " " . $digits[$counter] . $plural . " " . $hundred
                                       :
                                       $words[floor($number / 10) * 10]
                                       . " " . $words[$number % 10] . " "
                                       . $digits[$counter] . $plural . " " . $hundred;
                                } else $str[] = null;
                             }
                             $str = array_reverse($str);  
                             $result = implode('', $str);
                             $points = ($point) ?
                               "." . $words[$point / 10] . " " . 
                                     $words[$point = $point % 10] : '';  
                             echo $result . "Only";
                            ?></strong></td>
                  <!-- <td colspan="8"><strong>In Words:</strong></td>           -->
                  <td colspan="3"><strong>Net Balance</strong></td>
                  <td colspan="1"><?php echo $lorry->net_balance_rs;?></td>
                 
                </tr>

                 <tr class="text-center">
                  <td colspan="8"><b>Lorry Hire Balance / Payment</b></td>
                   <td colspan="4"><strong>Amount Rs.</strong></td>
                </tr>
                 <tr>
                 <td colspan="8"></td>
                 <td colspan="3"><strong>Net Balance</strong></td> 
                 <td colspan="1"> <?php echo $lorry->net_balance_rs; ?></td>   
                </tr>

                 <tr class="text-center">
                  <td colspan="8"><b>Payment Details</b></td> 
                  <td colspan="3" style="text-align:left;">
                  <strong>Other Amount</strong><br>
                  </td>
                   <td colspan="1">
                  <span><?php echo $lorry->qq_total_amount; ?></span><br>
                  </td>
                </tr> 
                 <tr>
                 <td colspan="2"><strong>Cash Amt.</strong></td>
                 <td colspan="2"><strong>Cheque Amt.</strong></td>
                 <td colspan="2"><strong>Cheque No.</strong></td> 
                 <td colspan="2"><strong>Date</strong></td>  
                 <td colspan="3"><strong>Total Amount</strong></td> 
                 <td colspan="1"><?php echo $lorry->ab_total_amount; ?> </td>
                </tr>
                 <tr>
                 <td colspan="2"><?php echo $lorry->payment_cash_amount; ?></td>
                 <td colspan="2"><?php echo $lorry->payment_cheque_amount; ?></td>
                 <td colspan="2"><?php echo $lorry->payment_cheque_no; ?></td>
                 <td colspan="2"><?php 
                        if(date('d-m-Y',strtotime($lorry->payment_date)) == "01-01-1970"){  
                           echo "";
                        }else{
                        echo date('d-m-Y',strtotime($lorry->payment_date));   
                        }?></td>
                 <td colspan="3"><strong>Deduction</strong></td> 
                 <td colspan="1"><?php echo $lorry->deduction_amount; ?></td>         
                </tr>
                <tr>
                <td colspan="8"><strong>In Words: <?php
                           $number = $lorry->deduction_amount; 
                              $no = floor($number);
                              $point = round($number - $no, 2) * 100;  
                              $hundred = null;
                              $digits_1 = strlen($no);
                              $i = 0;
                              $str = array();
                              $words = array('0' => '', '1' => 'One', '2' => 'Two',
                               '3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
                               '7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
                               '10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
                               '13' => 'Thirteen', '14' => 'Fourteen',
                               '15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
                               '18' => 'Eighteen', '19' =>'Nineteen', '20' => 'Twenty',
                               '30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
                               '60' => 'Sixty', '70' => 'Seventy',
                               '80' => 'Eighty', '90' => 'Ninety');
                              $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
                              while ($i < $digits_1) {
                                $divider = ($i == 2) ? 10 : 100;
                                $number = floor($no % $divider);
                                $no = floor($no / $divider);
                                $i += ($divider == 10) ? 1 : 2;
                                if ($number) {
                                   $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                                   $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                                   $str [] = ($number < 21) ? $words[$number] .
                                       " " . $digits[$counter] . $plural . " " . $hundred
                                       :
                                       $words[floor($number / 10) * 10]
                                       . " " . $words[$number % 10] . " "
                                       . $digits[$counter] . $plural . " " . $hundred;
                                } else $str[] = null;
                             }
                             $str = array_reverse($str);  
                             $result = implode('', $str);
                             $points = ($point) ?
                               "." . $words[$point / 10] . " " . 
                                     $words[$point = $point % 10] : '';  
                             echo $result . "Only";
                            ?></strong></td>
                   <!-- <td colspan="8"><strong>In Words:</strong></td> -->
                   <td colspan="3"><strong>Net Balance</strong></td>  
                   <td colspan="1"><?php echo $lorry->net_deduction_amount; ?></td>  
                </tr>
                <tr class="text-center">  
                  <td colspan="12"><b>Enclose Paper</b></td>
                </tr>
                <tr>
                 <td colspan="2"><strong>RC</strong> : <?php echo $lorry->rc; ?></td>
                 <td colspan="3"><strong>Insurance</strong> : <?php echo $lorry->enclose_insurance; ?></td> 
                 <td colspan="2"><strong>Permit</strong> : <?php echo $lorry->permit; ?></td> 
                 <td colspan="3"><strong>PAN</strong> : <?php echo $lorry->pan; ?></td>  
                  <td colspan="2"><strong>Driver Lic.</strong> : <?php echo $lorry->driver_lic; ?></td>  
                </tr>
                <tr>
                  <td colspan="12">
<span style="font-size:11px;"><b>नोट / INSTRUCTIONS :<b></span><br>

<span style="font-size:10px;" >1. Modvate (Duplicate for Duplfcate for Transporter) Copy of Invoice वाहन चालक को दिया है |</span><br>
<span style="font-size:10px;">2. Road Permit Form No. ...........................वाहन चालक को दिया है |</span><br>
<span style="font-size:10px;">3.   वाहन गंतव्य स्थान पर दिनांक ................. तक पहुंचना चाहिए नहीं तो रु. 500 /-  प्रति दिन काटेंगे
  Lorry should reach at destination on orbefore ........................... otherwise penality Rs.500/-per day will be deducted.</span><br>
<span style="font-size:10px;">4.   माल डिलवरी कि पहुंच हमारे ऑफिस नागपुर Despatch date से 15  दिन तक जमा कराएं नही तो रु. 50/-  प्रति दिन कटेंगे |</span><br>
<span style="font-size:10px;">Delivery Receipt should be submit to our office at Nagpur before 15 days from despatch date otherwise Rs.50/-per day will be deduct.</span></td>
                </tr>
      <tr>
        <td colspan="12">
          <span style="font-size:11px;"><b>DECLARATION :</b></span> 
          <p style="text-align:justify;font-size:10px;">I/We received all goods written above intect and sound in good condition and do hereby agree to hold the owner & on driver jointly and severly responsible to take the goods quite safety at destination shortages & damage of goods due to any cause what so ever will be treated as criminal breach of trust. I/We will be responsible to obey octroi rules and regulation on the way and destination. While carrying the above mentioned goods.<br><b>Received the goods as per terms and conditions printed & hand written above. The terms have been explained to me/us :</b></p>
          <p style="font-size:10px;"><b>Name</b></p>
          <span style="font-size:10px;"><b>Driver's/ Owner's or Agent Signature</b></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:red;"><b><?php echo $lorry->lorry_type; ?><b></span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   <span><b>Despatch-in-charge</b></span>
        </td>  
      </tr>
                </tbody> 
                 </table> 
               </div> 
               </div>
               </form>
                <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'admin/lorry_challan';?>" class="btn btn-secondary me-md-2">BACK</a>
                        
                     </div>
              <center>
                     <button class="btn btn-primary txt-white btn-animated from-top" onClick="printdiv('print_character');" ><span>PRINT</span></button>
                  </center>
            </div>
         </div>
      </div>
   </div>
</div>