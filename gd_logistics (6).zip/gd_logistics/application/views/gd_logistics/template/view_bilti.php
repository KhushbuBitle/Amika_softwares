<style type="text/css">
.radio-group {
    padding-left: 10px;
    margin-top: 10px;
    margin-bottom: 20px;
}

.radio-group label::after {
    content: '\00a0\00a0\00a0\00a0';
    /* eq &nbsp; x 4 */
}

.hrBorder {
    margin: 0px !important;
}

.hr-line {
    position: relative;
    display: inline-block;
    margin-left: 5px;
    margin-right: 5px;
    width: 100%;
    border-bottom: 1px solid #7A7A7A;
}

.table th {
    letter-spacing: 0px !important;
}
</style>
<?php $CI =&get_instance(); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span>Bilti</h4>
        <!-- Basic Layout -->
        <div class="row">
            <div class="col-xl">

                <div class="card mb-4">
                    <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'admin/bilti';?>" class="btn btn-secondary me-md-2">BACK</a>

                    </div>
                    <form id="print_character">
                        <div class="card-body">      
                            <div class="ed border-dark">
                                <table class="table table-bordered">   
                                    <tbody>   
                                        <tr>  
                                            <td class="abc" colspan="6">    

                                                <div class="row">
                                                    <div class="col-3">
                                                        <img src="<?php echo document_url('settings_logo/').$info_one->logo; ?>"
                                                            width="130px" height="130px" style="margin-right:40%;text-align:center;">
                                                    </div>
                                                    <div class="col-9 mt-4">
                                                        <span class="text-center text-uppercase"
                                                            style="font-size:20px;color:red;font-weight:bold;"><b>
                                                                <center><?php echo $info_one->company_name; ?></center>
                                                            </b></span>
                                                        <h6 class="text-center" style="font-size:14px;">
                                                            <?php echo $info_one->address; ?><br><br>
                                                            <span class="text-center" style="font-size:13px;">Mobile :
                                                                <?php echo $info_one->mobile_no; ?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
                                                            <span class="text-center" style="font-size:13px;">Email :
                                                                <?php echo $info_one->email; ?> </span>
                                                                

                                                               
                                                        </h6>
                                                    </div>


                                                </div> 

                                            </td> 
                                            <td colspan="3">
                                                <h6 class="text-center hr-line" style="padding-bottom:10px;">
                                                    <b>Consignment Note No. </b><br></h6>
                                                <span style="color:red;"><strong>VS : &nbsp;
                                                        <?php echo $bilti->vs_code; ?></strong> </span>&nbsp;&nbsp;
                                                <span><strong>Date : &nbsp; <span><?php 
                        if(date('d-m-Y',strtotime($bilti->con_date)) == "01-01-1970"){  
                           echo "";
                        }else{
                        echo date('d-m-Y',strtotime($bilti->con_date));  
                        }?></span>
                                                    </strong><br><br>

                                                    <strong>GST NO :</strong> <span> <?php echo $info_one->gst_no; ?></span>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="abc" colspan="3">
                                                <strong>Load Type:</strong>
                                                <span><?php echo $bilti->load_type; ?></span>
                                            </td>
                                            <td colspan="3"><strong>At Owner's Risk</strong></td>
                                            <td class="abc" colspan="3">
                                                <strong>PAN NO. &nbsp;&nbsp;: &nbsp;&nbsp;</strong>
                                                <span><?php echo $bilti->con_pan_no;?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">
                                                <strong>Insurance Company:</strong>
                                                <span><?php echo $bilti->insurance_company?></span>
                                            </td>
                                            <td class="right" colspan="3">
                                                <strong>Policy No.:</strong>
                                                <span><?php echo $bilti->policy_no; ?></span>
                                            </td>
                                            <td class="right" colspan="3">  
                                                <strong>CIN NO.:</strong>
                                                <span><?php echo $bilti->con_gst_no; ?></span>
                                            </td>
                                        </tr>
                                        <tr>  
                                            <td colspan="3">
                                               
                                                <strong>From:</strong><br>
                                                <?php if($bilti->from_bilti == 'Nagpur'){ ?>
                                                    <span><?php echo $bilti->from_address; ?></span>
                                                <?php }else{ ?>
                                                    <span><?php echo $bilti->from_address_indore; ?></span>
                                                    <?php } ?>
                                                <hr>
                                               
                                            </td>
                                            <td colspan="3">
                                                <strong>To:</strong>
                                                <span><?php echo $bilti->to_bilti; ?></span><br><br>
                                                <hr>
                                                <?php if($bilti->door_dilivery == 'Yes') {?>
                                                <span><?php echo $bilti->to_address; ?></span>
                                                <?php }else{
                     ?> <span><?php echo $bilti->to_addr; ?></span>
                                                <?php } ?>

                                                <?php if($bilti->consignment_copy == 'Yes'){ ?>
                                                <span><?php echo $bilti->kh_address; ?></span>
                                                <?php }else{ ?>
                                                <span><?php echo $bilti->from_addr; ?></span>
                                                <?php } ?>
                                            </td>
                                            <th>
                                                <!-- <strong>Particulars</strong><hr> -->
                                                <span class="hr-line"><strong>Particulars</strong></span>
                                                <span class="hr-line"><strong>Freight</strong></span><br>
                                                <span class="hr-line"><strong>Door Delivery</strong></span><br>
                                                <span class="hr-line"><strong>Local Coll.</strong></span><br>
                                                <span class="hr-line"><strong>LR Charge</strong></span><br>
                                                <span class="hr-line"><strong>Sub Charge</strong></span><br>
                                                <span class="hr-line"><strong>GST charge</strong></span><br>
                                                <span class="hr-line"><strong>Grand Total</strong></span><br>
                                            </th>
                                            <th>
                                                <!-- <strong>Rate</strong><hr> -->
                                                <span class="hr-line"><strong>Rate</strong></span>
                                                <!-- <span class="hr-line"><strong><?php echo $bilti->rate_one;?></strong></span><br>
                   <span class="hr-line"><strong><?php echo $bilti->rate_two;?></strong></span><br>
                    <span class="hr-line"><strong><?php echo $bilti->rate_three;?></strong></span><br>
                     <span class="hr-line"><strong><?php echo $bilti->rate_four;?></strong></span><br>
                      <span class="hr-line"><strong><?php echo $bilti->rate_five;?></strong></span><br>
                       <span class="hr-line"><strong><?php echo $bilti->rate_six;?></strong></span><br> -->
                                                <span
                                                    class="hr-line"><strong><?php echo $bilti->rate_one;?></strong></span><br>
                                                <span class="hr-line"><strong>0</strong></span><br>
                                                <span class="hr-line"><strong>0</strong></span><br>
                                                <span class="hr-line"><strong>0</strong></span><br>
                                                <span class="hr-line"><strong>0</strong></span><br>
                                                <span class="hr-line"><strong>0</strong></span><br>
                                                <span class="hr-line"><strong>0</strong></span><br>

                                            </th>
                                            <th>
                                                <!-- <strong>AMT</strong><hr> -->
                                                <span class="hr-line"><strong>AMT</strong></span>
                                                <span
                                                    class="hr-line"><strong><?php echo $bilti->amount_one;?></strong></span><br>
                                                <span
                                                    class="hr-line"><strong><?php echo $bilti->amount_two;?></strong></span><br>
                                                <span
                                                    class="hr-line"><strong><?php echo $bilti->amount_three;?></strong></span><br>
                                                <span
                                                    class="hr-line"><strong><?php echo $bilti->amount_four;?></strong></span><br>
                                                <span
                                                    class="hr-line"><strong><?php echo $bilti->amount_five;?></strong></span><br>
                                                <span
                                                    class="hr-line"><strong><?php echo $bilti->amount_six;?></strong></span><br>
                                                <span
                                                    class="hr-line"><strong><?php echo $bilti->grand_amount;?></strong></span><br>

                                            </th>
                                        </tr>
                                        <tr>
                                            <td colspan="3">
                                                <strong>Consignor:</strong>
                                                <span><?php echo $CI->seees_customer_name('m_consignor_details',$bilti->consignor_company_name);?></span><br>
                                                <span><strong>GST No:</strong>
                                                    <?php echo $bilti->consignor_gst_no; ?></span><br>
                                                <span class="d-flex flex-column"><strong>Mobile No:</strong>
                                                    <?php echo $bilti->consignor_phone_no; ?></span><br>
                                                <span class="d-flex flex-column"><strong>Address:</strong>
                                                    <?php echo $bilti->consignor_address; ?></span><br>
                                            </td>
                                            <td colspan="3">
                                                <strong>Consignee:</strong>
                                                <span><?php echo $CI->seees_consignee_name('m_consignee_details',$bilti->consignee_company_name);?></span><br>
                                                <span><strong>GST No:</strong>
                                                    <?php echo $bilti->consignee_gst_no; ?></span><br>
                                                <span><strong>Mobile No:</strong>
                                                    <?php echo $bilti->consignee_phone_no; ?></span><br>
                                                <span><strong>Address:</strong><?php echo $bilti->consignee_address; ?></span><br>
                                            </td>
                                            <td colspan="6">
                                                <strong>TBB (To be built):</strong>
                                                <span><?php echo $bilti->tbb_for; ?></span>
                                               
                                                

                                            </td>
                                        </tr>


                                        <tr>
                                            <td class="right" colspan="1">
                                                <strong>PKGS:</strong><br>
                                                <span><?php echo $bilti->packages; ?></span>
                                            </td>
                                            <td class="right" colspan="2">
                                                <strong>Packing Type:</strong><br>
                                                <span><?php echo $bilti->packing_type;?></span>
                                            </td>
                                            <td class="right" colspan="2">
                                                <strong>Invoice No.:</strong><br>
                                                <span><?php echo $bilti->invoice_no;?></span>
                                            </td>
                                            <td class="right" colspan="2">
                                                <strong>Declared Value:</strong><br>
                                                <span><?php echo $bilti->declared_value;?></span>
                                            </td>
                                            <td class="right" colspan="2">
                                                <strong>GST PAY:</strong><br>
                                                <span><?php echo $bilti->gst_pay;?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="right">
                                                <strong>E Way Bill No.:</strong>
                                                <span><?php echo $bilti->e_way_bill_no;?></span><span
                                                    style="font-weight:bold;">&nbsp;/&nbsp;</span><span><?php echo $bilti->e_way_bill_no_two;?></span><span
                                                    style="font-weight:bold;">&nbsp;/&nbsp;</span><span><?php echo $bilti->e_way_bill_no_three;?></span>

                                            </td>

                                            <td class="right" colspan="3">
                                                <strong>Valid upto :</strong>

                                                <span><?php 
                        if(date('d-m-Y',strtotime($bilti->valid_upto)) == "01-01-1970"){  
                           echo "";
                        }else{
                        echo date('d-m-Y',strtotime($bilti->valid_upto)); 
                        }?></span>
                                            </td>
                                            <td class="right" colspan="3">
                                                <strong>Lorry No.:</strong>
                                                <span><?php echo $bilti->lorry_no; ?> </span>
                                            </td>
                                            <td class="right" colspan="1" style="height:100%;">
                                                <strong>Actual Wt.:</strong>
                                                <span><?php echo $bilti->actual_wt;?></span>
                                            </td>
                                            <td class="right" colspan="1" style="height:60%;">
                                                <strong>Charge Wt.:</strong>
                                                <span><?php echo $bilti->charge_wt;?></span>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td class="right" colspan="4" style="height:100%;">
                                                <strong>Description:</strong><br>
                                                <span><?php echo $bilti->for_acknowledment;?></span>
                                            </td>

                                            <td style="height:100px;margin-bottom:30px;" colspan="5">
                                                <strong>For Acknowledgment</strong><br>
                                                <!-- <span><?php echo $bilti->for_acknowledment;?></span>  -->
                                            </td>
                                            <!-- <td class="right" colspan="4"></td> -->
                                        </tr>
                                        <tr>
                                            <td colspan="9" style="text-align:justify; font-size:14px;">Note: RTSG
                                                Details Axis Bank A/C No: 922020004679229 Branch Name: wadi, Nagpur (MH)
                                                IFSC CODE: UTIB0002011 Beneficiary Name: Guru Drishti Losistics Private
                                                Limited.</td>

                                        </tr>
                                        <tr>
                                            <td colspan="9" style="text-align:justify; font-size:14px;">The payment of
                                                the consignment freight should be made only by RTGS/DD/an Account payee
                                                cheque in favor of Guru Drashti Logistics Private Limited.</td>

                                        </tr>
                                        <tr>
                                            <td colspan="9" style="text-align:justify; font-size:14px;">Caution: Any
                                                copy of this is not to be negotiable through the any bank/Financial
                                                institution/Agency for collection discounting Or credit purpose.</td>

                                        </tr>
                                        <tr class="text-center">
                                            <td colspan="3"><b>Notice</b></td>
                                            <td class="text-center" style="color:tomato;" colspan="3">
                                                <strong><?php echo $bilti->copy_type; ?></strong><br>
                                            </td>
                                            <td colspan="3"><b></b></td>
                                        </tr>
                                        <tr>
                                            <td colspan="6">
                                                <p style="text-align:justify; font-size:14px;">This consignment covered
                                                    by this set by special lorry Receipt shall be stored at the
                                                    destination under the control of transport operator and shall be
                                                    delivered to or to the order of consignee bank whose name is
                                                    mentioned in lorry receipt. It will under no circumstances be
                                                    delivered to anyone with out written authority from consignee bank
                                                    or its order endorsed on consignee copy or on a separate letter of
                                                    authority.</p>
                                            </td>
                                            <td colspan="4">
                                                <p style="text-align:center; font-size:14px;">Amt of GST are provisional
                                                    actual amount as per money receipt issued by NTS realization of CNS
                                                    <br>Freight payble by Consignor / Consignee.</p>
                                                <hr>
                                                <span style="text-align:center; font-size:14px;"><b>
                                                        <center>Signature Of Branch Staff </center>
                                                    </b></span>
                                            </td>

                                        </tr>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <!-- <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'admin/bilti';?>" class="btn btn-secondary me-md-2">BACK</a>
                        
                     </div> -->
                    </form>
                    <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'admin/bilti';?>" class="btn btn-secondary me-md-2">BACK</a>

                    </div>
                    <center>
                        <button class="btn btn-primary txt-white btn-animated from-top"
                            onClick="printdiv('print_character');"><span>PRINT</span></button>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
