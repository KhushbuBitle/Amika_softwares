<?php $CI =&get_instance(); ?>
<!-- Content wrapper -->
<div class="content-wrapper">
	<!-- Content -->
	<div class="container-xxl flex-grow-1 container-p-y">
		<?php if(!empty($this->session->flashdata('success_message'))){ ?>
			<div class="row mt-3">
				<div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
					<div class="alert alert-success alert-dismissible">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
					</div>
				</div>
			</div>
		<?php } ?>
		<!-- Basic Bootstrap Table -->
		<div class="card">
			<div class="card-header"></div>
			<div class="card-body">
				<div class="card-title">
					<h4 class="text-center title-2">Invoice Report</h4>
				</div>

				<form method="GET" name="form" action="<?php echo base_url().'admin/invoice_report';?>">
					<div class="row">
						<div class="col-4">  
							<div class="form-group">
								<label for="cc-payment" class="control-label mb-1">From</label>
								<input id="start_date" name="start_date" type="date" value="<?php echo $_GET['start_date']; ?>" class="form-control">
							</div>
						</div>
						<div class="col-4">
							<div class="form-group">
								<label for="cc-payment" class="control-label mb-1">To</label>
								<input id="end_date" name="end_date" type="date" value="<?php echo $_GET['end_date']; ?>" class="form-control">
							</div>
						</div>
						<div class="col-2 mt-4">
							<div class="form-group">
								<input id="search" name="search" value="Search" type="submit"  class="form-control" style="background-color: #696cff;color: white;">
							</div>
						</div>
					</div>
				</form>
				<form method="GET" name="my_form" action="<?php echo base_url().'admin/name_client';?>" class="mt-3">
					<div class="row">
						<div class="col-4">
							<div class="form-group">
								<label for="cc-payment" class="control-label mb-1">Customer Name</label>
								<select name="name" id="name" class="form-select">
									<option value="0">select</option>
									<?php if(!empty($invoice_details)){ $i=1; foreach($invoice_details as $key){?>
										<option value="<?= $key->owner_name ?>|<?= $key->tbb_for ?>">
										<?php if($key->tbb_for == 'Consignor'){?>
											<?php echo $CI->seees_customer_name('m_consignor_details',$key->owner_name);?>
										<?php }else{ ?>
											<?php echo $CI->seees_consignee_name('m_consignee_details',$key->owner_name);?>
										<?php }
										?>
									</option>
									<?php } }?>
								</select>

							</div>
						</div>

					</div>
					<div class="col-2 mt-4">
						<div class="form-group">
							<input id="search_code" name="search_code" value="Search" type="submit" class="form-control" style="background-color: #696cff;color: white;">
						</div>
					</div>
			</div>
			</form>

			<div class="row ">
				<div class="col-7">
					<h4 class="mb-0"></h4>
				</div>
				<div class="col-5 text-right">
					<button class="btn btn-animated from-top" style="background-color:#fc6e26; color:white;"
							onClick="printdiv('print_character');"><span>PRINT</span></button>
					<button type="submit" class="btn" style="background-color:#1e3d8d; color:white;"
							data-toggle="tooltip" data-placement="bottom" title="Downlod in CSV"
							onclick="download_csv('csv_download_table')" id="download_data">DOWNLOAD
						CSV</button>
					<input type="button" class="btn" value="Back" onclick="goBack()"
						   style="background-color: #fc6e26;color: white;">
				</div>
			</div>

			<div class="table-responsive p-4" id="print_character">
				<div class="ed border-dark">
					<table width='100%' id="csv_download_table" class="table table-bordered">
						<thead class="thead-light">
						<tr>
							<td colspan="15">
								<center>
									<h4>Invoice Report</h4>
							</td>
						</tr>
						<tr class="text-center">
							<th class="text-center">Sr.No.</th>
							<th class="text-center">Customer Name</th>
							<th class="text-center">Bill no.</th>
							<th class="text-center">Bill date</th>
							<th class="text-center">CNS no.</th>
							<th class="text-center">CNS date</th>
							<th class="text-center">Date</th>
							<th class="text-center">Amount</th>
						</tr>
						</thead>
						<tbody>
						<?php
						$dynamic_table_id = $key->id;
						if (!empty($report)) {
							$sr = 1;
							foreach ($report as $key) { ?>
								<tr>
									<td class="text-center"><?php echo $sr; ?></td>
									<td>
										<?php if ($key->tbb_for == 'Consignor') { ?>
											<?= $CI->seees_customer_name('m_consignor_details', $key->owner_name); ?>
										<?php } else { ?>
											<?= $CI->seees_consignee_name('m_consignee_details', $key->owner_name); ?>
										<?php }
										?>
									</td>  

									<td class="text-center"><?= $key->bill_no; ?></td>
									<td class="text-center"><?php
										if(date('d-m-Y',strtotime($key->invoice_bill_date)) == "01-01-1970"){echo "";}
										else{echo date('d-m-Y',strtotime($key->invoice_bill_date));}?></td>
									<td class="text-center"><?= $key->vs_code?></td>
									<td class="text-center"><?= date('d-m-Y', strtotime($key->consignment_date))?></td>
									<td class="text-center"><?= date('d-m-Y', strtotime($key->invoice_bill_date))?></td>
									<td class="text-center"><?= $key->total_amount ?></td>
								</tr>
								<?php $sum += $key->total_amount; ?>

							<?php $sr++;  } 
						} else { ?>
							<tr>
								<td colspan="10" class="text-center text-xs">No Data Found</td>
							</tr>
						<?php } ?>

						<?php $dynamic_details = $this->db->where(array('invoice_id'=>$dynamic_table_id,'is_deleted !='=>9))
								->get('invoice_dynamic_details')->num_rows();?>
						<?php if(($_GET['name'])!=0){?>
							<?php if($dynamic_details>0){  ?>
								<?php $data = $this->db->where(array('invoice_id'=>$dynamic_table_id,'is_deleted !='=>9))
								->get('invoice_dynamic_details')->result();
						$sr=2; foreach($data as $row) { ?>
						<tr>
							<td class="text-center"><?= $sr ?></td>
							<td class="text-center"></td>
							<td class="text-center"></td>
							<td class="text-center"></td>
							<td class="text-center"><?= $row->vs_code_one ?></td>
							<td class="text-center"><?= date('d-m-Y', strtotime($row->consignment_date_one)) ?></td>
							<td class="text-center"></td>
							<td class="text-center"><?= $row->total_amount_one ?></td>
							<?php $sum += $row->total_amount_one; ?>
							<?php $sr++; } } }?>
						</tr>
						<tr>
							<td colspan="7" style="text-align:center;"><b>Total</b></td>
							<td>
								<h5 style="padding: 5px;text-align:center;">
									<?= 'Rs. '.$sum; ?>.00
								</h5>
							</td>


						</tr>

						</tbody>
					</table>
				</div>
			</div>
			<!-- END DATA TABLE-->
		</div>
	</div>
	<!--/ Basic Bootstrap Table -->
</div>
<!-- / Content -->
