<!-- Content wrapper -->
<div class="content-wrapper">
            <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-8 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">  
                      <div class="col-sm-7">
                        <div class="card-body">
                          <h5 class="card-title text-primary">Congratulations John! 🎉</h5>
                          <p class="mb-4">   
                            You have done <span class="fw-bold">72%</span> more sales today. Check your new badge in
                            your profile.
                          </p>

                          <a href="javascript:;" class="btn btn-sm btn-outline-primary">View Badges</a>
                        </div>
                      </div>
                      <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                          <img
                            src="<?php echo base_url();?>assets/img/illustrations/man-with-laptop-light.png"
                            height="140"
                            alt="View Badge User"
                            data-app-dark-img="illustrations/man-with-laptop-dark.png"
                            data-app-light-img="illustrations/man-with-laptop-light.png"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-md-4 order-1">
                  <div class="row">
                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                      <div class="card">
                        <div class="card-body">
                          <span class="fw-semibold d-block mb-1">Total Bilti </span>
                          <h3 class="card-title mb-2">
                          <div class="avatar flex-shrink-0">
                              <img
                                src="<?php echo base_url();?>assets/img/icons/unicons/chart-success.png"
                                alt="chart success"
                                class="rounded"
                              />
                            </div><?php $query = $this->db->query('SELECT * FROM bilti_details where `is_deleted` != 9');
                        echo $query->num_rows();?></h3>
                          <small class="text-success fw-semibold"></small>
                        </div>
                      </div>
                    </div>
                    <div class="col-6 mb-4"> 
                      <div class="card">
                        <div class="card-body">
                          <span class="d-block mb-1">Invoice</span>
                          <div class="avatar flex-shrink-0">
                              <img
                                src="<?php echo base_url();?>assets/img/icons/unicons/chart-success.png"
                                alt="chart success"
                                class="rounded"
                              />
                            </div>  
                          <h3 class="card-title text-nowrap mb-2"><?php $query = $this->db->query('SELECT * FROM invoice_details where `is_deleted` != 9');
                        echo $query->num_rows();?>
                      </h3>
                          <small class="text-danger fw-semibold"></small>
                        </div>
                      </div>  
                    </div>
                    
                  </div> 
                </div>
                <!-- Total Revenue -->
                <div class="col-12 col-lg-8 order-2 order-md-3 order-lg-2 mb-4">
                  <div class="card">
                    <div class="row row-bordered g-0">  
                      <div class="col-md-12">
                        <h5 class="card-header m-0 me-2 pb-3">Monthly Graph</h5>
                         <div class="px-2">



                         <div class="recent-report2">  
                    
                     <div class="chartBox">  
                        <select id="coffeesales">
                           <option value="">Select</option>
                           <option value="<?php echo implode(",", $month_data);?>">Bilti</option>  
                           <option value="<?php echo implode(",", $month_invoice_data);?>">Invoice</option>
                           <option value="<?php echo implode(",", $month_payment_data);?>">Payment Receipt</option>
                           <option value="<?php echo implode(",", $month_lorry_data);?>">Lorry</option>
                        </select>
                     </div>
                     <div class="recent-report__chart">
                        <div class="chartBox">
                           <canvas id="myChart"></canvas>
                        </div>
                     </div>
                  </div>

                         </div>
                        
                      </div>
                    </div>
                  </div>
                </div> 
                <!--/ Total Revenue -->
                <div class="col-12 col-md-8 col-lg-4 order-3 order-md-2">
                  <div class="row">
                  <div class="col-lg-6 col-md-12 col-6 mb-4">
                      <div class="card">
                        <div class="card-body">
                          <span>Total Lorry Challan</span>
                          <div class="avatar flex-shrink-0">
                              <img
                                src="<?php echo base_url();?>assets/img/icons/unicons/chart-success.png"
                                alt="chart success"
                                class="rounded"
                              />
                            </div>   
                          <h3 class="card-title text-nowrap mb-1"><?php $query = $this->db->query('SELECT * FROM lorry_challan_details where `is_deleted` != 9');
                        echo $query->num_rows();?></h3>
                          <small class="text-success fw-semibold"></small>
                        </div>
                      </div>
                    </div>
                    <div class="col-6 mb-4">
                      <div class="card">
                        <div class="card-body">
                          <span class="fw-semibold d-block mb-1">Total Payment Receipt</span>
                          <div class="avatar flex-shrink-0">
                              <img
                                src="<?php echo base_url();?>assets/img/icons/unicons/chart-success.png"
                                alt="chart success"
                                class="rounded"
                              />
                            </div>
                          <h3 class="card-title mb-2"><?php $query = $this->db->query('SELECT * FROM payment_receipt_details where `is_deleted` != 9');
                        echo $query->num_rows();?></h3>
                          <small class="text-success fw-semibold"></small>
                        </div>
                      </div>
                    </div>
                    <!-- </div>
    <div class="row"> -->
                  
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->
            <script>
   const ctx = document.getElementById('myChart').getContext('2d');
   const myChart = new Chart(ctx, {
       type: 'line',
       data: {
           labels: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'ÓCT', 'NOV', 'DEC'],
           datasets: [{
               label: 'Select',
               data: '<?php echo implode(",", $month_data);?>',
               backgroundColor: [
                   'rgba(255, 99, 132, 0.2)',
                   'rgba(54, 162, 235, 0.2)',
                   'rgba(255, 206, 86, 0.2)',
                   'rgba(75, 192, 192, 0.2)',
                   'rgba(153, 102, 255, 0.2)',
                   'rgba(255, 159, 64, 0.2)'
               ],
               borderColor: [
                   'rgba(255, 99, 132, 1)',
                   'rgba(54, 162, 235, 1)',
                   'rgba(255, 206, 86, 1)',
                   'rgba(75, 192, 192, 1)',
                   'rgba(153, 102, 255, 1)',
                   'rgba(255, 159, 64, 1)'
               ],
               borderWidth: 1
           }]
       },
       options: {
           scales: {
               y: {
                   beginAtZero: true
               }
           }
       }
   });
   const coffeesales = document.getElementById('coffeesales');
   coffeesales.addEventListener('change', salesTracker);
   function salesTracker(){
       const label = coffeesales.options[coffeesales.selectedIndex].text;
       myChart.data.datasets[0].label = label;
       myChart.data.datasets[0].data = coffeesales.value.split(',');
       myChart.update();
   }
</script>