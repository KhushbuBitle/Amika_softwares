<html lang="en">
<head>  
    <title>Bootstrap Timepicker Example</title>  
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>             
</head>   
<body>
<div class="container" style="margin-top: 20px">
    <div class="col-md-8 col-md-offset-2">
        <h2 class="text-center"></h2>
        <div class="form-group" style="margin-top: 30px">
            <label>Start Time</label>
            <input class="form-control" type="text" name="time_one" id="time_one" placeholder="hh:mm:ss" />
        </div>
        <div class="form-group" style="margin-top: 30px">
            <label>End Time</label>
            <input class="form-control" type="text" name="time_two" id="time_two" placeholder="hh:mm:ss" />
        </div>
        <div class="form-group" style="margin-top: 30px">
            <label>Duration</label>
            <input class="form-control" type="text" name="time_three" id="time_three"/>    
        </div>
<!--         <div class="form-group" style="margin-top: 30px">
            <label>Output</label>
            <input class="form-control" type="text" name="four" id="four"/>
        </div>  -->   
        <button type="button" id="abc" class="btn btn-danger">Click Me</button>  
    </div>  
   <div id="cont_one"></div>                   

</div>      
<script>  
    $('#time_one').datetimepicker({  
        format: 'hh:mm:ss',
    });
    $('#time_two').datetimepicker({
        format: 'hh:mm:ss',
    });
</script>
<script type="text/javascript">       
  $(document).ready(function(){    
$("#abc").click(function(){
       
      
  var a = $("#time_one").val();
  //alert(a);  
  var b = $("#time_two").val();
  var c = $("#time_three").val();        
  var starttime = a;  
  //alert(starttime);
  var endtime = b;  
  //alert(b);  
  var interval = c;  
  //alert(interval);
  var startTimeInMin = convertToMin(starttime);
  var endTimeInMin = convertToMin(endtime);
  timeIntervel = parseInt(endTimeInMin-startTimeInMin)/(parseInt(interval)*60);    

  nextSlot = starttime;         

  slotArra = [nextSlot];
  for(i=0; i<(timeIntervel-1); i++){
    var nextSlot =  getNextSlot(nextSlot, interval);  
    slotArra.push(nextSlot);      
  }         
    
   //alert(slotArra)             
  //$("#four").val(slotArra);
  //console.log(slotArra);     

  function convertToMin(inputTime){
    inputTime = inputTime.split(':');
    //2*1440
    var hrinseconds = parseInt(inputTime[0])*3600;
    var mininseconds = parseInt(inputTime[1])*60;
    return parseInt(hrinseconds)+parseInt(mininseconds)+parseInt(inputTime[2])
  }             
function getNextSlot(starttime, interval) {  
    var piece = starttime.split(':');  
    var hour = piece[0];                   
    var minutes = piece[1];
    var seconds = piece[2];                
    var newMinute = parseInt(minutes)+parseInt(interval)
    if(newMinute>=60){
      hour = parseInt(hour)+1;  
      newMinute = newMinute%60
      if(newMinute==0)   
        newMinute = '00';                        
    }    
    var newTim = hour+':'+newMinute+':'+seconds;  
    return newTim;      
  }   
  //alert(typeof(slotArra));
    for (j = 0; j <= (slotArra.length-1); j++)
    {

       $('#cont_one').append('<input type="checkbox">')
       $('#cont_one').append('<input type="text" value='+slotArra[j]+'>');
    }         

});   
});

</script>  
</body>
</html>
