<style type="text/css">
   .radio-group {
  padding-left: 10px;
  margin-top: 10px;
  margin-bottom: 20px;     
}
.radio-group label::after {
  content:'\00a0\00a0\00a0\00a0'; /* eq &nbsp; x 4 */  
}

</style>   
<div class="content-wrapper"> 
   <div class="container-xxl flex-grow-1 container-p-y">  
       <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span>Bilti</h4>
      <!-- Basic Layout -->         
      <div class="row">
         <div class="col-xl">
            <div class="card mb-4">  
               <div class="card-header d-flex justify-content-between align-items-center">  
                  <h5 class="mb-0">Bilti</h5>              
               </div>   
               <div class="card-body">   
                  <form action="<?php echo base_url().'admin/add_bilti'; ?>" enctype="multipart/form-data" method="POST">
                      <?php $load_type = array('FTL','LTL','SUN'); ?>
                     
                      <?php $consignment_copy = array('Yes','No'); ?>
                      <?php $packing_type = array('Wooden Box','CTN','BAG','LUSE','DRUM','Spiral'); ?>
                      <?php $copy_type = array('Lorry Copy','Consignee Copy','Consignor Copy','File Copy'); ?>
                      <p class="mt-3" style="font-weight: bold;"><u>AT OWNER'S RISK</u></p>
                      <div class="row mt-2">   
                      <div class="col-sm-2">    
                           <div class="form-group">
                              <label class="floating-label" for="Text">VS</label>
                              <select name="vs_code" id="vs_code" class="form-select">
                    <option value="">Select</option>
                    <?php for($i=-100;$i<100;$i++){?> 
                     <?php if(50001 < ($vs_code + $i)){ ?>  
                     <?php $id = $this->db->where(array('vs_code'=>($vs_code + $i)))->get('bilti_details')->num_rows(); ?> 
                          <?php if($id == 0){ ?>
                        <option value="<?php echo $vs_code + $i;  ?>" ><?php echo $vs_code + $i; ?></option>
                        <?php }}} ?>
                        <?php for($i=0;$i<100;$i++){?>    
                        <option value="<?php echo $vs_code + $i;  ?>" ><?php echo $vs_code + $i; ?></option>
                        <?php } ?>        
                     </select>  
                           </div>       
                        </div>  
                        <div class="col-sm-2">  
                           <div class="form-group">
                              <label class="floating-label" for="Text">Copy Type</label> 
                     <select name="copy_type" id="copy_type" class="form-select">
                        <option value="">Select</option>
                        <?php for($i=0;$i<count($copy_type);$i++){?>
                        <option value="<?php echo $copy_type[$i]; ?>" ><?php echo $copy_type[$i]; ?></option>
                        <?php } ?>
                     </select>
                           </div>             
                        </div>
                        <div class="col-sm-2">  
                           <div class="form-group">
                              <label class="floating-label" for="Text">Load Type</label> 
                     <select name="load_type" id="load_type" class="form-select">
                        <option value="">Select</option>
                        <?php for($i=0;$i<count($load_type);$i++){?>
                        <option value="<?php echo $load_type[$i]; ?>" ><?php echo $load_type[$i]; ?></option>
                        <?php } ?>
                     </select>
                           </div>         
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Insurance Company</label>
                              <input type="text" class="form-control" id="insurance_company" name="insurance_company">
                           </div>
                        </div>
                        <div class="col-sm-3">  
                           <div class="form-group">
                              <label class="floating-label" for="Text">Policy No.</label>
                              <input type="text" class="form-control" id="policy_no" name="policy_no">
                           </div>
                        </div>
                        </div>
                     <div class="row mt-3">  
                        
                        
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">From(City,State)</label>  
                              <select name="from_bilti" id="from_bilti" class="form-select" onchange="changeSearchfrom(this.value);">
                     <option>Select</option> 
                          <option value="Nagpur">Nagpur</option>
                          <option value="Indore">Indore</option>      
                     </select>  
                           </div>  
                        </div>   
                        <div class="col-sm-6" id="from_address_nag" style="display: none;">  
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label> <textarea type="text" class="form-control" id="from_address" name="from_address">Guru Drashti Logistics Pvt.Ltd. Nagpur</textarea>
                           </div>
                        </div> 
                         <div class="col-sm-6" id="from_address_ind" style="display: none;">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label> <textarea type="text" class="form-control" id="from_address_indore" name="from_address_indore">32, Tiware complex, TT Nager, Near Kataria Complex, Ring Road, Dewas Naka, Indore- 455001</textarea>
                           </div>
                        </div>
                        <div class="col-sm-3"> 
                           <div class="form-group">
                              <label class="floating-label" for="Text">To(City,State)</label>
                              <input type="text" class="form-control" id="to_bilti" name="to_bilti">        
                           </div>
                        </div>     
                        </div> 
                     
                     <div class="row mt-3">   
                        <!-- <div class="col-sm-3"> 
                           <div class="form-group">
                              <label class="floating-label" for="Text">To(City,State)</label>
                              <input type="text" class="form-control" id="to_bilti" name="to_bilti">        
                           </div>
                        </div> -->
                        <div class="col-sm-3">  
                           <div class="form-group">
                              <label class="floating-label" for="Text">Door Delivery</label> 
                     <select name="door_dilivery" id="door_dilivery" class="form-select" onchange="changeSearchstatus(this.value);">
                     <option>Select</option>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>    
                     </select>
                           </div>          
                        </div>
                        <div class="col-sm-3" id="to_address_details" style="display: none;">      
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>    
                              <textarea type="text" class="form-control" id="to_address" name="to_address">Door Delivery</textarea>
                           </div>     
                        </div>  
                        <div class="col-sm-3" id="to_aaa_details" style="display: none;">  
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>    
                              <textarea type="text" class="form-control" id="to_addr" name="to_addr">Godown Delivery</textarea>
                           </div>
                        </div>
                        <!-- </div>
                        <div class="row mt-3">    --> 
                        <div class="col-sm-3">  
                           <div class="form-group">
                              <label class="floating-label" for="Text">Consignment Copy Attached</label> 
                     <select name="consignment_copy" id="consignment_copy" class="form-select" onchange="changeSearch(this.value);">
                     <option>Select</option>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>    
                     </select>
                           </div>             
                        </div> 
                        <!-- <div class="col-sm-4" id="to_address_details" style="display: none;">      
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>    
                              <textarea type="text" class="form-control" id="to_address" name="to_address">Door Delivery</textarea>
                           </div>     
                        </div>     
                        <div class="col-sm-4" id="to_aaa_details" style="display: none;">  
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>    
                              <textarea type="text" class="form-control" id="to_addr" name="to_addr">Godown Delivery</textarea>
                           </div>
                        </div>    -->
                        <div class="col-sm-3" id="from_address_details" style="display: none;">  
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>    
                              <textarea type="text" class="form-control" id="kh_address" name="kh_address">Consignment Copy Attached</textarea>
                           </div>
                        </div>  
                        <div class="col-sm-3" id="from_aaa_details" style="display: none;">  
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>    
                              <textarea type="text" class="form-control" id="from_addr" name="from_addr">Without Consginment Copy Attached</textarea>
                           </div>
                        </div>      
                     </div>       
                     <div class="row mt-2">   
                     
                        

                     </div>
                      <p class="mt-3" style="font-weight: bold;"><u>CONSIGNOR</u></p>
                     <div class="row">  
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Company Name</label>
                              <select name="consignor_company_name" id="consignor_company_name" class="select2 form-select">
                           <option value="">Select</option>
                           <?php if(!empty($company_name)){
                              foreach($company_name as $row){?>
                           <option value="<?php echo $row['id'];?>">
                              <?php echo $row['customer_name'];?> 
                           </option>
                           <?php } } ?>     
                        </select> 
                           </div>    
                        </div>
                        <div class="col-sm-3"> 
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST NO.</label>
                                 <input type="text" class="form-control" id="consignor_gst_no" name="consignor_gst_no" minlength="15" maxlength="15">   
                           </div> 
                        </div>
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Phone No.</label>
                                 <input type="text" class="form-control" id="consignor_phone_no" name="consignor_phone_no" minlength="10" maxlength="10">   
                           </div>  
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Address</label>
                              <textarea type="text" class="form-control" id="consignor_address" name="consignor_address"></textarea>
                           </div>
                        </div>
                     </div>
                     <div class="row mt-3">  
                        <!-- <div class="col-sm-4">     
                           <div class="form-group">
                              <label class="floating-label" for="Text">Policy Name</label>
                             <input type="text" class="form-control" id="consignor_policy_name" name="consignor_policy_name">  
                           </div>        
                        </div> -->
                        <!-- <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Policy No.</label>
                                 <input type="text" class="form-control" id="consignor_policy_no" name="consignor_policy_no">   
                           </div>  
                        </div> -->
                         <!-- <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Policy Attachment</label>
                                 <input type="file" class="form-control" id="policy_file" name="policy_file">      
                           </div>  
                        </div> -->    
                     </div>
                     <p class="mt-2" style="font-weight: bold;"><u>CONSIGNEE</u></p>
                     <div class="row">    
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Company Name</label>
                              <select name="consignee_company_name" id="consignee_company_name" class="select2 form-select">
                           <option value="">Select</option>
                           <?php if(!empty($company)){
                              foreach($company as $row){?>
                           <option value="<?php echo $row['id'];?>">  
                              <?php echo $row['company_name'];?>  
                           </option>
                           <?php } } ?>  
                        </select> 
                           </div>    
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST NO.</label>
                                 <input type="text" class="form-control" id="consignee_gst_no" name="consignee_gst_no" minlength="15" maxlength="15">   
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Phone No.</label>
                                 <input type="text" class="form-control" id="consignee_phone_no" name="consignee_phone_no" minlength="10" maxlength="10">   
                           </div> 
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Address</label>
                              <textarea type="text" class="form-control" id="consignee_address" name="consignee_address"></textarea>
                           </div>
                        </div>
                     </div>  
                     <div class="row mt-3">      
                       
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Packing Type</label>
                              <select name="packing_type" id="packing_type" class="form-select">
                        <option value="">Select</option>
                        <?php for($i=0;$i<count($packing_type);$i++){?>
                        <option value="<?php echo $packing_type[$i]; ?>" ><?php echo $packing_type[$i]; ?></option>
                        <?php } ?>
                     </select>   
                           </div>   
                        </div>  
                        
                        
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Invoice No.</label>
                              <input type="text" class="form-control" id="invoice_no" name="invoice_no" style="border:1px solid red;">
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Declared Value</label>
                                 <input type="text" class="form-control" id="declared_value" name="declared_value">   
                           </div>   
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">PKGS</label>
                              <input type="text" class="form-control" id="packages" name="packages">
                           </div>   
                        </div>  
                        </div> 
                        <div class="row mt-3">
                        <div class="col-sm-3">  
                           <div class="form-group"> 
                              <label class="floating-label" for="Text">E Way Bill No. (One)</label>
                                 <input type="text" class="form-control" id="e_way_bill_no" name="e_way_bill_no" minlength="12" maxlength="12">   
                           </div>  
                        </div>
                        <div class="col-sm-3"> 
                           <div class="form-group"> 
                              <label class="floating-label" for="Text">E Way Bill No. (Two)</label> 
                                 <input type="text" class="form-control" id="e_way_bill_no_two" name="e_way_bill_no_two" minlength="12" maxlength="12">   
                           </div>  
                        </div>
                        <div class="col-sm-3"> 
                           <div class="form-group"> 
                              <label class="floating-label" for="Text">E Way Bill No. (Three)</label>
                                 <input type="text" class="form-control" id="e_way_bill_no_three" name="e_way_bill_no_three" minlength="12" maxlength="12">   
                           </div>  
                        </div>
                        </div>
                        <div class="row mt-3">
                        <div class="col-sm-3"> 
                           <div class="form-group">
                              <label class="floating-label" for="Text">Actual Wt.</label>
                                 <input type="text" class="form-control" id="actual_wt" name="actual_wt">   
                           </div>  
                        </div>  
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Charge Wt.</label>
                                 <input type="text" class="form-control" id="charge_wt" name="charge_wt" style="border:1px solid red;">     
                           </div>          
                        </div> 
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Valid Upto</label>
                                 <input type="date" class="form-control" id="valid_upto" name="valid_upto">     
                           </div>  
                        </div>  
                        <!-- <div class="col-sm-3">  
                           <div class="form-group">
                              <label class="floating-label" for="Text">Lorry No.</label>
                                 <input type="text" class="form-control" id="lorry_no" name="lorry_no">      
                           </div>     
                        </div> --> 
                        <div class="col-sm-3">        
                           <div class="form-group">
                              <label class="floating-label" for="Text">Lorry No</label>
                              <select name="lorry_no" id="lorry_no" class="select2 form-select">
                           <option value="">Select</option>
                           <?php if(!empty($lorry_no)){
                              foreach($lorry_no as $row){?>
                           <option value="<?php echo $row['lorry_no'];?>">
                              <?php echo $row['lorry_no'];?> 
                           </option>
                           <?php } } ?>  
                        </select> 
                           </div>    
                        </div>
                     </div>  
                     <div class="row mt-3">    
                     </div>   
                     <!-- <div class="row mt-3">    
                        <div class="col-sm-6">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Description</label>
                              <textarea type="text" class="form-control" id="description" name="description"></textarea>
                           </div>   
                        </div>
                     </div>     -->
                     <p class="mt-2" style="font-weight: bold;"><u>CONSIGNMENT NOTE NO</u></p>
                     <div class="row">     
                        
                        <?php $today = date('Y-m-d'); ?>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">DATE</label>
                                 <input type="date" class="form-control" id="con_date" name="con_date" value="<?php echo $today; ?>">   
                           </div>   
                        </div>  
                         <div class="col-sm-3">    
                           <div class="form-group">
                              <label class="floating-label" for="Text">Pan No.</label>
                                 <input type="text" class="form-control" id="con_pan_no" name="con_pan_no" minlength="10" maxlength="10" value="AAKCG1444K" readonly >   
                           </div> 
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">CIN No.</label>
                                 <input type="text" class="form-control" id="con_gst_no" name="con_gst_no"  value="U60210MH2022PTC393571" readonly>   
                           </div> 
                        </div>
                     </div> 
                     <div class="row mt-5">       
                        <div class="col-sm-3">   
                                        
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" style="background-color:#e6d91e8a;"class="form-control" value="Rate"  readonly>   
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" style="background-color:#e6d91e8a;" class="form-control" value="Amount"  readonly>    
                           </div> 
                        </div> 
                     </div>    
                     <div class="row">       
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="freight" name="freight" value="Freight"  readonly style="background-color:#ffc1078f;">
                           </div>              
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="rate_one" name="rate_one" placeholder="Rate" value="0" style="border-color:red;">   
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="amount_one" name="amount_one" placeholder="Amount" value="0">   
                           </div> 
                        </div> 
                     </div>   
                      <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="door_delivery" name="door_delivery" value="Door Delivery" readonly style="background-color:#ffc1078f;">
                           </div>   
                        </div>
                        <!-- <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="rate_two" name="rate_two" placeholder="Rate" value="0">   
                           </div>  
                        </div>  -->
                        <div class="col-sm-3"></div>
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="amount_two" name="amount_two" placeholder="Amount" value="0">   
                           </div> 
                        </div>
                     </div>      
                     <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="local_collection" name="local_collection" value="Local Collection" readonly style="background-color:#ffc1078f;">
                           </div>   
                        </div>
                        <!-- <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="rate_three" name="rate_three" placeholder="Rate" value="0">   
                           </div>  
                        </div>  -->
                        <div class="col-sm-3"></div>
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="amount_three" name="amount_three" placeholder="Amount" value="0">   
                           </div> 
                        </div>   
                     </div> 
                     <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="lr_charge" name="lr_charge" value="LR Charge" readonly style="background-color:#ffc1078f;">
                           </div>   
                        </div>
                        <!-- <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="rate_four" name="rate_four" placeholder="Rate" value="0">    
                           </div>  
                        </div>  -->
                        <div class="col-sm-3"></div>
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="amount_four" name="amount_four" placeholder="Amount" value="0">   
                           </div> 
                        </div>   
                     </div>     
                     <div class="row">       
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="sub_charge" name="sub_charge" value="Sub Charge" readonly style="background-color:#ffc1078f;">
                           </div>   
                        </div>
                        <!-- <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="rate_five" name="rate_five" placeholder="Rate" value="0">    
                           </div>  
                        </div>  -->
                        <div class="col-sm-3"></div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="amount_five" name="amount_five" placeholder="Amount" value="0">   
                           </div> 
                        </div>   
                     </div> 
                      <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="gst_charge" name="gst_charge" value="GST Charge" readonly style="background-color:#ffc1078f;">  
                           </div>   
                        </div>
                        <!-- <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="rate_six" name="rate_six" placeholder="Rate" value="0">    
                           </div>  
                        </div>  -->
                        <div class="col-sm-3"></div>
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="amount_six" name="amount_six" placeholder="Amount" value="0">   
                           </div>   
                        </div>   
                     </div> 
                     <div class="row">     
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" style="background-color:#90EE90;" class="form-control" id="grand_total" name="grand_total" value="Grand Total" readonly >  
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">    
                           </div>  
                        </div> 
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                                 <input type="text" class="form-control" id="grand_amount" name="grand_amount" placeholder="Grand Amount" style="border:1px solid red;">   
                           </div>   
                        </div>   
                     </div>   
                     <div class="row mt-3">              
                        <div class="col-sm-4">    
                           <div class="form-group radio-group">   
                              <label class="floating-label" for="Text">Basis Of BKG</label><br> 
                             <label class="radio-inline mt-2"><input type="radio" name="basis_of_bkg" value="To_Pay"><span style="margin-left:10px;">To PAY</span></label>
                             <label class="radio-inline"><input type="radio" name="basis_of_bkg" value="TBB"><span style="margin-left:10px;">TBB</span></label>
                             <label class="radio-inline"><input type="radio" name="basis_of_bkg" value="PAID"><span style="margin-left:10px;">PAID</span></label>
                           </div>         
                        </div>    
                        <div class="col-sm-4">    
                           <div class="form-group radio-group">
                              <label class="floating-label" for="Text">GST PAY</label><br> 
                             <label class="radio-inline mt-2"><input type="radio" name="gst_pay" value="Consignor"><span style="margin-left:10px;">Consignor</span></label>
                             <label class="radio-inline"><input type="radio" name="gst_pay" value="Consignee"><span style="margin-left:10px;">Consignee</span></label>
                             <label class="radio-inline"><input type="radio" name="gst_pay" value="NTC"><span style="margin-left:10px;">NTC</span></label>
                           </div>    
                        </div>  
                        <div class="col-sm-4">            
                           <div class="form-group radio-group">      
                              <label class="floating-label" for="Text" style="color:red;">TBB (To be built)</label><br> 
                             <label class="radio-inline mt-2"><input type="radio" name="tbb_for" value="Consignor"><span style="margin-left:10px;">Consignor</span></label>
                             <label class="radio-inline"><input type="radio" name="tbb_for" value="Consignee"><span style="margin-left:10px;">Consignee</span></label>   
                           </div>   
                        </div>  
                     </div> 
                      <div class="row mt-3">    
                        <div class="col-sm-12">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Description</label>
                              <textarea type="text" class="form-control" id="for_acknowledment" name="for_acknowledment"> </textarea> 
                           </div>          
                        </div> 
                     </div>         
                     <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'admin/bilti';?>" class="btn btn-secondary me-md-2">BACK</a>
                        <button type="submit" name="submit_form" class="btn btn-primary">SAVE</button>
                     </div>
                  </form>   
               </div>
            </div>
         </div>
      </div>
   </div>
</div>  
<script>
  $(document).ready(function(){     
      $('.select2').select2();
      $("#consignor_company_name").on("change",function(){
   /*auto fill for op_quntity*/
      var id  = $("#consignor_company_name").val();
      var controller_name = '<?php echo $controller_name; ?>';
      $.ajax({
           type: "POST",
           url: '<?php echo base_url($controller_name.'/get_consignor_data/');?>',
           data:{id:id},
           success: function(response){
           var data = JSON.parse(response);
           if(typeof data === 'object' && data !== null){
            console.table(data);
             $('#consignor_company_name').val(data.id);
             $('#consignor_gst_no').val(data.gst_no); 
             $('#consignor_phone_no').val(data.mobile_no);
             $('#consignor_address').val(data.address);
           }else{
              alert('Data not found!'); 
           }
      }});
   }); 
});
</script>  

<script>
   $(document).ready(function(){     
      $('.select2').select2();
      $("#consignee_company_name").on("change",function(){
         var input  = $("#consignee_company_name").val();
         var controller_name = '<?php echo $controller_name; ?>';
      $.ajax({
           type: "POST",
           url: '<?php echo base_url($controller_name.'/get_consignee_data/');?>',
           data:{id:input},
           success: function(response){
           var data = JSON.parse(response);
           if(typeof data === 'object' && data !== null){
            console.table(data);
             $('#consignee_company_name').val(data.id);
             $('#consignee_gst_no').val(data.gst_no); 
             $('#consignee_phone_no').val(data.mobile_no);
             $('#consignee_address').val(data.address);
           }else{
              alert('Data not found!');
           }
      }});
      });
   });
</script> 
<script>
//Confirmed and reject fields showing
function changeSearchstatus(type){  
      if (type == "Yes") {    
         document.getElementById('to_address_details').style.display = "block";
         document.getElementById('to_aaa_details').style.display = "none";
     }
     if (type == "No") {  
      document.getElementById('to_aaa_details').style.display = "block";
      document.getElementById('to_address_details').style.display = "none";
      }  
     
   } 
 </script>  
<script>
//Confirmed and reject fields showing   
function changeSearch(type){
      if (type == "Yes") {    
         document.getElementById('from_address_details').style.display = "block";
         document.getElementById('from_aaa_details').style.display = "none";
         
     }
     if (type == "No") {  
      document.getElementById('from_aaa_details').style.display = "block";
      document.getElementById('from_address_details').style.display = "none";
      }  
     
   } 
 </script>  
 <script> 
//Confirmed and reject fields showing
function changeSearchfrom(type){  
      if (type == "Nagpur") {    
         document.getElementById('from_address_nag').style.display = "block";
         document.getElementById('from_address_ind').style.display = "none";
     }
     if (type == "Indore") {  
      document.getElementById('from_address_ind').style.display = "block";
      document.getElementById('from_address_nag').style.display = "none";
      }  
     
   } 
 </script>
 
 <script>
$("#amount_one").click(function(){
  var a1 =$('#charge_wt').val();
  var a2 =$('#rate_one').val();
  $('#amount_one').val(a1 * a2);

});

$("#grand_amount").click(function(){
  
  var a1 =$('#charge_wt').val();
  var a2 =$('#rate_one').val();
  $('#amount_one').val(a1 * a2);


   var a1 = parseInt($('#amount_one').val());
   var a2 = parseInt($('#amount_two').val());
   var a3 = parseInt($('#amount_three').val());
   var a4 = parseInt($('#amount_four').val());
   var a5 = parseInt($('#amount_five').val());
   var a6 = parseInt($('#amount_six').val());
   var a7 = (a1 + a2 + a3 + a4 + a5 + a6);
   $('#grand_amount').val(a7);
  
});
</script>