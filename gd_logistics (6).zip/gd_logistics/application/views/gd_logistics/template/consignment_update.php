<?php $CI =&get_instance(); ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <?php if(!empty($this->session->flashdata('success_message'))){ ?>
        <div class="row mt-3">
            <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert"
                        aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
                </div>
            </div> 
        </div>
        <?php } ?> 
        <div class="card">  
            <div class="card-header">  
                <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-8 col-lg-8">
                        <h5>Consignment List</h5>
                    </div>
                    <div class="col-sm-4">
                        <a href="" class="btn btn-primary btn-md"
                          data-bs-toggle="modal"
                          data-bs-target="#modaltop1" style="margin-left: 50%;" 
                        >
                          Add
                        </a> 
                    </div>
                </div>
            </div>  
            <hr>
            <div class="table-responsive text-nowrap">  
                <table class="table datatableid">
                    <thead>
                        <tr>
                            <th>SR NO.</th>
                            <th>CNS NO.</th>
                            <th>DATE</th>
                            <th>TIME</th>
                            <th>LORRY NO.</th>
                            <th>FROM</th>
                            <th>TO</th>
                            <th style="color:red">CURRENT STATUS</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($info)){ $i=1; foreach($info as $key){?>
                        <tr>
                            <td><?php echo $i;?></td>
                            <td>
                                <a href="" type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#basicModal" onclick="get_area_one('<?php echo $key->ee_id;?>')">
                                    <?php echo $key->vs_code;?></a>
                            </td> 
                            <td><?php 
                        if(date('d-m-Y',strtotime($key->consignment_date)) == "01-01-1970"){  
                           echo "";
                        }else{
                        echo date('d-m-Y',strtotime($key->consignment_date)); 
                        }?></td>
                            <td><?php echo $key->consignment_time;?></td>
                            <td><?php echo $key->lorry_no;?></td>
                            <td><?php echo $key->consignment_from;?></td>
                            <td><?php echo $key->consignment_to;?></td>
                            <td><?php echo $key->consignment_status;?></td>  
                            <td>   
                                    
                                    <a href=" " class="btn btn-sm rounded-pill btn-info" role="button" data-bs-target="#modaltop" onclick="get_area('<?php echo $key->vs_code; ?>', '<?php echo $key->ee_id; ?>','<?php echo $key->consignment_date; ?>','<?php echo $key->consignment_from; ?>','<?php echo $key->consignment_to; ?>','<?php echo $key->lorry_no; ?>','<?php echo $key->consignment_time; ?>','<?php echo $key->consignment_status; ?>', '<?php echo $key->id; ?>','consignment_update_details')" data-bs-toggle="modal" class="btn btn-gradient-danger btn-sm"><i class="bx bx-edit-alt me-2"></i></a>
                                        <a href=" " role="button" class="btn btn-sm rounded-pill btn-danger"
                                            onclick="delete_company('<?php echo $key->id;?>','consignment_update_details')"
                                            data-bs-toggle="modal" class="dropdown-item"><i
                                                class="bx bx-trash me-2"></i></a>
                                   
                            </td>
                        </tr>
                        <?php $i++; } }else{ ?>
                        <tr>
                            <td colspan="4" class="text-center text-xs">No Data Found</td>
                        </tr>
                        <?php }  ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--/ Basic Bootstrap Table --> 
    </div>
    <!-- / Content --> 
    <!-- Modal -->
   <!--  this is used for add -->   
    <div class="modal modal-top fade" id="modaltop1" role="dialog">
        <div class="modal-dialog modal-md">
            <form class="modal-content" action="<?php echo base_url().'admin/consignment_update'; ?>" method="post" id="one">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTopTitle">Consignment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div> 
                <div class="modal-body">
                    <input type="hidden" name="id" id="id">
                    <div class="row">
                        <div class="col mb-0"> 
                            <label>Consignment No.</label>
                            <select name="vs_code" id="vs_code" class="select2 form-select">
                                <option value="">Select</option>
                                <?php if(!empty($vs_code)){
                              foreach($vs_code as $row){?>
                                <option value="<?php echo $row['vs_code'];?>">
                                    <?php echo $row['vs_code'];?>
                                </option>
                                <?php } } ?> 
                            </select> 
                        </div>
                        <div class="col mb-3">         
                            <label>Lorry No.</label>
                            <input type="text" id="lorry_no" name="lorry_no"
                                class="form-control form-control-alternative">
                        </div>  
                        </div>
                    <div class="row">
                        <div class="col mb-0">
                            <label>To</label>
                            <textarea type="text" id="consignment_to" name="consignment_to"
                                class="form-control form-control-alternative"></textarea>
                        </div>
                        <div class="col mb-3">
                            <label>From</label>
                            <textarea type="text" id="consignment_from" name="consignment_from"
                                class="form-control form-control-alternative"></textarea>
                        </div> 
                    </div>
                    <div class="row"> 
                        <div class="col mb-0">
                            <label>Date</label>
                            <input type="date" id="consignment_date" name="consignment_date"
                                class="form-control form-control-alternative">
                        </div>
                        <div class="col mb-3">
                            <label>Time</label>
                            <input type="time" id="consignment_time" name="consignment_time"
                                class="form-control form-control-alternative">
                        </div>
                     </div>
                    <div class="row">
                        <div class="col mb-3">
                            <label>Current Status</label>
                            <textarea type="text" id="consignment_status" name="consignment_status"
                                class="form-control form-control-alternative" style="border: 1px solid red;"></textarea>
                        </div>
                    </div>
                  </div>
                <input type="hidden" id="ee_id" name="ee_id">
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="submit" class="btn btn-primary" name="submit_form" id="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>
</div>

<!-- this is used for edit -->  
<div class="modal modal-top fade" id="modaltop" role="dialog">
        <div class="modal-dialog modal-md">
            <form class="modal-content" action="<?php echo base_url().'admin/consignment_update'; ?>" method="post" id="two">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTopTitle">Consignment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> 
                </div> 
                <div class="modal-body">
                    <input type="hidden" name="id" id="id1">  
                    <div class="row">
                        <div class="col mb-0"> 
                            <label>Consignment No.</label>
                            <input type="text" name="vs_code" id="vs_code_one" class="form-control form-control-alternative">
                        </div>
                        <div class="col mb-3">         
                            <label>Lorry No.</label>
                            <input type="text" id="lorry_no_one" name="lorry_no"
                                class="form-control form-control-alternative">
                        </div>  
                        </div>
                    <div class="row">
                        <div class="col mb-0">
                            <label>To</label>
                            <textarea type="text" id="consignment_to_one" name="consignment_to"
                                class="form-control form-control-alternative"></textarea>
                        </div>
                        <div class="col mb-3">
                            <label>From</label>
                            <textarea type="text" id="consignment_from_one" name="consignment_from"
                                class="form-control form-control-alternative"></textarea>
                        </div> 
                       
                    </div>
                     <div class="row">  
                        <div class="col mb-0">
                            <label>Date</label>
                            <input type="date" id="consignment_date_one" name="consignment_date"
                                class="form-control form-control-alternative">
                        </div>
                        <div class="col mb-3">
                            <label>Time</label>
                            <input type="time" id="consignment_time_one" name="consignment_time"
                                class="form-control form-control-alternative">
                        </div>
                     </div>
                    <div class="row">
                        <div class="col mb-3">
                            <label>Current Status</label>
                            <textarea type="text" id="consignment_status_one" name="consignment_status"
                                class="form-control form-control-alternative" style="border: 1px solid red;"></textarea>
                        </div>
                    </div>
                  </div>
                <input type="hidden" id="ee_id_one" name="ee_id">
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="submit" class="btn btn-primary" name="submit_form" id="submit1">Submit</button>
                </div> 
            </form> 
        </div>
    </div>
</div>
</div>
</div>
</div>

<!-- this is used for view edit popup --> 
<div class="modal modal-top fade" id="modaltop_one" role="dialog"> 
    <div class="modal-dialog modal-lg">
        <form class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTopTitle">Consignment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="">    
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th> 
                                <th>TIME</th>
                                <th>LORRY NO</th> 
                                <th>FROM</th>
                                <th>TO</th>
                                <th style="color:red">CURRENT STATUS</th>
                            </tr>
                        </thead>
                        <tbody id="hh">   
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
                <!-- <button type="submit" class="btn btn-primary" name="submit_form">Submit</button> -->
            </div>
        </form>
    </div>
</div>
<script> 
function get_area(vs_code, ee_id, consignment_date, consignment_from, consignment_to, lorry_no, consignment_time, consignment_status, id, table_name) {  
            $("#id1").val(id);
            $('#vs_code_one').val(vs_code);  
            $('#ee_id_one').val(ee_id);  
            $("#consignment_date_one").val(consignment_date);
            $("#consignment_from_one").val(consignment_from);
            $("#lorry_no_one").val(lorry_no);
            $("#consignment_to_one").val(consignment_to);
            $('').val(consignment_time);
            $('').val(consignment_status);  
             
      } 

function clear(elements) {
    var errors = 0;
    $.each(elements, function(index, element) {
        $('#modaltop' + element).val('');
        errors++;
    });
}

function delete_company(id, table_name) {
    var del = confirm("Do you want to delete this?")
    if (del) {
        $.ajax({
            url: '<?php echo base_url(strtolower($controller_name).'/delete_data/');?>' + id + '/' + table_name,
            type: "POST",
            data: {
                id: id
            },
            success: function(response) {
                alert(response);
                location.reload()
            }
        });
    }
}
</script>  
<script>
function get_area_one(id) {
    clear(['id']);
    $("#modaltop_one").modal('show');    
    var name_id = id;
    // alert(name_id);   
    $.ajax({
        type: "GET",
        url: '<?php echo base_url();?>admin/get_con_kh_data',
        data: {
            "id": name_id
        },
        dataType: 'json',
        success: function(data) {
            $('#hh').html("");
            var html = '';
            for (var i = 0; i < data.length; i++) {
                html += '<tr>' +
                    '<td>' + data[i].consignment_date + '</td>' +
                    '<td>' + data[i].consignment_time + '</td>' +
                    '<td>' + data[i].lorry_no + '</td>' +
                    '<td>' + data[i].consignment_from + '</td>' +
                    '<td>' + data[i].consignment_to + '</td>' +
                    '<td>' + data[i].consignment_status + '</td>' +
                    '</tr>';
            }
            $('#hh').append(html);

        }
    });
}

function clear(elements) {
    var errors = 0;
    $.each(elements, function(index, element) {
        $('#modaltop_one' + element).val('');
        errors++;
    });
}
</script>
<script>
/*auto fill for bank details*/
$(document).ready(function(){
    $('.select2').select2();
    $("#vs_code").on("change" , function() {
    var vs_code = $("#vs_code").val();
    // alert(vs_code);
    $.ajax({
        type: "GET",
        url: '<?php echo base_url('admin/get_bilti');?>',
        data: {
            id: vs_code
        },
        dataType: 'json',
        success: function(data) {
            console.log(data);
            $('#lorry_no').val(data.from_bilti.lorry_no);
            $('#consignment_to').val(data.from_bilti.to_bilti);
            $('#consignment_from').val(data.from_bilti.from_bilti);
            $('#consignment_date').val(data.from_bilti.con_date);

        }
    });
});
});
</script>