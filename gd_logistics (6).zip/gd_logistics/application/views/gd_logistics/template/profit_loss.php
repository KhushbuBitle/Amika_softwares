<!-- Content wrapper -->
<?php $CI =&get_instance(); ?>
<div class="content-wrapper">
	<!-- Content -->
	<div class="container-xxl flex-grow-1 container-p-y">
		<?php if(!empty($this->session->flashdata('success_message'))){ ?>
			<div class="row mt-3">
				<div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
					<div class="alert alert-success alert-dismissible">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?= $this->session->flashdata('success_message');?>
					</div>
				</div>
			</div>
		<?php } ?>
		<!-- Basic Bootstrap Table -->
		<div class="card">
			<div class="card-header">
				<div class="row">
					<div class="col-md-8 col-sm-8 col-xs-8 col-lg-8">
						<h5>Profit / Loss</h5>
					</div>
					<div class="col-sm-4">
						<a href="<?= base_url().'admin/add_bilti'; ?>"
						   class="btn btn-primary doctor_btn">Add Bilti</a>
					</div>
					<div>
						<form method="GET" name="form" action="<?php echo base_url().'admin/profit_loss';?>">
							<div class="row">  
								<div class="col-3">
									<div class="form-group">
										<label for="cc-payment" class="control-label mb-1">From</label>
										<input id="start_date" name="start_date" type="date" value="<?php echo $_GET['start_date']; ?>" class="form-control">
									</div>
								</div>
								<div class="col-3">
									<div class="form-group">
										<label for="cc-payment" class="control-label mb-1">To</label>
										<input id="end_date" name="end_date" type="date" value="<?php echo $_GET['end_date']; ?>" class="form-control">
									</div>
								</div>
								<div class="col-2 mt-4">
									<div class="form-group">
											<input id="search" name="search" type="submit" class="form-control" style="background-color: #696cff;color: white;">
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<hr>
			<div class="table-responsive text-nowrap">
				<table class="table datatableid">
					<thead>
					<tr>
						<th>#</th>
						<th>CNS no.</th>
						<th>Date</th>
						<th>LHC No.</th>
						<th>LHC Date</th>
						<th>CNS Amount</th>
						<th>LHC Amount</th>
						<th>Difference</th>
						<th>Profit/Loss (in %)</th>
						<th>Bill no.</th>
						<th>Amount</th>
					</tr>
					</thead>
					<tbody class="table-border-bottom-0">
					<?php if(!empty($pl)){ $i=1; foreach($pl as $data) {
						?>

						<tr>
							<td><?= $i;?></td>
							<td><?= $data->vs_code;?></td>
							<td><?= $data->con_date;?></td>
							<td><?= $data->lorry_hire_contact_no;?></td>
							<td><?= $data->lorry_hire_date;?></td>
							<td><?= $data->grand_amount;?></td>
							<td><?= $data->total_amount_rs;?></td>
							<td><?= $value = ($data->grand_amount) - ($data->total_amount_rs); ?></td>
							<td><?php $kl = $value / $data->grand_amount * 100;
								if($value < 0)
								{ echo "<button class=\"btn btn-danger\">".$kl."%"."</button>";
								}else{
									echo "<button class=\"btn btn-success\">".$kl."%"."</button>";
								} ?>
							</td>
							<td><?= $data->bill_no;?></td>
							<td><?= $data->total_amount;?></td>
						</tr>
						<?php $i++; } }else{ ?>
						<tr>
							<td colspan="4" class="text-center text-xs">No Data Found</td>
						</tr>
					<?php }?>
					</tbody>
				</table>
			</div>
		</div>
		<!--/ Basic Bootstrap Table -->
	</div>
	<!-- / Content --><?php
