<!-- Content wrapper -->
<?php $CI =&get_instance(); ?>   
<div class="content-wrapper">
<!-- Content -->
<div class="container-xxl flex-grow-1 container-p-y">
   <?php if(!empty($this->session->flashdata('success_message'))){ ?>
   <div class="row mt-3">
      <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
         <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
         </div>      
      </div>          
   </div>
   <?php } ?>
   <!-- Basic Bootstrap Table -->
   <div class="card">
      <div class="card-header">
         <div class="row">
            <div class="col-md-8 col-sm-8 col-xs-8 col-lg-8">
               <h5>Bilti List</h5>
            </div>
            <div class="col-sm-4">
               <a href="<?php echo base_url().'admin/add_bilti'; ?>"
                  class="btn btn-primary doctor_btn">Add Bilti</a>
            </div>
         </div>
      </div>
      <hr>
      <div class="table-responsive text-nowrap">  
         <table class="table datatableid">
            <thead>
               <tr>
                  <th>SR.</th>
                  <th>CNC NO.</th>
                  <th>CONSIGNOR NAME</th>
                  <th>CONSIGNOR MOB.</th>
                  <th>CONSIGNEE NAME</th>
                  <th>CONSIGNEE MOB.</th>
                  <th>INSURANCE COM.</th>
                  <th>ACTION</th>   
               </tr>
            </thead>
            <tbody class="table-border-bottom-0">  
               <?php if(!empty($bilti)){ $i=1; foreach($bilti as $key){?> 
               <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $key->vs_code;?></td> 
                  <td><?php echo $CI->seees_customer_name('m_consignor_details',$key->consignor_company_name);?></td>
                  <td><?php echo $key->consignor_phone_no;?></td>
                  <td><?php echo $CI->seees_consignee_name('m_consignee_details',$key->consignee_company_name);?></td>
                  <td><?php echo $key->consignee_phone_no;?></td>
                  <td><?php echo $key->insurance_company; ?></td> 
                  <td>
                    
                        
                           <a class="btn btn-sm rounded-pill btn-warning" href="<?php echo base_url('admin/view_bilti/'.$key->id); ?>"
                              ><i class='bx bx-street-view me-2'></i></i></a>
                           <a class="btn btn-sm rounded-pill btn-info" href="<?php echo base_url('admin/edit_bilti/'.$key->id); ?>"
                              ><i class="bx bx-edit-alt me-2"></i></a>
                           <a class="btn btn-sm rounded-pill btn-danger" onclick='return checkdelete()' href="<?php echo base_url('admin/delete_bilti/'.$key->id); ?>"
                              ><i class="bx bx-trash me-2"></i></a> 
                       
                  </td>  
               </tr>
               <?php $i++; } }else{ ?>  
               <tr>
                  <td colspan="4" class="text-center text-xs">No Data Found</td>
               </tr>
               <?php }  ?>
            </tbody>
         </table>
      </div>
   </div>
   <!--/ Basic Bootstrap Table -->
</div>
<!-- / Content -->