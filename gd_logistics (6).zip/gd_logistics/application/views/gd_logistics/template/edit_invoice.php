<div class="content-wrapper">
   <div class="container-xxl flex-grow-1 container-p-y">
      <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span>Invoice</h4>
      <!-- Basic Layout -->
      <div class="row">
         <div class="col-xl">     
            <div class="card mb-4">  
               <div class="card-header d-flex justify-content-between align-items-center">  
                  <h5 class="mb-0">Invoice</h5>
               </div>      
               <div class="card-body"> 
                  <form action="<?php echo base_url().'admin/update_invoice/'.$invoice_details->id; ?>" enctype="multipart/form-data" method="POST">
                     <div class="row mt-3">
                     <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text"><strong>Consignment No.</strong></label>
                              <input type="text" class="form-control" id="vs_code" name="vs_code" value="<?php echo $invoice_details->vs_code; ?>" style="border:1px solid red;">          
                           </div>
                        </div>
                     <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Invoice No.</label>  
                              <input type="text" class="form-control" id="invoice_no" name="invoice_no" value="<?php echo $invoice_details->invoice_no; ?>">          
                           </div>
                        </div>  
                           
                        <div class="col-sm-4">  
                           <div class="form-group">
                              <label class="floating-label" for="Text"><strong>Consignment Date</strong></label>
                              <input type="date" class="form-control" id="consignment_date" name="consignment_date" value="<?php echo $invoice_details->consignment_date; ?>">          
                           </div>
                        </div>
                     </div>
                      <p class="mt-5" style="font-weight: bold;"><u>Bill Station Address</u></p> 
                      <div class="row mt-3">   
                  
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Bill No./Freight Bill</label>
                              <input type="text" class="form-control" id="bill_no" name="bill_no" value="<?php echo $invoice_details->bill_no; ?>">
                           </div>
                        </div> 
                          <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Date</label>
                              <input type="date" class="form-control" id="invoice_bill_date" name="invoice_bill_date" value="<?php echo $invoice_details->invoice_bill_date; ?>" >
                           </div>    
                        </div>  
                          
                     </div>
                     <div class="row mt-3">       
                        <div class="col-sm-4">
                           <div class="form-group">
                              <?php if($invoice_details->tbb_for == 'Consignor'){ ?>
                              <label class="floating-label" for="Text">Customer Name</label>
                              <select name="owner_name" id="owner_name" class="select2 form-select">
                        <option value="">Select</option>
                        <?php if(!empty($company_name)){
                           foreach($company_name as $row){
                              if($invoice_details->owner_name==$row['id']){$s="selected";}else{$s="";}?>
                        <option value="<?php echo $row['id'];?>" <?php echo $s;?>>
                           <?php echo $row['customer_name'];?> 
                        </option>
                        <?php } } ?>   
                     </select>
                     <?php }else{ ?>
                        <select name="owner_name" id="owner_name" class="select2 form-select">
                        <option value="">Select</option>
                        <?php if(!empty($company)){
                           foreach($company as $row){
                              if($invoice_details->owner_name==$row['id']){$s="selected";}else{$s="";}?>
                        <option value="<?php echo $row['id'];?>" <?php echo $s;?>>
                           <?php echo $row['company_name'];?>
                        </option>
                        <?php } } ?>     
                     </select>

                        <?php } ?>
                           </div> 
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Customer Address</label>
                              <textarea type="text" class="form-control" id="customer_address" name="customer_address"><?php echo $invoice_details->customer_address; ?></textarea>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST No.</label>
                              <input type="text" class="form-control" id="gst_no" name="gst_no" value="<?php echo $invoice_details->gst_no; ?>">
                           </div>
                        </div> 
                     </div>
                     <div class="row mt-3">
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Booking Station</label>
                              <input type="text" class="form-control" id="booking_station" name="booking_station" value="<?php echo $invoice_details->booking_station; ?>">
                           </div>
                        </div>
                        <!-- <div class="col-sm-4">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Date</label>   
                              <input type="date" class="form-control" id="bill_date" name="bill_date" value="<?php echo $invoice_details->bill_date; ?>">
                           </div>
                        </div>   -->
                        <div class="col-sm-4">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Destination</label>
                              <input type="text" class="form-control" id="destination" name="destination" value="<?php echo $invoice_details->destination; ?>">
                           </div>   
                        </div>
                     </div>
                      <div class="row mt-3">
                        
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Truck No.</label>
                              <input type="text" class="form-control" id="truck_no" name="truck_no" value="<?php echo $invoice_details->truck_no; ?>">          
                           </div>
                        </div>
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Charge Weight,MT</label>
                              <input type="text" class="form-control" id="charge_weight_mt" name="charge_weight_mt" value="<?php echo $invoice_details->charge_weight_mt; ?>">
                           </div>
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate</label>
                              <input type="text" class="form-control" id="rate" name="rate" value="<?php echo $invoice_details->rate; ?>">
                           </div>   
                        </div>
                        
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Freight Amount</label>
                              <input type="text" class="form-control" id="freight_amount" name="freight_amount" value="<?php echo $invoice_details->freight_amount; ?>">
                           </div>
                        </div>
                     </div>
                      <div class="row mt-3">
                       
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Unloading Charge</label>
                              <input type="text" class="form-control" id="unloading_charge" name="unloading_charge" value="<?php echo $invoice_details->unloading_charge; ?>">
                           </div>   
                        </div>
                        <div class="col-sm-3">    
                           <div class="form-group">
                              <label class="floating-label" for="Text">Detention Charge</label>
                              <input type="text" class="form-control" id="detention" name="detention" value="<?php echo $invoice_details->detention; ?>">
                           </div>  
                        </div> 
                        <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Other Charge</label>
                              <input type="text" class="form-control" id="other_charge" name="other_charge"  value="<?php echo $invoice_details->other_charge; ?>">
                           </div>
                        </div> 
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Total Amount</label>  
                              <input type="text" class="form-control name_list total_amount" id="total_amount" name="total_amount" value="<?php echo $invoice_details->total_amount; ?>" style="border:1px solid red;">          
                           </div>
                        </div> 
                     </div>
                     <div class="row mt-3">
                     <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">SGST(9%)</label>
                              <input type="text" class="form-control" id="sgst" name="sgst" value="<?php echo $invoice_details->sgst; ?>">          
                           </div>  
                        </div>  
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">CGST(9%) / IGST(9%)</label>
                              <input type="text" class="form-control" id="cgst_igst" name="cgst_igst"  value="<?php echo $invoice_details->cgst_igst; ?>">          
                           </div>     
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">GST Amount</label>
                              <input type="text" class="form-control" id="gst_amount" name="gst_amount" value="<?php echo $invoice_details->gst_amount; ?>">          
                           </div>  
                        </div>  
                        <div class="col-sm-4">             
                           <div class="form-group radio-group">        
                           <input type="hidden" class="form-control" id="tbb_for" name="tbb_for" value="<?php echo $invoice_details->tbb_for; ?>">   
                           </div>   
                        </div> 
                           </div>
                           <div class="row mt-3">
               <div class="col-sm-12">
                  <div class="form-group">
                              <label class="floating-label" for="Text">Remarks</label>  
                              <textarea type="text" class="form-control" id="remarks" name="remarks"><?php echo $invoice_details->remarks;?></textarea>
                  </div>
               </div>
               </div>
                     <div class="row mt-2" >
                     <div class="col-sm-3">
                           
                              <input type="hidden" class="form-control" id="sgst_amount" name="sgst_amount"  value="<?php echo $invoice_details->sgst_amount; ?>">          
                           
                        </div>
                     <div class="col-sm-3">
                          
                              <input type="hidden" class="form-control" id="cgst_igst_amount" name="cgst_igst_amount" value="<?php echo $invoice_details->cgst_igst_amount; ?>">          
                           
                        </div>     
                     </div> 
                      <div class="row">
                        <div class="col-sm-3">
                          
                        </div>
                        <div class="col-sm-3"></div>
                        <div class="col-sm-3"></div>
                     <div class="col-sm-3"></div>       
                    </div>   

               <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-2" >                              
               <div id="dynamic_field">     
                   <?php foreach ($dynamic_invoice_details as $row) : ?> 
                       <input type="hidden" name="invoice_id" id="invoice_id" value="<?php echo $row['invoice_id']; ?>">
                        <input type="hidden" name="form_three_id[]" value="<?php echo $row['id']; ?>">      
                     <div class="row mt-3"> 
                        <div class="col-sm-3">
                           <div class="form-group">  
                              <label class="floating-label" for="Text">Booking Station</label>
                              <input type="text" class="form-control" id="booking_station_one" value="<?php echo $row['booking_station_one']; ?>" name="booking_station_one[]">
                           </div>   
                        </div>     
                         <div class="col-sm-3">
                           <div class="form-group">  
                              <label class="floating-label" for="Text"><strong>Consignment No.</strong></label>
                              <input type="text" class="form-control" id="vs_code_one" value="<?php echo $row['vs_code_one']; ?>" name="vs_code_one[]" style="border:1px solid red;">          
                           </div>
                        </div>  
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text"><strong>Consignment Date</strong></label>
                              <input type="date" class="form-control" id="consignment_date_one" value="<?php echo $row['consignment_date_one']; ?>" name="consignment_date_one[]">           
                           </div>
                        </div>
                        <div class="col-sm-3"> 
                           <div class="form-group">
                              <label class="floating-label" for="Text">Destination</label> 
                              <input type="text" class="form-control" id="destination_one" value="<?php echo $row['destination_one']; ?>" name="destination_one[]">
                           </div>
                        </div>
                        <div class="col-sm-3"> 
                           <div class="form-group">
                              <label class="floating-label" for="Text">Truck No.</label>
                              <input type="text" class="form-control" id="truck_no_one" value="<?php echo $row['truck_no_one']; ?>" name="truck_no_one[]" >          
                           </div>
                        </div>
                        <div class="col-sm-3"> 
                           <div class="form-group">
                              <label class="floating-label" for="Text">Charge Weight,MT</label>
                              <input type="text" value="<?php echo $row['charge_weight_mt_one']; ?>" class="form-control" id="charge_weight_mt_one" name="charge_weight_mt_one[]"> 
                           </div>
                        </div>
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Rate</label>
                              <input type="text" value="<?php echo $row['rate_one']; ?>" class="form-control" id="rate_one" name="rate_one[]"> 
                           </div> 
                        </div>
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Invoice No.</label>
                              <input type="text" class="form-control" id="invoice_no_one" value="<?php echo $row['invoice_no_one']; ?>" name="invoice_no_one[]">           
                           </div>   
                        </div>
                        <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Freight Amount</label>
                              <input type="text" class="form-control" id="freight_amount_one" value="<?php echo $row['freight_amount_one']; ?>" name="freight_amount_one[]">
                           </div>
                        </div>    
                         <div class="col-sm-3">
                           <div class="form-group">
                              <label class="floating-label" for="Text">Unloading Charge</label>
                              <input type="text" class="form-control" id="unloading_charge_one" name="unloading_charge_one[]" value="<?php echo $row['unloading_charge_one']; ?>">  
                           </div>     
                        </div>
                         <div class="col-sm-3">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Total Amount</label>
                              <input type="text" class="form-control name_list total_amount" id="total_amount_one" name="total_amount_one[]" value="<?php echo $row['total_amount_one']; ?>" style="border:1px solid red;">          
                           </div>      
                        </div>  
                        <div class="col-sm-3 mt-4"> 
                             <a href="<?php echo base_url('admin/delete_comm/'.$row['id']); ?>" class="btn btn-sm btn-danger text-white">X</a>   
                        </div>   
                     </div>      
<!--        <button type="button" name="add" id="add" class="btn btn-success">Add More</button>  -->    
                              
                        

                        
                       <?php endforeach; ?>  
                     </div>
                  </div> 
                   <button type="button" name="add" id="add" class="btn btn-success">Add More</button>
                   <div class="row mt-3">
                   <div class="col-sm-9"></div> 
                        <div class="col-sm-3">   
                           <div class="form-group">  
                              <label class="floating-label" for="Text">All Total Amount</label>
                              <input type="text" class="form-control" id="two_total_amount" name="two_total_amount" value="<?php echo $invoice_details->two_total_amount ?>" style="border-color: red;">
                           </div>      
                        </div>  
                   </div>   
                     <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url().'/admin/invoice';?>" class="btn btn-secondary me-md-2">BACK</a>
                        <button type="submit" name="submit_form" class="btn btn-primary">Update</button>
                     </div>  
                  </form>
               </div>
            </div>
         </div>  
      </div>
   </div>
</div>
<script>
   $('#total_amount').click(function(){
   var a1  = parseInt($('#freight_amount').val());
   var a2   = parseInt($('#unloading_charge').val());
   var a3   = parseInt($('#detention').val());
   var a4   = parseInt($('#other_charge').val());
   var a5= a1 + a2 + a3 + a4 ;
   $('#total_amount').val(Math.round(a5));
   })
</script>   
<script>
/*auto fill for bank details*/   
$(document).ready(function(){
    $("#vs_code").on("change" , function() {          
    var vs_code = $("#vs_code").val(); 
    // alert(vs_code);
    $.ajax({
        type: "GET",
        url: '<?php echo base_url('admin/vs_details');?>',                 
        data: {
            id: vs_code      
        }, 
        dataType: 'json',   
        success: function(data) {                         
           console.log(data);  
            if(data[2] == 'Consignee'){    
            $('#owner_name').html("<option value='"+data[0].id+"' selected>"+data[0].company_name+"</option>"); 
            var id  = $("#owner_name").val() + '/m_consignee_details';
            }else{  
            $('#owner_name').append("<option value='"+data[1].id+"' selected>"+data[1].customer_name+"</option>"); 
            var id  = $("#owner_name").val() + '/m_consignor_details';            
            } 
      
     var controller_name = '<?php echo $controller_name; ?>';     
      $.ajax({
           type: "POST",
           url: '<?php echo base_url($controller_name.'/get_consignor_owner_data/');?>', 
           data:{id:id},
           success: function(response){
           var data = JSON.parse(response);
           if(typeof data === 'object' && data !== null){ 
            console.table(data);   
             $('#owner_name').val(data.id);   
             $('#gst_no').val(data.gst_no);
             $('#customer_address').val(data.address);            
           }else{
              alert('Data not found!');     
           }  
      }});
           

        }
    });
});
});
</script>
<script type="text/javascript">               
   /*auto fill form*/   
   $("#vs_code").change(function() {
      var vs_code  = $("#vs_code").val();
      var controller_name = '<?php echo $controller_name; ?>';       
      var type = 'vs_code';    
      $.ajax({
           type: "POST",
           url: '<?php echo base_url($controller_name.'/get_bilti_consignment_data/');?>',
           data:{vs_code:vs_code,type:type},
           success: function(response){
           var data = JSON.parse(response); 
           if(typeof data === 'object' && data !== null){
             $('#booking_station').val(data.from_bilti);   
             $('#destination').val(data.to_bilti);  
             $('#consignment_date').val(data.con_date); 
             $('#invoice_no').val(data.invoice_no);   
             $('#truck_no').val(data.lorry_no);
             $('#charge_weight_mt').val(data.charge_wt); 
             $('#rate').val(data.rate_one); 
             $('#freight_amount').val(data.amount_one);                
            }     
      }});
   });
</script>
<script>  
   /*auto fill broker details*/   
   $("#owner_name").change(function() {
      var id  = $("#owner_name").val();
      var controller_name = '<?php echo $controller_name; ?>';
      $.ajax({
           type: "POST",
           url: '<?php echo base_url($controller_name.'/get_consignor_owner_data/');?>', 
           data:{id:id},
           success: function(response){
           var data = JSON.parse(response);
           if(typeof data === 'object' && data !== null){
            console.table(data);
             $('#owner_name').val(data.id);   
             $('#gst_no').val(data.gst_no);
             $('#customer_address').val(data.address);   
           }else{
              alert('Data not found!');     
           }  
      }});
   });
</script> 
  <script>
$('#gst_amount').click(function(){
   var price = parseInt($('#total_amount').val()); 
   var gst = $('#cgst_igst').val();
   var xyz   =  (gst/100)*price;    
    var a = Math.round(xyz);
    $('#cgst_igst_amount').val(a);
    
    var price_one = $('#total_amount').val();
    var gst_one   = $('#sgst').val();
    var xyz_one   =  (gst_one/100)*price_one;  
    var e = Math.round(xyz_one);
    $('#sgst_amount').val(e);
   
   //alert(price);
 var b =  parseInt($('#cgst_igst_amount').val());
 var c =  parseInt($('#sgst_amount').val());
 $('#gst_amount').val(b + c);
})
</script>
<script>
   $('#all_total_amount').click(function(){
   var a1  = parseInt($('#total_amount').val());
   var a2   = parseInt($('#gst_amount').val());
   var a3= a1 + a2;
   $('#all_total_amount').val(Math.round(a3));
   })
</script>  
<script>
$(document).ready(function(){
  $("#hide").click(function(){
   //alert(1);
    $("#dynamic_field").hide();
  });
  $("#show").click(function(){
    $("#dynamic_field").show();
  });
});
</script>

<script type="text/javascript">      
   $(document).ready(function(){         
   var i=1;  
   $('#add').click(function(){
   i++;  
   $('#dynamic_field').append('<div id="row'+i+'" class="dynamic-added"><div class="row mt-3"><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text">Booking Station</label><input type="text" class="form-control" id="booking_station_one'+i+'" name="booking_station_one[]"></div></div> <div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text"><strong>Consignment No.</strong></label><input type="text" class="form-control" id="vs_code_one'+i+'" name="vs_code_one[]" style="border:1px solid red;">        </div></div><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text"><strong>Consignment Date</strong></label><input type="date" class="form-control" id="consignment_date_one'+i+'" name="consignment_date_one[]"></div></div><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text">Destination</label><input type="text" class="form-control" id="destination_one'+i+'" name="destination_one[]"></div></div><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text">Truck No.</label><input type="text" class="form-control" id="truck_no_one'+i+'" name="truck_no_one[]"></div></div><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text">Charge Weight,MT</label><input type="text" class="form-control" id="charge_weight_mt_one'+i+'"  name="charge_weight_mt_one[]"></div></div><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text">Rate</label><input type="text" class="form-control" id="rate_one'+i+'" name="rate_one"></div></div><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text">Invoice No.</label><input type="text" class="form-control" id="invoice_no_one'+i+'" name="invoice_no_one[]"></div></div><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text">Freight Amount</label><input type="text" class="form-control" id="freight_amount_one'+i+'" name="freight_amount_one[]"></div></div><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text">Unloading Charge</label><input type="text" class="form-control" id="unloading_charge_one'+i+'" name="unloading_charge_one[]" value="0"></div></div><div class="col-sm-3"><div class="form-group"><label class="floating-label" for="Text">Total Amount</label><input type="text" class="form-control name_list total_amount" id="total_amount_one'+i+'" name="total_amount_one[]" style="border:1px solid red;"></div></div><div><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></div></div></div><div id="row'+i+'" class="dynamic-added"></div>');      
    $('#vs_code_one'+i+'').change(function() { 
      //console.log('hello');  
      //alert(1);  
      var vs_code_one  = $('#vs_code_one'+i+'').val();
      //alert(vs_code_one);
      var controller_name = '<?php echo $controller_name; ?>';          
      var type = 'vs_code_one';          
      $.ajax({
           type: "POST",
           url: '<?php echo base_url($controller_name.'/get_bilti_consignment_data_one/');?>',
           data:{vs_code_one:vs_code_one,type:type},
           success: function(response){
           var data = JSON.parse(response); 
           if(typeof data === 'object' && data !== null){
             $('#booking_station_one'+i+'').val(data.from_bilti);   
             $('#destination_one'+i+'').val(data.to_bilti);  
             $('#consignment_date_one'+i+'').val(data.con_date); 
             $('#invoice_no_one'+i+'').val(data.invoice_no);   
             $('#truck_no_one'+i+'').val(data.lorry_no);
             $('#charge_weight_mt_one'+i+'').val(data.charge_wt); 
             $('#rate_one'+i+'').val(data.rate_one); 
             $('#freight_amount_one'+i+'').val(data.amount_one);    
                             
            }         
      }});
   });

    $('#total_amount_one'+i+'').click(function(){
     var one  = parseInt($('#freight_amount_one'+i+'').val());
     var two  = parseInt($('#unloading_charge_one'+i+'').val());
     var three = one + two;
     $('#total_amount_one'+i+'').val(Math.round(three));

  });
   
});  
$(document).on('click', '.btn_remove', function(){  
   var button_id = $(this).attr("id");   
   $('#row'+button_id+'').remove();      
   });     
   }); 
</script>   
 <script type="text/javascript">                  
   /*auto fill form*/   
   $("#vs_code_one").change(function() {
      var vs_code_one  = $("#vs_code_one").val();
      alert(vs_code_one);
      var controller_name = '<?php echo $controller_name; ?>';       
      var type = 'vs_code_one';      
      $.ajax({
           type: "POST",
           url: '<?php echo base_url($controller_name.'/get_bilti_consignment_data_one/');?>',
           data:{vs_code_one:vs_code_one,type:type},
           success: function(response){
           var data = JSON.parse(response); 
           if(typeof data === 'object' && data !== null){
             $('#booking_station_one').val(data.from_bilti);   
             $('#destination_one').val(data.to_bilti);  
             $('#consignment_date_one').val(data.con_date); 
             $('#invoice_no_one').val(data.invoice_no);   
             $('#truck_no_one').val(data.lorry_no);
             $('#charge_weight_mt_one').val(data.charge_wt); 
             $('#rate_one').val(data.rate_one); 
             $('#freight_amount_one').val(data.amount_one);    
                             
            }         
      }});
   });
</script>    
<script>    
  $(document).on('click', "input", function () {
var total = 0;
$('.total_amount').each(function(){
  total += parseFloat($(this).val());
  $('#two_total_amount').val(total); 
})     

})
</script>  