<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span>Lorry Challan</h4>
        <!-- Basic Layout -->
        <div class="row">
            <div class="col-xl">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Lorry Challan</h5> 
                    </div>
                    <div class="card-body">
                        <form action="<?php echo base_url().'admin/add_lorry_challan'; ?>" enctype="multipart/form-data"
                            method="POST">
                            <?php $lorry_type = array('Advance','Lorry Hire Payment','File Copy'); ?>
                            <div class="row">
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Lorry Hire Contract No.</label>
                                        <!-- <input type="text" class="form-control" id="lorry_hire_contact_no" name="lorry_hire_contact_no" value="<?php //echo $lorry_hire_contact_no; ?>" >  -->
                                        <select name="lorry_hire_contact_no" id="lorry_hire_contact_no"
                                            class="form-select">
                                            <option value="">Select</option>
                                            <?php for($i=-100;$i<100;$i++){?>
                                            <?php if(60001 < ($lorry_hire_contact_no + $i)){ ?>
                                            <?php $id = $this->db->where(array('lorry_hire_contact_no'=>($lorry_hire_contact_no + $i)))->get('lorry_challan_details')->num_rows(); ?>
                                            <?php if($id == 0){ ?>
                                            <option value="<?php echo $lorry_hire_contact_no + $i;  ?>">
                                                <?php echo $lorry_hire_contact_no + $i; ?></option>
                                            <?php }}} ?>
                                            <?php for($i=1;$i<100;$i++){?>
                                            <option value="<?php echo $lorry_hire_contact_no + $i;  ?>">
                                                <?php echo $lorry_hire_contact_no + $i; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Lorry Type</label>
                                        <select name="lorry_type" id="lorry_type" class="form-select"
                                            onchange="changeSearchstatus(this.value);">
                                            <option value="">Select</option>
                                            <?php for($i=0;$i<count($lorry_type);$i++){?>
                                            <option value="<?php echo $lorry_type[$i]; ?>">
                                                <?php echo $lorry_type[$i]; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"><strong>CNS No.</strong></label>
                                        <input type="text" class="form-control" id="vs_code" name="vs_code"
                                            style="border:1px solid red;">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"><strong>Lorry No.</strong></label>
                                        <input type="text" class="form-control" id="lorry_no" name="lorry_no"
                                            style="border:1px solid red;">
                                    </div>
                                </div>

                            </div>
                            <div class="row mt-3">

                                <?php $today = date('Y-m-d'); ?>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Date</label>
                                        <input type="date" class="form-control" id="lorry_hire_date"
                                            name="lorry_hire_date" value="<?php echo $today; ?>">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">From(City,State)</label>
                                        <input type="text" class="form-control" id="from_lorry" name="from_lorry">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">To(City,State)</label>
                                        <input type="text" class="form-control" id="to_lorry" name="to_lorry">
                                    </div>
                                </div>

                            </div>
                            <div class="row mt-3">
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Act. Wt.</label>
                                        <input type="text" class="form-control" id="actual_weight" name="actual_weight">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Charge Wt.</label>
                                        <input type="text" class="form-control" id="charge_weight" name="charge_weight">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Pkg.</label>
                                        <input type="text" class="form-control" id="package" name="package">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Challan No.</label>
                                        <input type="text" class="form-control" id="challan_no" name="challan_no">
                                    </div>
                                </div>

                            </div>
                            <div class="row mt-3">

                            </div>
                            <p class="mt-3" style="font-weight: bold;"><u>Lorry Owner Details</u></p>
                            <div class="row mt-3">
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Name</label>
                                        <input type="text" class="form-control" id="owner_name" name="owner_name"
                                            style="border-color:red;">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Mobile No.</label>
                                        <input type="text" class="form-control" id="owner_mobile_no"
                                            name="owner_mobile_no" minlength="10" maxlength="10">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Alternate Mobile No.</label>
                                        <input type="text" class="form-control" id="owner_alt_mobile_no"
                                            name="owner_alt_mobile_no" minlength="10" maxlength="10">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Address</label>
                                        <textarea type="text" class="form-control" id="owner_address"
                                            name="owner_address"></textarea>
                                    </div>
                                </div>

                            </div>
                            <p class="mt-3" style="font-weight: bold;"><u>Broker Details</u></p>
                            <div class="row mt-3">
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Name</label>
                                        <select name="broker_name" id="broker_name" class="form-select">
                                            <option value="">Select</option>
                                            <?php if(!empty($broker)){
                              foreach($broker as $row){?>
                                            <option value="<?php echo $row['id'];?>">
                                                <?php echo $row['broker_name'];?>
                                            </option>
                                            <?php } } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Mobile No.</label>
                                        <input type="text" class="form-control" id="broker_mobile_no"
                                            name="broker_mobile_no" minlength="10" maxlength="10">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Alternate Mobile No.</label>
                                        <input type="text" class="form-control" id="broker_alt_mobile_no"
                                            name="broker_alt_mobile_no" minlength="10" maxlength="10">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Address</label>
                                        <textarea type="text" class="form-control" id="broker_address"
                                            name="broker_address"></textarea>
                                    </div>
                                </div>

                            </div>
                            <p class="mt-3" style="font-weight: bold;"><u>Driver Details</u></p>
                            <div class="row mt-3">
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Name</label>
                                        <input type="text" class="form-control" id="driver_name" name="driver_name">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Mobile No.</label>
                                        <input type="text" class="form-control" id="driver_mobile_no"
                                            name="driver_mobile_no" minlength="10" maxlength="10">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Alternate Mobile No.</label>
                                        <input type="text" class="form-control" id="driver_alt_mobile_no"
                                            name="driver_alt_mobile_no" minlength="10" maxlength="10">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Address</label>
                                        <textarea type="text" class="form-control" id="driver_address"
                                            name="driver_address"></textarea>
                                    </div>
                                </div>

                            </div>
                            <p class="mt-3" style="font-weight: bold;"><u>Hire Particulars</u></p>
                            <div class="row mt-3">
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Rate Per Ton</label>
                                        <input type="text" class="form-control" id="rate_per_ton" name="rate_per_ton">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Charge Wt.</label>
                                        <input type="text" class="form-control" id="hire_charge_wt"
                                            name="hire_charge_wt">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"></label>
                                        <input type="text" class="form-control" id="lorry_hire" name="lorry_hire"
                                            value="Lorry Hire" readonly>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"></label>
                                        <input type="text" class="form-control" id="lorry_amount_rs"
                                            name="lorry_amount_rs" placeholder="Amount Rs.">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-3">
                                </div>
                                <div class="col-sm-3">
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"></label>
                                        <input type="text" class="form-control" id="other_amount" name="other_amount"
                                            value="Other Amount" readonly>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"></label>
                                        <input type="text" class="form-control" id="other_amount_rs"
                                            name="other_amount_rs" placeholder="Amount Rs." value="0">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-3">
                                </div>
                                <div class="col-sm-3">
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"></label>
                                        <input type="text" class="form-control" id="total_amount" name="total_amount"
                                            value="Total Amount" readonly>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"></label>
                                        <input type="text" class="form-control" id="total_amount_rs"
                                            name="total_amount_rs" placeholder="Amount Rs."
                                            style="border:1px solid red;">
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3" style="font-weight: bold;"><u>Advance Detail</u></p>
                            <div class="row mt-3">
                                <!-- <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Mode Of Payment</label>
                              <select name="mode_of_payment" id="mode_of_payment" class="form-control" onchange="changeSearchstatus(this.value);" required>
                    <option>Select</option>
                    <option value="Cash">Cash</option>  
                    <option value="Cheque">Cheque</option> 
                   
                  </select>   
                           </div>
                        </div>         -->
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Cash Amount</label>
                                        <input type="text" class="form-control" id="cash_amount" name="cash_amount">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Cheque Amount</label>
                                        <input type="text" class="form-control" id="cheque_amount" name="cheque_amount"
                                            value="0">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Cheque No.</label>
                                        <input type="text" class="form-control" id="cheque_no" name="cheque_no">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Date</label>
                                        <input type="date" class="form-control" id="advance_date" name="advance_date">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"></label>
                                        <input type="text" class="form-control" id="adv_amount" name="adv_amount"
                                            value="Adv. Amount" readonly>
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text"></label>
                                        <input type="text" class="form-control" id="adv_amount_rs" name="adv_amount_rs"
                                            placeholder="Amount Rs." style="border:1px solid red;">
                                    </div>
                                </div>
                            </div>

                            <p class="mt-3" style="font-weight: bold;"><u>Lorry Hire Balance / Payment</u></p>
                            <div id="to_display" style="display: none;">
                                <div class="row mt-3">
                                    <div class="col-sm-6">
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="net_balance" name="net_balance"
                                                value="Net Balance" readonly>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="net_balance_rs"
                                                name="net_balance_rs" placeholder="Amount Rs."
                                                style="border:1px solid red;">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="to_display_not" style="display: none;">
                                <div class="row">

                                    <div class="col-sm-6">

                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="other_amount"
                                                name="other_amount" value="Other Amount" readonly>
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="ab_other_amount"
                                                name="ab_other_amount" placeholder="Amount Rs." value="0">
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <!-- <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Mode Of Payment</label>
                              <select name="mode_of_payment_one" id="mode_of_payment_one" class="form-control" onchange="changestatus(this.value);" required>
                    <option>Select</option>
                    <option value="Cash">Cash</option>  
                    <option value="Cheque">Cheque</option> 
                   
                  </select>   
                           </div>
                        </div>        -->
                                    <!-- <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Cash Amount</label>
                              <input type="text" class="form-control" id="payment_cash_amount" name="payment_cash_amount">
                           </div>
                        </div> -->
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="deduction" name="deduction"
                                                value="Deduction" readonly>
                                        </div>
                                    </div>
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text">TDS</label>
                                            <input type="text" class="form-control" id="tds" name="tds" value="0">
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text">Shortage</label>
                                            <input type="text" class="form-control" id="shortage" name="shortage"
                                                value="0">
                                        </div>
                                    </div>
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text">Damage</label>
                                            <input type="text" class="form-control" id="damage" name="damage" value="0">
                                        </div>
                                    </div>

                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="damage_amount"
                                                name="damage_amount" placeholder="Amount Rs." style="border-color:red;">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-3">
                                    </div>
                                    <div class="col-sm-3">
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="total_balance_amount"
                                                name="total_balance_amount" value="Total Balance Amount" readonly>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="qq_total_amount"
                                                name="qq_total_amount" placeholder="Amount Rs."
                                                style="border:1px solid red;">
                                        </div>
                                    </div>
                                </div>
                                <p class="mt-3" style="font-weight: bold;"><u>Payment Details</u></p>
                                <div class="row mt-3">
                                    <!-- <div class="col-sm-2">   
                           <div class="form-group">
                              <label class="floating-label" for="Text">Mode Of Payment</label>
                              <select name="mode_of_payment_one" id="mode_of_payment_one" class="form-control" onchange="changestatus(this.value);" required>
                    <option>Select</option>
                    <option value="Cash">Cash</option>  
                    <option value="Cheque">Cheque</option> 
                   
                  </select>   
                           </div>
                        </div>        -->
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text">Cash Amount</label>
                                            <input type="text" class="form-control" id="payment_cash_amount"
                                                name="payment_cash_amount">
                                        </div>
                                    </div>
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text">Cheque Amount</label>
                                            <input type="text" class="form-control" id="payment_cheque_amount"
                                                name="payment_cheque_amount" value="0">
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text">Cheque No.</label>
                                            <input type="text" class="form-control" id="payment_cheque_no"
                                                name="payment_cheque_no">
                                        </div>
                                    </div>
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text">Date</label>
                                            <input type="date" class="form-control" id="advance_date"
                                                name="advance_date">
                                        </div>
                                    </div>
                                    <!-- <div class="col-sm-2">     
                           <div class="form-group">
                              <label class="floating-label" for="Text"></label>
                              <input type="text" class="form-control" id="deduction" name="deduction" value="Deduction" readonly>
                           </div>
                        </div> -->
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="deduction_amount"
                                                name="deduction_amount" placeholder="Amount Rs."
                                                style="border:1px solid red;">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-7">
                                    </div>

                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="deduction_net_balance"
                                                name="deduction_net_balance" value="Net Balance" readonly>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label class="floating-label" for="Text"></label>
                                            <input type="text" class="form-control" id="net_deduction_amount"
                                                name="net_deduction_amount" placeholder="Amount Rs."
                                                style="border:1px solid red;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-5" style="font-weight: bold;"><u>Enclose Paper</u></p>
                            <div class="row mt-3">
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">RC</label>
                                        <input type="text" class="form-control" id="rc" name="rc">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Insurance</label>
                                        <input type="text" class="form-control" id="enclose_insurance"
                                            name="enclose_insurance">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Permit</label>
                                        <input type="text" class="form-control" id="permit" name="permit">
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Pan</label>
                                        <input type="text" class="form-control" id="pan" name="pan">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label class="floating-label" for="Text">Driver Lic</label>
                                        <input type="text" class="form-control" id="driver_lic" name="driver_lic">
                                    </div>
                                </div>
                            </div>
                            <div class="d-grid mt-3 d-md-flex justify-content-md-end">
                                <a href="<?php echo base_url().'admin/lorry_challan';?>"
                                    class="btn btn-secondary me-md-2">BACK</a>
                                <button type="submit" name="submit_form" class="btn btn-primary">SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <script type="text/javascript">
    /*auto fill form*/
    $("#owner_name").click(function() {
        var lorry_no = $("#lorry_no").val();
        var controller_name = '<?php echo $controller_name; ?>';
        var type = 'lorry_no';
        $.ajax({
            type: "POST",
            url: '<?php echo base_url($controller_name.'/get_lorry_owner_data/');?>',
            data: {
                lorry_no: lorry_no,
                type: type
            },
            success: function(response) {
                var data = JSON.parse(response);
                if (typeof data === 'object' && data !== null) {
                    $('#owner_name').val(data.owner_name);
                    $('#owner_mobile_no').val(data.owner_no);
                    $('#owner_alt_mobile_no').val(data.alternate_no);
                    $('#owner_address').val(data.address);
                    $('#rc').val(data.rc);
                    $('#permit').val(data.permit);
                    $('#enclose_insurance').val(data.insurance_no);
                    $('#pan').val(data.pan_no);
                }
            }
        });
    });
    </script>
    <script>
    /*auto fill broker details*/
    $("#broker_name").change(function() {
        var id = $("#broker_name").val();
        var controller_name = '<?php echo $controller_name; ?>';
        $.ajax({
            type: "POST",
            url: '<?php echo base_url($controller_name.'/get_broker_data/');?>',
            data: {
                id: id
            },
            success: function(response) {
                var data = JSON.parse(response);
                if (typeof data === 'object' && data !== null) {
                    console.table(data);
                    $('#broker_name').val(data.id);
                    $('#broker_mobile_no').val(data.mobile_no);
                    $('#broker_alt_mobile_no').val(data.alt_mobile_no);
                    $('#broker_address').val(data.address);
                } else {
                    alert('Data not found!');
                }
            }
        });
    });
    </script>
    <script type="text/javascript">
    /*auto fill form*/
    $("#vs_code").change(function() {
        var vs_code = $("#vs_code").val();
        var controller_name = '<?php echo $controller_name; ?>';
        var type = 'vs_code';
        $.ajax({
            type: "POST",
            url: '<?php echo base_url($controller_name.'/get_bilti_data/');?>',
            data: {
                vs_code: vs_code,
                type: type
            },
            success: function(response) {
                var data = JSON.parse(response);
                if (typeof data === 'object' && data !== null) {
                    $('#from_lorry').val(data.from_bilti);
                    $('#to_lorry').val(data.to_bilti);
                    $('#package').val(data.packages);
                    $('#actual_weight').val(data.actual_wt);
                    $('#charge_weight').val(data.charge_wt);
                    //$('#rate_per_ton').val(data.rate_one); 
                    $('#lorry_amount_rs').val(data.amount_one);
                    $('#cns_no').val(data.vs_code);
                    $('#hire_charge_wt').val(data.charge_wt);
                    $('#lorry_no').val(data.lorry_no);
                    $
                }
            }
        });
    });
    </script>
    <!-- Hire Particular -->
    <script>
    $("#total_amount_rs").click(function() {
        // hire particulars
        var rate = $('#rate_per_ton').val();
        var charge = $('#hire_charge_wt').val();
        var lorry_amount_rs = rate * charge;
        $('#lorry_amount_rs').val(Math.round(lorry_amount_rs));

        var p1 = parseInt($('#lorry_amount_rs').val());
        var p2 = parseInt($('#other_amount_rs').val());
        var p3 = p1 + p2;
        $('#total_amount_rs').val(Math.round(p3));
    });
    </script>
    <script>
    $("#adv_amount_rs").click(function() {
        var r1 = parseInt($('#cash_amount').val());
        var r2 = parseInt($('#cheque_amount').val());
        var r3 = r1 + r2;
        $('#adv_amount_rs').val(Math.round(r3));

    })
    </script>
    <script>
    $("#net_balance_rs").click(function() {
        var total = parseInt($('#total_amount_rs').val());
        var adv = parseInt($('#adv_amount_rs').val());
        var abc = total - adv;
        $('#net_balance_rs').val(Math.round(abc));
    });
    </script>
    <script>
    $("#deduction_amount").click(function() {
        var b1 = parseInt($('#payment_cash_amount').val());
        var b2 = parseInt($('#payment_cheque_amount').val());
        var b3 = b1 + b2;
        $('#deduction_amount').val(Math.round(b3));
    });
    </script>
    <script>
    $("#ab_total_amount").click(function() {
        var p1 = parseInt($('#ab_balance_rs').val());
        var p2 = parseInt($('#ab_other_amount').val());
        var p3 = p1 + p2;
        $('#ab_total_amount').val(Math.round(p3));
    });
    </script>
    <script>
    $("#qq_total_amount").click(function() {
        var t1 = parseInt($('#net_balance_rs').val());
        var t2 = parseInt($('#ab_other_amount').val());
        var t3 = t1 + t2;
        var t5 = parseInt($('#damage_amount').val());
        var t6 = t3 - t5;

        $('#qq_total_amount').val(Math.round(t6));
    });
    </script>

    <script>
    $("#damage_amount").click(function() {
        // advance details
        var c4 = parseInt($('#tds').val());
        var c5 = parseInt($('#shortage').val());
        var c6 = parseInt($('#damage').val());
        var c7 = c4 + c5 + c6;
        // $('#damage_amount').val(Math.round(c7));

        // var d8 =   parseInt($('#deduction_amount').val());
        //var d9   = parseInt($('#damage_amount').val());
        //var d10= d8 + d9 ;
        //var d11 = parseInt($('#ab_total_amount').val()); 
        // $('#qq_total_amount').val(d10-d11);
        $('#damage_amount').val(c7);
    });
    </script>

    <script>   
    $("#net_deduction_amount").click(function() {
        // advance details
        var d8 = parseInt($('#deduction_amount').val());
        var d9 = parseInt($('#qq_total_amount').val());
        $('#net_deduction_amount').val(d9 - d8);
    });
    </script>
    <script>
    //Confirmed and reject fields showing
    function changeSearchstatus(type) {
        if (type == "Advance") {
            document.getElementById('to_display').style.display = "block";
            document.getElementById('to_display_not').style.display = "none";
        }
        if (type == "Lorry Hire Payment") {
            document.getElementById('to_display_not').style.display = "block";
            document.getElementById('to_display').style.display = "block";
        }
        if (type == "File Copy") {
            document.getElementById('to_display_not').style.display = "block";
            document.getElementById('to_display').style.display = "block";
        }

    }
    </script>