<style type="text/css">
	.radio-group {
		padding-left: 10px;
		margin-top: 10px;
		margin-bottom: 20px;
	}

	.radio-group label::after {
		content: '\00a0\00a0\00a0\00a0';
		/* eq &nbsp; x 4 */
	}

	.hrBorder {
		margin: 0px !important;
	}

	.hr-line {
		position: relative;
		display: inline-block;
		margin-left: 5px;
		margin-right: 5px;
		width: 100%;
		border-bottom: 1px solid #7A7A7A;
	}

	.custom {
		display: inline;
	}
</style>
<?php $CI = &get_instance(); ?>
<div class="content-wrapper">
	<div class="container-xxl flex-grow-1">
		<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span>Invoice</h4>
		<!-- Basic Layout -->
		<div class="row">
			<div class="col-xl">
				<div class="card mb-4">
					<div class="card-header d-flex justify-content-between align-items-center">
						<button class="btn btn-primary txt-white btn-animated from-top" onClick="printdiv('print_character');"><span>PRINT</span>
						</button>
						<a href="<?php echo base_url() . 'admin/invoice'; ?>" class="btn btn-secondary me-md-2">BACK</a>
					</div>
					<form action="<?php echo base_url() . 'admin/view_invoice/' . $info->id; ?>" enctype="multipart/form-data" method="POST" id="print_character">
						<div class="card-body">
							<div>
								<table class="table-border w-100">

									<thead>
										<tr class="m-5" style="border:1px solid black;">
											<td><img src="<?= document_url('settings_logo/') . $info_one->logo; ?>" width="150px" height="150px"></td>
											<td colspan="6">
												<h4 style="color:#5a62ce;font-weight:bold;text-align:center;">Freight Invoice</h4>
												<h1 class="text-uppercase" style="color:#b60c0c;font-weight:bold;text-align:center;"><?= $info_one->company_name; ?></h1>
												<div>
													<span class="align-content-start m-2 " style="float: left">PAN No. : <strong>AAKCG1444K</strong></span>
													<span class="justify-content-end m-2 " style="float: right">GST No. : <strong>27AAKCG1444K1ZF</strong></span>
												</div>
											</td>
										</tr>  
									</thead>
									<hr>
									<tbody>
										<tr class="m-5" style="border:1px solid black;">
											<td colspan="1" style="border:1px solid black; padding: 5px;">
												<div class="col-md-4 custom m-2">
													<span class="d-flex mx-2"><strong>Bill No. :&nbsp;<?php echo $info->bill_no; ?></strong></span>
													<span class="d-flex mx-2">Date:&nbsp;
														<strong>
															<?php if (date('d-m-Y', strtotime($info->invoice_bill_date)) == "01-01-1970") {
																echo "";
															} else {
																echo date('d-m-Y', strtotime($info->invoice_bill_date));
															} ?>
														</strong>
													</span>
												</div>
											</td>
											<td colspan="9" style="padding: 20px;">
												<div class="col-md-6 custom">
													<span class="d-flex mx-2">Bill Station Address: &nbsp;<strong><?= $info_one->address; ?></strong></span>
													<span class="d-flex mx-2">Phone No. :&nbsp;<strong><?= $info_one->mobile_no; ?></strong></span>
													<span class="d-flex mx-2">Email: &nbsp;<strong><?= $info_one->email; ?></strong></span>
												</div>
											</td>
										</tr>

										<tr>
											<td style="border:1px solid black;" colspan="6">
												<span class="mx-2">Customer Name:&nbsp;<strong>
														<?php if ($info->tbb_for == 'Consignor') {
															echo $CI->seees_customer_name('m_consignor_details', $info->owner_name);
														} else {
															echo $CI->seees_consignee_name('m_consignee_details', $info->owner_name);
														} ?>
													</strong>
												</span><br>

												<span class="mx-2">Customer Address:&nbsp;<strong><?= $info->customer_address; ?></strong></span><br>
												<span class="mx-2">GST no. :&nbsp;<strong><?= $info->gst_no; ?></strong></span>
											</td>
										</tr>
									</tbody>

								</table>

								<table class="table-border w-100">
									<thead>
										<tr style="text-align: center; background-color:#8080807d;">
											<th style="border:1px solid black;font-size:14px;"><b>Sr. No.</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Booking Station</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>CNS No</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Date</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Destination</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Truck No</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Charge Weight,MT</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Rate</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Invoice No.</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Freight Amount</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Unloading Charge</b></th>
											<th style="border:1px solid black;font-size:14px;"><b>Total Amount</b></th>
										</tr>
									</thead>
									<tbody>
										<tr style="text-align: center;">
											<td style="border:1px solid black;font-size:14px;"> 1 </td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->booking_station; ?></td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->vs_code; ?></td>
											<td style="border:1px solid black;font-size:12px;">
												<?php if (date('d-m-Y', strtotime($info->consignment_date)) == "01-01-1970") {
													echo "";
												} else {
													echo date('d-m-Y', strtotime($info->consignment_date));
												} ?></td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->destination; ?></td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->truck_no; ?></td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->charge_weight_mt; ?></td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->rate; ?></td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->invoice_no; ?></td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->freight_amount; ?></td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->unloading_charge; ?></td>
											<td style="border:1px solid black;font-size:14px;"><?= $info->total_amount; ?>/-</td>
										</tr>
										<?php $demo = $info->id; ?>
										<?php $aa_count = $this->db->where(array('invoice_id' => $demo, 'is_deleted !=' => 9))->get('invoice_dynamic_details')->num_rows(); ?>
										<?php if ($aa_count > 0) {  ?>
											<?php $data = $this->db->where(array('invoice_id' => $demo, 'is_deleted !=' => 9))->get('invoice_dynamic_details')->result();
											$j = 2;
											foreach ($data as $row111) { ?>
												<tr style="text-align: center;">
													<td style="border:1px solid black;font-size:14px;"><?= $j; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->booking_station_one; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->vs_code_one; ?></td>
													<td style="border:1px solid black;font-size:12px;"><?= $row111->consignment_date_one; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->destination_one; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->truck_no_one; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->charge_weight_mt_one; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->rate_one; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->invoice_no_one; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->freight_amount_one; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->unloading_charge_one; ?></td>
													<td style="border:1px solid black;font-size:14px;"><?= $row111->total_amount_one; ?>/-</td>
												</tr>
											<?php $j++;
											} ?>
										<?php } ?>
										<tr style="border:2px solid black;">
											<td style="border:1px solid black; border-left:white" colspan="10">&nbsp;In Words:-<strong>
													<?php
													$number = $info->two_total_amount;
													$no = floor($number);
													$point = round($number - $no, 2) * 100;
													$hundred = null;
													$digits_1 = strlen($no);
													$i = 0;
													$str = [];
													$words = [
														"0" => "",
														"1" => "One",
														"2" => "Two",
														"3" => "Three",
														"4" => "Four",
														"5" => "Five",
														"6" => "Six",
														"7" => "Seven",
														"8" => "Eight",
														"9" => "Nine",
														"10" => "Ten",
														"11" => "Eleven",
														"12" => "Twelve",
														"13" => "Thirteen",
														"14" => "Fourteen",
														"15" => "Fifteen",
														"16" => "Sixteen",
														"17" => "Seventeen",
														"18" => "Eighteen",
														"19" => "Nineteen",
														"20" => "Twenty",
														"30" => "Thirty",
														"40" => "Forty",
														"50" => "Fifty",
														"60" => "Sixty",
														"70" => "Seventy",
														"80" => "Eighty",
														"90" => "Ninety",
													];
													$digits = ["", "Hundred", "Thousand", "Lakh", "Crore"];
													while ($i < $digits_1) {
														$divider = $i == 2 ? 10 : 100;
														$number = floor($no % $divider);
														$no = floor($no / $divider);
														$i += $divider == 10 ? 1 : 2;
														if ($number) {
															$plural = ($counter = count($str)) && $number > 9 ? "s" : null;
															$hundred = $counter == 1 && $str[0] ? " and " : null;
															$str[] =
																$number < 21 ? $words[$number] . " " . $digits[$counter] . " " . $hundred : $words[floor($number / 10) * 10] . " " . $words[$number % 10] . " " . $digits[$counter] . " " . $hundred;
														} else {
															$str[] = null;
														}
													}
													$str = array_reverse($str);
													$result = implode("", $str);
													$points = $point
														? "." . $words[$point / 10] . " " . $words[($point = $point % 10)]
														: "";
													echo $result . "Only"; ?></strong>
											</td>

											<td colspan="1" style="border-left-color: white">
												Total Amount:
											</td>

											<td colspan="1" align="center" style="border:1px solid black; justify-content-end; ">
												<strong><?php echo $info->two_total_amount; ?>/- Rs.</strong>
											</td>
										</tr>
									</tbody>
									<tfoot>
										<tr>
											<td class="p-4" colspan="10" style="border:1px solid black;">
												<span class="d-flex flex-column"><b><u>TERMS AND CONDITIONS</u></b></span>
												<span class="d-flex flex-column">1) The Payment of the bill should be made only by an Account Payee Cheque/DD/NEFT/RTGS.</span>
												<span class="d-flex flex-column">2) Interst @ 2% P.M. or part there of will be charged, if bill is not paid on due date as per contract.</span>
												<span class="d-flex flex-column"><b>3) GST ON REVERSE CHARGE TO BE PAID BY SERVICE RECEIVER.</b></span>
												<span class="d-flex flex-column"><b>4) Our Bank Account detail as below</b></span>
												<span class="d-flex flex-column" class="text-center"><b>AXIS BANK A/C NO. : 922020004679229</b></span>
												<span class="d-flex flex-column"><b>Branch Name : Wadi,Nagpur(MH)</b></span>
												<span class="d-flex flex-column"><b>IFSC CODE:UTIB0002011</b></span>
											</td>
											<td colspan="2" class="text-center" style="border:1px solid black;" <span><b>Signature</b></span></td>
										</tr>

										<tr>
											<td colspan="12" ; style="border:1px solid black;">
												<b>&nbsp;Remark:&nbsp;<?= $info->remarks; ?></b>
											</td>
										</tr>

									</tfoot>
								</table>


							</div>
						</div>
					</form>
					<div class="card-footer d-grid mt-3 d-md-flex justify-content-md-end">
						<a href="<?php echo base_url() . 'admin/invoice'; ?>" class="btn btn-secondary me-md-2">BACK</a>
					</div>
				</div>
			</div>
		</div>