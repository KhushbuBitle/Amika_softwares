<!DOCTYPE html>
<html
  lang="en"
  class="light-style customizer-hide"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
    <title>Shipment & Container Tracking</title>  
    <meta name="description" content="" />
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />
    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/css/pages/page-auth.css" />
    <!-- Helpers -->
    <script src="<?php echo base_url();?>assets/vendor/js/helpers.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
  </head>
 <body style="background-image: url('<?php echo base_url(); ?>assets/img/tracking_bg.jpg');background-size:cover; height:auto; width:100%;">         
    <div class="container-fluid">
      <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner" style="max-width:680px;">
          <div class="card">
            <div class="card-body">  
                <h3 style="text-align:center;color:#f88502;" class="text-uppercase">Guru Drashti Logistics Pvt.Ltd.</h3> 
                <hr>
			  <?php 
                        $msg = $this->session->flashdata('msg');
                        if($msg != "") {
                        ?> 
                     <div class="alert alert-success alert-dismissible">
                       <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
                        <?php echo $msg; ?> 
                     </div>
                     <?php
                        }
            ?>
              <h4 class="mb-2" style="text-align:center;">Shipment Tracking</h4>
              <p class="mb-4" style="text-align:center;">Check your booking type and enter your tracking number.</p>
                <br>
			  <form method="GET" name="my_form" action="<?php echo base_url().'tracking/consignment_report';?>">  
              <div class="row" style="align-content:center;"> 
              <div class="col-4">
                  <h5 class="mt-2" style="float:right;">Consignment Number</h5>
                    </div>
                    <div class="col-6"> 
                    <input id="name" name="name" type="text" value="<?php echo $_GET['name']; ?>" class="form-control">  
                    </div>
                  <div class="col-2">
					        <center>
                  <input id="search_code" name="search_code" value="Track" type="submit"class="btn btn-block mb-4" style="background-color:#f88502; color:white; float:left;"> 
				          </center> 
                </div>
                </div>  
                <br>
                <p class="mb-4" style="text-align:center;">Hint : Consignment number is made of 5 digits.</p>
              </form>
<br>
              <p class="text-center">
			  <a href="https://amikasoftwares.com/" style="font-size:13px; color:">Designed & Developed by Amika Softwares</a>
              </p>
            </div>   
          </div>
        </div> 
      </div>
    </div>
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo base_url();?>assets/vendor/libs/jquery/jquery.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/libs/popper/popper.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/js/bootstrap.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="<?php echo base_url();?>assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="<?php echo base_url();?>assets/js/main.js"></script>
    <!-- Page JS -->
    <!-- Place this tag in your head or just before your close body tag. -->
    <!-- <script async defer src="https://buttons.github.io/buttons.js"></script> -->
  </body>
</html>
