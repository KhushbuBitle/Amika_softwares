<!-- Content wrapper -->
<div class="content-wrapper">
	<!-- Content -->
	<div class="container-xxl flex-grow-1 container-p-y">
		<?php if(!empty($this->session->flashdata('success_message'))){ ?>
			<div class="row mt-3">
				<div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
					<div class="alert alert-success alert-dismissible">
						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?= $this->session->flashdata('success_message');?>
					</div>
				</div>
			</div>
		<?php } ?>
		<!-- Basic Bootstrap Table -->
		<div class="card">
			<div class="card-header">
				<div class="row">
					<div class="col-md-8 col-sm-8 col-xs-8 col-lg-8">
						<h5>Count</h5>
					</div>
					<div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 col-xs-4">
						<a href="<?php echo base_url().("fleet/new_trip/".$uri); ?>" class="btn btn-primary doctor_btn">Add New Trip</a>
					</div>
				</div>

			</div>
			<hr>
			<div class="table-responsive text-nowrap">
				<table class="table datatableid" >
					<thead>
					<!--					<tr>-->
					<!--						<form method="POST" action="--><?php //= base_url().'fleet/trip_log';?><!--">-->
					<!--							<td>From:<input class="form-control" type="date" id="start_date" name="start_date"></td>-->
					<!--							<td>To:<input class="form-control" type="date" id="end_date" name="end_date"></td>-->
					<!--							<td><button class="btn btn-info" action="submit">Search</button></td>-->
					<!--						</form>-->
					<!--					</tr>-->
					<div class="row">
						<form method="GET" name="between_dates" action="<?php echo base_url().'fleet/trip_log';?>">
							<div class="col-2 mx-4">
								<div class="form-group">
									<label for="cc-payment" for="start_date" class="control-label mb-1">From</label>
									<input id="start_date" name="start_date" type="date" value="<?php echo $_GET['start_date']; ?>" class="form-control">
								</div>
							</div>
							<div class="col-2">
								<div class="form-group">
									<label for="end_date" class="control-label mb-1">To</label>
									<input id="end_date" name="end_date" type="date" value="<?php echo $_GET['end_date']; ?>" class="form-control">
								</div>
							</div>
							<div class="col-1 mt-4">
								<div class="form-group">
									<input id="trip_between" name="trip_between" value="Search" type="submit"  class="form-control" style="background-color: #696cff;color: white;">
								</div>
							</div>
					</div>
					</thead>
					<tbody class="table-border-bottom-0">
					<tr>
						<th>#</th>
						<th>No. of Consignments</th>
						<th>No. of Bilti</th>
						<th>Total Charge weight</th>
						<th>No. of CNS</th>
					</tr>
					<?php foreach ($bilti_count as $ln) { ?>
					<?php foreach ($charge_sum as $sum) { ?>
						<tr>
							<td><?= $i; ?></td>
							<td></td>
							<td><?= $ln->count;?></td>
							<td><?= $sum->charge; ?></td>
							<td></td>
							<td></td>
						</tr>
					<?php } }?>
<!--						<tr>-->
<!--							<td colspan="6" class="text-center text-xs">No Data Found</td>-->
<!--						</tr>-->
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<!--/ Basic Bootstrap Table -->
</div>
<!-- / Content -->


