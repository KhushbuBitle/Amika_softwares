<?php $CI =&get_instance(); ?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <?php if(!empty($this->session->flashdata('success_message'))){ ?>
        <div class="row mt-3">
            <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert"
                        aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
                </div>
            </div>
        </div>
        <?php } ?>
        <!-- Basic Bootstrap Table -->
        <div class="card">
            <div class="card-header"></div>
            <div class="card-body">
                <div class="card-title">
                    <h4 class="text-center title-2">Bilti Report</h4> 
                </div>
                <form method="GET" name="form" action="<?php echo base_url().'admin/bilti_cns_report';?>">
                    <div class="row">
                        <div class="col-2">
                            <div class="form-group">
                                <label for="cc-payment" class="control-label mb-1">From</label>
                                <input id="start_date" name="start_date" type="date"
                                    value="<?php echo $_GET['start_date']; ?>" class="form-control">
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label for="cc-payment" class="control-label mb-1">To</label>
                                <input id="end_date" name="end_date" type="date"
                                    value="<?php echo $_GET['end_date']; ?>" class="form-control">
                            </div>
                        </div> 
                        <div class="col-2">
                            <div class="form-group">
                                <label for="cc-payment" class="control-label mb-1">Consignor / Consignee</label>
                                <select name="name" id="name" class="form-select" value="<?php echo $_GET['name']; ?>">
                                    <option>Select</option> 
                                    <option value="Consignor"
                                        <?php if($_GET['name'] == "Consignor"){ echo "selected";}?>>Consignor</option>
                                    <option value="Consignee"
                                        <?php if($_GET['name'] == "Consignee"){ echo "selected";}?>>Consignee</option> 
                                    
                            </select>
                            </div>
                        </div>
                        
                        <div class="col-2 mt-4">
                            <div class="form-group">
                                <input id="search" name="search" value="Search" type="submit" class="form-control"
                                    style="background-color: #696cff;color: white;">
                            </div>
                        </div>
                    </div>
                </form>
              


            </div>

            <!--/ Basic Bootstrap Table -->

            <!-- / Content -->
            <div class="row ">
                <div class="col-7">
                    <h4 class="mb-0"></h4>
                </div>
                <div class="col-5 text-right">
                    <button class="btn btn-animated from-top" style="background-color:#fc6e26; color:white;"
                        onClick="printdiv('print_character');"><span>PRINT</span></button>
                    <button type="submit" class="btn" style="background-color:#1e3d8d; color:white;"
                        data-toggle="tooltip" data-placement="bottom" title="Downlod in CSV"
                        onclick="download_csv('csv_download_table')" id="download_data">DOWNLOAD
                        CSV</button>
                    <input type="button" class="btn" value="Back" onclick="goBack()"
                        style="background-color: #fc6e26;color: white;">
                </div>
            </div>
            <div class="table-responsive p-4" id="print_character">
                <div class="ed border-dark">
                    <table width='100%' border='1' id="csv_download_table" class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th class="text-center">Sr.No.</th>
                                <th>CNC NO.</th>
                                <th>TBB FOR</th>   
                                <th>CONSIGNOR NAME</th>
                                <th>CONSIGNOR MOBILE NO.</th>
                                <th>CONSIGNEE NAME</th>
                                <th>CONSIGNEE MOBILE NO.</th>
                                <th>INSURANCE COM.</th>

                            </tr>

                        </thead>
                        <tbody>
                            <?php   
                     if(!empty($report)){  
                        $i=1; foreach($report as $key){?>
                               <tr class="text-center">
                                <td class="text-center"><?php echo $i;?></td>
                                <td class="text-center"><?php echo $key->vs_code;?></td>
                                <td class="text-center"><?php echo $key->tbb_for;?></td>
                                <td class="text-center">
                                    <?php echo $CI->seees_customer_name('m_consignor_details',$key->consignor_company_name);?>
                                </td>
                                <td class="text-center"><?php echo $key->consignor_phone_no;?></td>
                                <td class="text-center">
                                    <?php echo $CI->seees_consignee_name('m_consignee_details',$key->consignee_company_name);?>
                                </td>
                                <td class="text-center"><?php echo $key->consignee_phone_no;?></td>
                                <td class="text-center"><?php echo $key->insurance_company; ?></td>
                            </tr>

                            <?php $i++; } }else{ ?>
                            <tr>
                                <td colspan="10" class="text-center text-xs">No Data Found</td>
                            </tr>
                            <?php } ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>