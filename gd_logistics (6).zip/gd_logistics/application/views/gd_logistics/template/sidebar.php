 <!-- Layout wrapper -->
 <div class="layout-wrapper layout-content-navbar">
     <div class="layout-container">
         <!-- Guru Drashti Logistics Pvt.Ltd. -->
         <!-- Menu -->
         <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
             <?php $user_role = $_SESSION['user_role']; ?>
             <div class="app-brand text-center">
                 <a href="index.html">
                <img src="<?php echo document_url('settings_logo/').$info_one->logo; ?>" width="75%" height="75%">
                     <h3>GD Logistics</h3>
                     </a>
               </div>

             <?php if($user_role == 'admin'){ ?>
             <ul class="menu-inner py-1">
                 <!-- Dashboard -->
                 <li class="menu-item active">
                     <a href="<?php echo base_url().'admin'; ?>" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-home-circle"></i>
                         <div data-i18n="Analytics">Dashboard</div>
                     </a>
                 </li>
                 <li class="menu-item">
                     <a href="<?php echo base_url().'settings'; ?>" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Company Settings</div>
                     </a>
                 </li>
                 <li class="menu-item">
                     <a href="javascript:void(0);" class="menu-link menu-toggle">
                         <i class="menu-icon tf-icons bx bx-dock-top"></i>
                         <div data-i18n="Account Settings">Master</div>
                     </a>
                     <ul class="menu-sub">
                         <li class="menu-item">
                             <a href="<?php echo base_url().'master/consignor';?>" class="menu-link">
                                 <div data-i18n="Account">Consignor</div>
                             </a>
                         </li>
                         <li class="menu-item">
                             <a href="<?php echo base_url().'master/lorry_owner';?>" class="menu-link">
                                 <div data-i18n="Notifications">Lorry Owner Details</div>
                             </a>
                         </li>
                         <li class="menu-item">
                             <a href="<?php echo base_url().'master/broker'; ?>" class="menu-link">
                                 <div data-i18n="Connections">Broker Details</div>
                             </a>
                         </li>
                         <li class="menu-item">
                             <a href="<?php echo base_url().'master/consignee'; ?>" class="menu-link">
                                 <div data-i18n="Connections">Consignee</div>
                             </a>
                         </li>
                     </ul>
                 </li>
                 <!-- Components -->
                 <!-- Cards -->
                 <!--  <li class="menu-item">
              <a href="cards-basic.html" class="menu-link">
                <i class="menu-icon tf-icons bx bx-collection"></i>
                <div data-i18n="Basic">Cards</div>
              </a>
            </li> -->
                 <!-- User interface -->
                 <li class="menu-item">
                     <a href="<?php echo base_url().'staff'; ?>" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Staff</div>
                     </a>
                 </li>
                 <li class="menu-item">
                     <a href="<?php echo base_url().'admin/bilti'; ?>" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Bilti</div>
                     </a>
                 </li>  
                 <li class="menu-item">
                     <a href="<?php echo base_url().'admin/lorry_challan'; ?>" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Lorry Challan</div>
                     </a>   
                 </li>  
				 
				
                 <li class="menu-item">
                     <a href="<?php echo base_url().'admin/invoice'; ?>" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Invoice</div>
                     </a>
                 </li>
                 <li class="menu-item">
                     <a href="<?php echo base_url().'admin/payment_receipt'; ?>" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Payment Receipt</div>
                     </a>
                 </li>

                 <!-- <li class="menu-item">
              <a href="cards-basic.html" class="menu-link">
                <i class="menu-icon tf-icons bx bx-collection"></i>
                <div data-i18n="Basic">Payment Receipt</div>
              </a>
            </li>   -->
                 <li class="menu-item">
                     <a href="javascript:void(0);" class="menu-link menu-toggle">
                         <i class="menu-icon tf-icons bx bx-dock-top"></i>
                         <div data-i18n="Account Settings">Report</div>
                     </a>
                     <ul class="menu-sub">
                     <li class="menu-item">
					 <a href="<?php echo base_url().'admin/profit_loss'; ?>" class="menu-link">
						 <!-- <i class="menu-icon tf-icons bx bx-collection"></i> -->
						 <div data-i18n="Basic">Profit/Loss</div>
					 </a>  
				 </li>
                 <li class="menu-item">
					 <a href="<?php echo base_url().'admin/count'; ?>" class="menu-link">
						 <!-- <i class="menu-icon tf-icons bx bx-collection"></i> -->
						 <div data-i18n="Basic">Count</div>
					 </a>
				 </li>
                         <li class="menu-item">
                             <a href="<?php echo base_url().'admin/invoice_report';?>" class="menu-link">
                                 <div data-i18n="Account">Invoice Report</div>
                             </a>
                         </li>
                         <li class="menu-item">
                             <a href="<?php echo base_url().'admin/lorry_hire_payment_report';?>" class="menu-link">
                                 <div data-i18n="Account">Lorry Hire Report</div>
                             </a>
                         </li>
                         <li class="menu-item">
                             <a href="<?php echo base_url().'admin/payment_receipt_report';?>" class="menu-link">
                                 <div data-i18n="Account">Payment Receipt Report</div>
                             </a>
                         </li>

                         <!-- <li class="menu-item">
                  <a href="<?php //echo base_url().'admin/gst_report'; ?>" class="menu-link">
                    <div data-i18n="Connections">GST Report</div>
                  </a>  
                </li> -->
                         <li class="menu-item">
                             <a href="<?php echo base_url().'admin/tbb_for_report'; ?>" class="menu-link">
                                 <div data-i18n="Connections">Consignor/Consignee Report</div>
                             </a>
                         </li>
                         <!-- <li class="menu-item">
                  <a href="<?php //echo base_url().'admin/bilti_cns_report'; ?>" class="menu-link">
                    <div data-i18n="Connections">CNS Report</div>
                  </a>  
                </li> -->
                     </ul>
                 </li>
                 <li class="menu-item">
                     <a href="<?php echo base_url('admin/consignment_update') ?>" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic" style="color:red;">Consignment Update</div>
                     </a>
                 </li>
             </ul>
             <?php } ?>

             <?php if($user_role == 'staff'){ ?>
             <ul class="menu-inner py-1 mt-4">
                 <!-- Dashboard -->
                 <li class="menu-item active">
                     <a href="index.html" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-home-circle"></i>
                         <div data-i18n="Analytics">Dashboard</div>
                     </a>
                 </li>
                 <li class="menu-item">
                     <a href="<?php echo base_url().'settings'; ?>" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Company Settings</div>
                     </a>
                 </li>
                 <li class="menu-item">
                     <a href="javascript:void(0);" class="menu-link menu-toggle">
                         <i class="menu-icon tf-icons bx bx-dock-top"></i>
                         <div data-i18n="Account Settings">Master</div>
                     </a>
                     <ul class="menu-sub">
                         <li class="menu-item">
                             <a href="<?php echo base_url().'master/consignor';?>" class="menu-link">
                                 <div data-i18n="Account">Consignor</div>
                             </a>
                         </li>
                         <li class="menu-item">
                             <a href="<?php echo base_url().'master/lorry_owner';?>" class="menu-link">
                                 <div data-i18n="Notifications">Lorry Owner Details</div>
                             </a>
                         </li>
                         <li class="menu-item">
                             <a href="<?php echo base_url().'master/broker'; ?>" class="menu-link">
                                 <div data-i18n="Connections">Broker Details</div>
                             </a>
                         </li>
                     </ul>
                 </li>
                 <!-- Components -->
                 <!-- Cards -->
                 <!--  <li class="menu-item">
              <a href="cards-basic.html" class="menu-link">
                <i class="menu-icon tf-icons bx bx-collection"></i>
                <div data-i18n="Basic">Cards</div>
              </a>
            </li> -->
                 <!-- User interface -->
                 <li class="menu-item">
                     <a href="javascript:void(0)" class="menu-link menu-toggle">
                         <i class="menu-icon tf-icons bx bx-box"></i>
                         <div data-i18n="User interface">Users</div>
                     </a>
                     <ul class="menu-sub">
                         <li class="menu-item">
                             <a href="ui-accordion.html" class="menu-link">
                                 <div data-i18n="Accordion">Staff</div>
                             </a>
                         </li>
                         <!--  <li class="menu-item">
                  <a href="ui-alerts.html" class="menu-link">
                    <div data-i18n="Alerts">Client</div>
                  </a>
                </li> -->
                     </ul>
                 </li>
                 <li class="menu-item">
                     <a href="cards-basic.html" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Bilti</div>
                     </a>
                 </li>

                 <li class="menu-item">
                     <a href="cards-basic.html" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Lorry Challan</div>
                     </a>
                 </li>
                 <li class="menu-item">
                     <a href="cards-basic.html" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Invoice</div>
                     </a>
                 </li>
                 <!-- <li class="menu-item">
              <a href="cards-basic.html" class="menu-link">
                <i class="menu-icon tf-icons bx bx-collection"></i>
                <div data-i18n="Basic">Payment Receipt</div>
              </a>
            </li>   -->
                 <li class="menu-item">
                     <a href="cards-basic.html" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Reports</div>
                     </a>
                 </li>
                 <li class="menu-item">
                     <a href="cards-basic.html" class="menu-link">
                         <i class="menu-icon tf-icons bx bx-collection"></i>
                         <div data-i18n="Basic">Consignment Update</div>
                     </a>
                 </li>
             </ul>
             <?php } ?>
         </aside>
         <!-- / Menu -->
