<?php $CI =&get_instance(); ?>
<!-- Content wrapper -->
<div class="content-wrapper">    
<!-- Content -->
<div class="container-xxl flex-grow-1 container-p-y">
   <?php if(!empty($this->session->flashdata('success_message'))){ ?>
   <div class="row mt-3">
      <div class="col-sm-12 col-xs-12 col-lg-12 col-md-12">
         <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_message');?>
         </div>      
      </div>           
   </div>
   <?php } ?>
   <!-- Basic Bootstrap Table -->
   <div class="card">
      <div class="card-header"></div>   
      <div class="card-body">
         <div class="card-title">
            <h4 class="text-center title-2">GST Report</h4>   
         </div>  
        
         <form method="GET" name="form" action="<?php echo base_url().'admin/gst_report';?>">
            <div class="row">
               <div class="col-4">
                  <div class="form-group">
                     <label for="cc-payment" class="control-label mb-1">From</label>
                     <input id="start_date" name="start_date" type="date" value="<?php echo $_GET['start_date']; ?>" class="form-control">  
                  </div>
               </div>
               <div class="col-4">
                  <div class="form-group">
                     <label for="cc-payment" class="control-label mb-1">To</label>
                     <input id="end_date" name="end_date" type="date" value="<?php echo $_GET['end_date']; ?>" class="form-control">
                  </div>
               </div>
               <div class="col-2 mt-4">
                  <div class="form-group">
                     <input id="search" name="search" value="Search" type="submit"  class="form-control" style="background-color: #696cff;color: white;">
                  </div> 
               </div>   
            </div>   
         </form>    
         <form method="GET" name="my_form" action="<?php echo base_url().'admin/gst_name_client';?>" class="mt-3">
            <div class="row">
   
               <div class="col-4">    
                  <div class="form-group">
                     <label for="cc-payment" class="control-label mb-1">Customer Name</label>
                     <select name="name" id="name" class="form-select">
                  <option value="">Select</option>
                  <?php if(!empty($owner_name)){
                     foreach($owner_name as $row){
                     if($_GET['name']==$row['id']){$s="selected";}else{$s="";}
                  ?>
                  <option value="<?php echo $row['id'];?>" <?php echo $s;?>>
                     <?php echo $row['owner_name'];?>
                  </option>
                  <?php } } ?>  
               </select>        
                  </div>
               </div>
               <div class="col-2 mt-4">
                  <div class="form-group">
                     <input id="search_code" name="search_code" value="Search" type="submit" class="form-control" style="background-color: #696cff;color: white;">  
                  </div>
               </div>
            </div>
         </form> 
         <div class="row align-items-center">
            <div class="col-7">
               <h4 class="mb-0"></h4>
            </div>
            <div class="col-5 text-right">
               <button class="btn btn-animated from-top" style="background-color:#fc6e26; color:white;" onClick="printdiv('print_character');" ><span>PRINT</span></button>
               <button type="submit" class="btn" style="background-color:#1e3d8d; color:white;"  data-toggle="tooltip" data-placement="bottom" title="Downlod in CSV"  onclick="download_csv('csv_download_table')" id="download_data">DOWNLOAD CSV</button>
               <input type="button" class="btn" value="Back" onclick="goBack()" style="background-color: #fc6e26;color: white;">   
            </div>  
         </div>
         <!-- DATA TABLE-->                   
         <div class="table-responsive p-4" id="print_character">
         <div class="ed border-dark">
            <table width='100%' id="csv_download_table" class="table table-bordered">
               <thead class="thead-light">
                  <tr>
                     <td colspan="15">
                        <center>
                        <h4>GST Report</h4>    
                     </td> 
                  </tr>
                  <tr class="text-center">
                     <th class="text-center">Sr.No.</th>
                     <th class="text-center">Customer Name</th>
                     <th class="text-center">Invoice No.</th>
                     <th class="text-center">Date</th>
                     <th class="text-center">Total Amount</th>  
                     <th class="text-center">SGST Amount</th>
                     <th class="text-center">CGST/IGST Amount</th>
                     <th class="text-center">GST Amount</th>
                     <!-- <th class="text-center">All Total Amount</th>  -->
                    
                     
                  </tr>       
               </thead>                            
               <tbody>        
                  <?php   
                     if(!empty($report)){  
                        $i=1; foreach($report as $key){?>
                  <tr>
                     <td class="text-center"><?php echo $i;?></td>  
                     <td class="text-center"><?php echo $CI->seees_owner_name('m_consignor_details',$key->owner_name);?></td>
                     <td class="text-center"><?php echo $key->invoice_no; ?></td>
                     <td class="text-center"><?php echo $key->invoice_bill_date; ?></td>
                     <td class="text-center"><?php echo $key->total_amount;?></td>
                     <td class="text-center"><?php echo $key->sgst_amount;?></td>
                     <td class="text-center"><?php echo $key->cgst_igst_amount;?></td>
                     <td class="text-center"><?php echo $key->gst_amount;?></td>
                     <!-- <td class="text-center"><?php //echo $key->all_total_amount;?></td> -->
                    
                   
                    
                  </tr>
                  <?php  $sum     +=  $key->total_amount;?>   
                  <?php  $sum_one     +=  $key->sgst_amount;?> 
                  <?php  $sum_two     +=  $key->cgst_igst_amount;?>    
                  <?php  $sum_three     +=  $key->cgst_igst_amount;?> 
                   
                      
                 
                 

                  <?php $i++; } }else{ ?>              
                  <tr>
                     <td colspan="10" class="text-center text-xs">No Data Found</td>
                  </tr>
                  <?php } ?> 
                  <tr>
                     <td colspan="4" style="text-align:center;"><b>Total</b></td>  
                     <td><h5 style="padding: 5px;text-align:center;"><?php  echo 'Rs. '.$sum;?>.00 </h5></td>
                     <td><h5 style="padding: 5px;text-align:center;"><?php  echo 'Rs. '.$sum_one;?>.00 </h5></td>
                     <td><h5 style="padding: 5px;text-align:center;"><?php  echo 'Rs. '.$sum_two;?>.00 </h5></td>
                     <td><h5 style="padding: 5px;text-align:center;"><?php  echo 'Rs. '.$sum_three;?>.00 </h5></td>
                    
                    
                    
                  </tr> 
                 
               </tbody>
            </table>
                  </div>
         </div>
         <!-- END DATA TABLE-->  
      </div>
   </div>
   <!--/ Basic Bootstrap Table -->
</div>
<!-- / Content -->