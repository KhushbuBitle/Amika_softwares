<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin_model extends MY_Model {
    public function __construct(){
        parent::__construct();  
    }
    //check_login     
    public function check_login() {
        $login       = $_SESSION['logged_in'];
        $role        = $_SESSION['user_role'];
        $first_name  = $_SESSION['first_name'];
        $last_name   = $_SESSION['last_name'];
        if ($login == TRUE && ($role == 'admin')){
            return 1;    
        } else {
            return 0;  
        }  
    }  
    //get_bilti_id      
    public function get_bilti_id(){
        $count      = $this->db->query('SELECT vs_code FROM bilti_details');
        if ($count->num_rows() > 0){
            $query  = $this->db->query('SELECT MAX(vs_code) AS vs_code FROM bilti_details');
            $result = $query->row();
            return $result->vs_code + 1;
        }else{
            return '50001';    
        }
    }   
    //get_challan_id        
    public function get_challan_id(){
        $count      = $this->db->query('SELECT lorry_hire_contact_no FROM lorry_challan_details');
        if ($count->num_rows() > 0){
            $query  = $this->db->query('SELECT MAX(lorry_hire_contact_no) AS lorry_hire_contact_no FROM lorry_challan_details');
            $result = $query->row();
            return $result->lorry_hire_contact_no + 1;
        }else{
            return '60001';      
        }
    } 
     //get_invoice_id    
     public function get_invoice_id(){
        $count      = $this->db->query('SELECT invoice_no FROM invoice_details');
        if ($count->num_rows() > 0){
            $query  = $this->db->query('SELECT MAX(invoice_no) AS invoice_no FROM invoice_details');
            $result = $query->row();
            return $result->invoice_no + 1;
        }else{
            return '10001';  
        }
    } 
     //get_bill_id      
     public function get_bill_id(){
        $count      = $this->db->query('SELECT bill_no FROM invoice_details');
        if ($count->num_rows() > 0){
            $query  = $this->db->query('SELECT MAX(bill_no) AS bill_no FROM invoice_details');
            $result = $query->row();
            return $result->bill_no + 1; 
        }else{
            return '75001';            
        }
    } 
     //get_receipt_id    
     public function get_receipt_id(){
        $count      = $this->db->query('SELECT receipt_no FROM payment_receipt_details');
        if ($count->num_rows() > 0){
            $query  = $this->db->query('SELECT MAX(receipt_no) AS receipt_no FROM payment_receipt_details');
            $result = $query->row();
            return $result->receipt_no + 1; 
        }else{
            return '40001';  
        } 
    } 
    public function invoice_report($table,$start_date,$end_date){
        $sql = "SELECT * From $table Where `invoice_bill_date` BETWEEN '".$start_date."' AND '".$end_date."'";   
        //$sql="SELECT * From $table Where policy_period_from == '".$start_date."' ";
        $query = $this->db->query($sql); 
      //echo  $this->db->last_query();exit;       
        return $query->result();           
    }  
    public function name_client($name)
	{
		$value  = explode('|', $name);

		if($value[1] == 'Consignee' )
		{
			$sql = "SELECT * FROM invoice_details WHERE `owner_name`= $value[0] AND `tbb_for`= '$value[1]' ";
			$query = $this->db->query($sql);
			return $query->result();
		}else
		{
			$sql = "SELECT * FROM invoice_details WHERE `owner_name`= $value[0] AND `tbb_for`='Consignor' ";
			$query = $this->db->query($sql);
			return $query->result();
		}
	}
     //lorry_hire_payment_report
     public function lorry_hire_payment_report($table,$name){
        $sql = "SELECT * From $table Where lorry_type like '%".$name."%'";   
        $query = $this->db->query($sql);        
        return $query->result();        
    } 
    //payment_receipt_report
    public function payment_receipt_report($table,$name){  
        $sql = "SELECT * From $table Where payment_type like '%".$name."%'";   
        $query = $this->db->query($sql);        
        return $query->result();        
    } 
    //search
    public function search($get_leave){
        $this->db->select('*');
        $this->db->where('vs_code',$get_leave); 
        // $this->db->where('is_deleted !=',9);
        return $this->db->get('bilti_details')->row();  
    }
    //search_vs
    public function search_vs($get_vs){
        $this->db->select('*');
        $this->db->where('vs_code',$get_vs);   
        // $this->db->where('is_deleted !=',9);
        return $this->db->get('bilti_details')->row();  
    }

    public function get_cns($key){
        $this->db->select('*');
        $this->db->where('vs_code',$key); 
        // $this->db->where('is_deleted !=',9);
        return $this->db->get('bilti_details')->row();  
    }
    //get_consignment_id
     public function get_consignment_id(){
        $count      = $this->db->query('SELECT main_id FROM consignment_update_details');
        if ($count->num_rows() > 0){
            $query  = $this->db->query('SELECT MAX(main_id) AS main_id FROM consignment_update_details');
            $result = $query->row();
            return $result->main_id + 1; 
        }else{
            return '1';  
        }
    } 
    //  //search
    //  public function get_search($ab){
    //     $this->db->select('*');
    //     $this->db->where('main_id',$ab); 
    //     // $this->db->where('is_deleted !=',9);
    //     return $this->db->get('consignment_update_details')->result();  
    // }
  //name_client
  public function one_name_client($table,$name){
    $sql = "SELECT * From $table Where vs_code like '".$name."'";  
    $query = $this->db->query($sql);        
    return $query->result();           
} 


public function bilti_data($vs_code)      
{
    $sql = "SELECT `consignor_company_name`,`consignee_company_name` From bilti_details where `vs_code`= $vs_code";   
    $query = $this->db->query($sql);          
    return $query->result();          
}
//bilti report
public function bilti_cns_report($table,$start_date,$end_date,$name){
        $sql = "SELECT * From $table Where `con_date` BETWEEN '".$start_date."' AND '".$end_date."' AND  `tbb_for` like '".$name."'";   
        //$sql="SELECT * From $table Where policy_period_from == '".$start_date."' ";
        $query = $this->db->query($sql);          
        return $query->result();           
    }  
    public function tbb_for_report($table,$name){
    $sql = "SELECT * From $table Where tbb_for like '".$name."'";  
    $query = $this->db->query($sql);        
    return $query->result();          
} 

}
?>
