<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Staff_template_model extends MY_Model {
    public function __construct(){
        parent::__construct(); 
    }
    //check_login
    public function check_login() {
        $login       = $_SESSION['logged_in'];      
        $role        = $_SESSION['user_role'];
        $first_name  = $_SESSION['first_name'];
        $last_name   = $_SESSION['last_name'];
        if ($login == TRUE && ($role == 'staff')){
            return 1;
        } else {
            return 0;  
        }
    }     
    
    

}
?>
