<?php 
   class Login_model extends MY_Model{
    //check_user
    public function check_user($username, $password){
        $this->db->select('username,password');
        $this->db->from('users');
        $this->db->where('username', $username);
        $query = $this->db->get();
        if($query->num_rows()==1){
            $result       = $query->row();
            $hashpassword = $result->password;
            if (password_verify($password,$hashpassword)){
                return 1;
            }else{
                return 0;     
            }
        }else{
            return 0;   
        }
    }
    //change_password
    public function change_password() {
        $new_password = $this->input->post('new_password');
        $username     = $_SESSION['username'];
        $user_id      = $_SESSION['user_id'];
        $user_role    = $_SESSION['user_role'];
        $password     = password_hash($new_password, PASSWORD_DEFAULT);
        $this->db->set(array('password' => $password));
        $this->db->where('username', $username);
        if ($this->db->update('users')) {
            return "Your password is change, Please login using new password!";
        } else {
            return "Your password is not change!";
        }
    }
    // get_user_data 
    public function get_user_data($username){
        $this->db->select('*');
        $this->db->from('users');  
        $this->db->where('username',$username);
        //$this->db->where("(username='$username' OR mobile_no='$username')");
        $query = $this->db->get();
        return $query->row(); 
    }  
    // get_session_data
    public function get_session_data($user_id, $user_role){
        if ($user_role == 'admin' ){
            $table_name = 'admin_login_details';
            $id = 'id';
        }else if($user_role == 'staff'){
            $table_name = 'staff_details';
            $id = 'id';
        }
        $query = $this->db->get_where($table_name, array($id => $user_id));
        return $query->row();
    }
}
?>