<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Master_model extends MY_Model {
    public function __construct(){
        parent::__construct();
    }
    public function check_login() {
        $login = $_SESSION['logged_in'];
        $role  = $_SESSION['user_role'];
        $first_name  = $_SESSION['first_name'];
        $last_name  = $_SESSION['last_name'];
        if ($login == TRUE && ($role == 'admin')){
            return 1;
        } else {
            return 0;
        } 
    } 
     //get_customer_code
    public function get_customer_code(){
       $count      = $this->db->query('SELECT customer_code FROM m_consignor_details');
       if ($count->num_rows() > 0){
           $query  = $this->db->query('SELECT MAX(customer_code) AS customer_code FROM m_consignor_details');
           $result = $query->row();
           return $result->customer_code + 1; 
        }else{
           return '11';
       }
    }  
    //get_consignee_code
    public function get_consignee_code(){
        $count      = $this->db->query('SELECT customer_code FROM m_consignee_details');
        if ($count->num_rows() > 0){
            $query  = $this->db->query('SELECT MAX(customer_code) AS customer_code FROM m_consignee_details');
            $result = $query->row();
            return $result->customer_code + 1; 
         }else{
            return '11';
        }
     }  
    //get_broker_code
    public function get_broker_code(){
       $count      = $this->db->query('SELECT broker_code FROM m_broker_details');
       if ($count->num_rows() > 0){
           $query  = $this->db->query('SELECT MAX(broker_code) AS broker_code FROM m_broker_details');
           $result = $query->row();
           return $result->broker_code + 1; 
        }else{
           return '11';
       }
    } 

}
?>
