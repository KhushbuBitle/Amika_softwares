<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
   class Tracking_model extends MY_Model {
    public function __construct(){
        parent::__construct();
    }
  one_name_client
  public function one_name_client($table,$name){
    $sql = "SELECT * From $table Where vs_code like '".$name."'";  
    $query = $this->db->query($sql);        
    return $query->result();      
        
    }     
}
    ?>

