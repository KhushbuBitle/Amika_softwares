<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$host = $_SERVER['HTTP_HOST']; 

if($host == 'localhost'){           
	$username = 'root';
	$password = '';
	$database = 'gd_logistics';     
	$active_group = 'default';  
}else if($host == 'gdlogistics.in'){ 
	$username = 'gdlogistics_crm548';
	$password = '~FqpZfxkr?}*';
	$database = 'gdlogistics_crm548';
	$active_group = 'server';
}else if($host == 'appsoftinfosystem.in'){ 
	$username = 'appsoft_gd_logistics';
	$password = '[Qh%d8w}RjcU';
	$database = 'appsoft_gd_logistics';
	$active_group = 'server';
}else{
	$username = 'appsoft_gd_logistics';     
	$password = '[Qh%d8w}RjcU';
	$database = 'appsoft_gd_logistics';     
	$active_group = 'server';
}

$temp = explode('.',$_SERVER['HTTP_HOST']);   
if(strlen($temp[0])>16){
	$dbusername = substr($temp[0],0,16);
	$dbname = substr($temp[0],0,16);
}else{
	$dbusername = $temp[0];
	$dbname = $temp[0]; 
}

$query_builder = TRUE;            
$db[$active_group] = array(
	'dsn'	   => '',
	'hostname' => 'localhost',     
	'username' => $username,
	'password' => $password,
	'database' => $database,
	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt'  => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE,
);
?>