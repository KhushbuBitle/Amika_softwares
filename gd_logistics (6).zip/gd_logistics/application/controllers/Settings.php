<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Settings extends MY_Controller{
  public function __construct() {
    parent::__construct();
    //LOAD ALL REQUIRED MODEL
    $this->load->model('Admin_model', 'admin_model');
    // $check = $this->admin_model->check_login();
    //     if ($check == 0) {
    //         redirect('login/logout');
    //     }
    }
    //index
    public function index(){
      $data['controller_name']  = 'settings';
      $data['view']             = 'settings/dashboard';
      $data['page_name']        = '/settings';
      $data['logo']             = $this->my_model->get_single_data('settings_details',array('id' => '1'));
      $data['info']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $this->load->view("gd_logistics/settings/dashboard",$data);
    }
    //update_settings 
    public function update_settings(){
      $id                              =$this->input->post('id', true); 
      $data['company_name']            =$this->input->post('company_name', true);
      $data['email']                   =$this->input->post('email', true);
      $data['email']                   =$this->input->post('email', true);
      $data['pan_no']                  =$this->input->post('pan_no', true);
      $data['gst_no']                  =$this->input->post('gst_no', true);
      $data['cin_no']                  =$this->input->post('cin_no', true);
      $data['address']                 =$this->input->post('address', true);
      $data['website']                 =$this->input->post('website', true);  
      $data['updated_at']              =date('Y-m-d H-i-s');      
      //logo
      $xyz_staff_id                    = $_POST['id'];
      if(!empty($_FILES['logo']['name'])){
        $file_to_upload = 'logo';
        $upload_folder  = 'logo';
        $filename       = strtolower(str_replace(" ","",$xyz_staff_id.''.$file_to_upload));
        $upload_folder  = 'settings_logo';
        $filetypes      = '*';
        $logo  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes); 
      }
      if(!empty($logo)){
        $data = array('logo'=>$logo);
        // print_r($data);
        // exit;
        $this->admin_model->update('settings_details',$data, array('id'=>$xyz_staff_id));
      }
      $result = $this->db->update('settings_details',$data,array('id'=>$id));
      $this->session->set_flashdata('success_message', $result);
      redirect('settings'); 
    }
   

}
?>