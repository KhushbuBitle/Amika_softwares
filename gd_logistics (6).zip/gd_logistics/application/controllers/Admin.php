<?php
defined('BASEPATH') OR exit('No direct script access allowed');      
class Admin extends MY_Controller{
  public function __construct() {
    parent::__construct();  
    //LOAD ALL REQUIRED MODEL
    $this->load->model('Admin_model', 'admin_model');         
    $check = $this->admin_model->check_login();      
        if ($check == 0) {
            redirect('login/logout');                                      
        }                
    }
    //index  
    public function index(){    
      $data['controller_name']  = 'admin';  
      $data['view']             = 'template/dashboard';
      $data['page_name']        = '/body';
      $data['info']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
       //Bilti GRAPH
       $year = date("Y"); 
       $month_data = array();
     for ($months = 1; $months <= 12; $months++) {
       $next_month = $months + 1;
       $where = array("created_mili_second >=" => strtotime($year."-" . $months . "-01"), "created_mili_second <=" => strtotime($year."-" . $next_month . "-01"));
       $jan_count = $this->db->select("count(id) as count")->where($where)->get("bilti_details")->row()->count;
       array_push($month_data, $jan_count);
     }
     $data['month_data'] = $month_data; 
     
         //Invoice GRAPH
         $year = date("Y"); 
         $month_invoice_data = array();
       for ($months = 1; $months <= 12; $months++) {
         $next_month = $months + 1;
         $where = array("created_mili_second >=" => strtotime($year."-" . $months . "-01"), "created_mili_second <=" => strtotime($year."-" . $next_month . "-01"));
         $jan_count = $this->db->select("count(id) as count")->where($where)->get("invoice_details")->row()->count;
         array_push($month_invoice_data, $jan_count);  
       }
       $data['month_invoice_data'] = $month_invoice_data; 

        //Payment GRAPH
        $year = date("Y"); 
        $month_payment_data = array();
      for ($months = 1; $months <= 12; $months++) {
        $next_month = $months + 1;
        $where = array("created_mili_second >=" => strtotime($year."-" . $months . "-01"), "created_mili_second <=" => strtotime($year."-" . $next_month . "-01"));
        $jan_count = $this->db->select("count(id) as count")->where($where)->get("payment_receipt_details")->row()->count;
        array_push($month_payment_data, $jan_count);  
      }
      $data['month_payment_data'] = $month_payment_data; 

       //lorry GRAPH
       $year = date("Y"); 
       $month_lorry_data = array();  
     for ($months = 1; $months <= 12; $months++) {
       $next_month = $months + 1;
       $where = array("created_mili_second >=" => strtotime($year."-" . $months . "-01"), "created_mili_second <=" => strtotime($year."-" . $next_month . "-01"));
       $jan_count = $this->db->select("count(id) as count")->where($where)->get("lorry_challan_details")->row()->count;
       array_push($month_lorry_data, $jan_count);  
     }
     $data['month_lorry_data'] = $month_lorry_data; 
     $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $this->load->view("gd_logistics/template/dashboard",$data);   
    }  
    //add_bilti        
    public function add_bilti (){  
       if(isset($_POST['submit_form'])){

       if(!empty($_FILES['policy_file']['name'])){
        $xyz_staff_id = $_POST['id']; 
        $file_to_upload = 'policy_file';
        $filename = strtolower(str_replace(" ","_",$xyz_staff_id.'_'.$file_to_upload));
        $upload_folder = 'policy_file'; 
        $filetypes = '*';
        $policy_file = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);
        $data['policy_file'] = $policy_file;            
      }    
       //generate bilti id
        // $new_count     = $this->db->query('SELECT vs_code FROM bilti_details');
        // if ($new_count->num_rows() > 0){
        //   $new_query  = $this->db->query('SELECT MAX(vs_code) AS vs_code FROM bilti_details');
        //   $new_result = $new_query->row();
        //   $dd= $new_result->vs_code + 1; 
        // }else{
        //   $dd= '50001';       
        // }
      $data['vs_code']               = $this->input->post('vs_code',true);   
      $data['load_type']             = $this->input->post('load_type',true);  
      $data['door_dilivery']         = $this->input->post('door_dilivery',true); 
      $data['kh_address']            = $this->input->post('kh_address',true); 
      $data['from_address']          = $this->input->post('from_address',true); 
      $data['to_addr']               = $this->input->post('to_addr',true); 
      $data['e_way_bill_no_two']     = $this->input->post('e_way_bill_no_two',true); 
      $data['e_way_bill_no_three']   = $this->input->post('e_way_bill_no_three',true); 
      $data['from_addr']             = $this->input->post('from_addr',true);  
      $data['to_address']            = $this->input->post('to_address',true); 
      $data['tbb_for']               = $this->input->post('tbb_for',true);  
      $data['consignment_copy']      = $this->input->post('consignment_copy',true);  
      $data['copy_type']             = $this->input->post('copy_type',true);   
      $data['insurance_company']     = $this->input->post('insurance_company',true); 
      $data['from_bilti']            = $this->input->post('from_bilti',true);
      $data['from_address_indore']   = $this->input->post('from_address_indore',true);
      $data['policy_no']             = $this->input->post('policy_no',true);
      $data['to_bilti']            = $this->input->post('to_bilti',true);
      $data['consignor_company_name']= $this->input->post('consignor_company_name',true);
      $data['consignor_gst_no']      = $this->input->post('consignor_gst_no',true);
      $data['consignor_phone_no']    = $this->input->post('consignor_phone_no',true);
      $data['consignor_policy_name'] = $this->input->post('consignor_policy_name',true);
      $data['consignor_policy_no'] = $this->input->post('consignor_policy_no',true);
      $data['consignee_address'] = $this->input->post('consignee_address',true);
      $data['consignor_address'] = $this->input->post('consignor_address',true);
        $data['consignee_company_name']= $this->input->post('consignee_company_name',true);
        $data['consignee_gst_no']      = $this->input->post('consignee_gst_no',true);
        $data['consignee_phone_no']    = $this->input->post('consignee_phone_no',true);
        $data['packages']              = $this->input->post('packages',true);
        $data['packing_type']          = $this->input->post('packing_type',true);
        $data['e_way_bill_no']         = $this->input->post('e_way_bill_no',true);
        $data['invoice_no']            = $this->input->post('invoice_no',true);
        $data['declared_value']        = $this->input->post('declared_value',true);
        $data['valid_upto']            = $this->input->post('valid_upto',true);
        $data['lorry_no']              = $this->input->post('lorry_no',true);
        $data['description']           = $this->input->post('description',true);
        $data['actual_wt']             = $this->input->post('actual_wt',true);
        $data['charge_wt']             = $this->input->post('charge_wt',true);
        $data['con_date']              = $this->input->post('con_date',true);
        $data['con_pan_no']            = $this->input->post('con_pan_no',true);
        $data['con_gst_no']            = $this->input->post('con_gst_no',true);
        $data['freight']               = $this->input->post('freight',true);
        $data['rate_one']              = $this->input->post('rate_one',true);
        $data['amount_one']            = $this->input->post('amount_one',true);
        $data['door_delivery']         = $this->input->post('door_delivery',true);  
        $data['rate_two']              = $this->input->post('rate_two',true);
        $data['amount_two']            = $this->input->post('amount_two',true);      
        $data['local_collection']      = $this->input->post('local_collection',true);
        $data['rate_three']            = $this->input->post('rate_three',true);
        $data['amount_three']          = $this->input->post('amount_three',true);
        $data['lr_charge']             = $this->input->post('lr_charge',true);    
        $data['rate_four']             = $this->input->post('rate_four',true);
        $data['amount_four']           = $this->input->post('amount_four',true);
        $data['sub_charge']            = $this->input->post('sub_charge',true);
        $data['rate_five']             = $this->input->post('rate_five',true);
        $data['amount_five']           = $this->input->post('amount_five',true);
        $data['gst_charge']            = $this->input->post('gst_charge',true);
        $data['rate_six']              = $this->input->post('rate_six',true);
        $data['amount_six']            = $this->input->post('amount_six',true);   
        $data['grand_total']           = $this->input->post('grand_total',true);  
        $data['grand_rate']            = $this->input->post('grand_rate',true);    
        $data['grand_amount']          = $this->input->post('grand_amount',true);
        $data['amount_in_word']        = $this->input->post('amount_in_word',true);   
        $data['basis_of_bkg']          = $this->input->post('basis_of_bkg',true);
        $data['gst_pay']               = $this->input->post('gst_pay',true);
        $data['for_acknowledment']     = $this->input->post('for_acknowledment',true); 
        $data['created_at']            = date('Y-m-d H-i-s');  
        $data['created_mili_second']   = strtotime(date("Y-m-d"));     
        $add_bilti  = $this->admin_model->insert('bilti_details',$data);
        $this->session->set_flashdata('success_message', $add_bilti);   
        redirect('admin/bilti');         
      }
      $data['controller_name']  = 'admin';
      $data['view']             = 'template/dashboard';
      $data['page_name']        = '/add_bilti';
      $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $data['company_name']     = $this->admin_model->fetch_data('m_consignor_details');
      $data['company']          = $this->admin_model->fetch_data('m_consignee_details');
      $data['lorry_no']          = $this->admin_model->fetch_data('m_lorry_owner_details');
      $data['vs_code']         =$this->admin_model->get_bilti_id(); 
      $this->load->view("gd_logistics/template/dashboard",$data);
    } 
    //bilti   
    public function bilti(){
      $data['controller_name']  = 'admin';
      $data['view']             = 'template/dashboard';
      $data['page_name']        = '/bilti';
      $data['info_one']         = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $data['info']             = $this->my_model->get_single_data('settings_details',array('id' => '1'));
      $data['bilti']            = $this->admin_model->fetch('bilti_details'); 

      $this->load->view("gd_logistics/template/dashboard",$data);
    }

	public function count(){
		$data['controller_name']  = 'admin';
		$data['view']             = 'template/dashboard';
		$data['page_name']        = '/count';
		$data['bilti']            = $this->admin_model->fetch('bilti_details');
		$data['bilti_count'] = $this->db->query("SELECT COUNT(*) AS count FROM `bilti_details`")->result();
		$data['charge_sum'] = $this->db->query("SELECT SUM(`charge_wt`) AS charge FROM `bilti_details`")->result();
		$this->load->view("gd_logistics/template/dashboard",$data);
	}
    //edit_bilti  
  public function edit_bilti(){  
        $id                        = $this->uri->segment(3);
        $data['controller_name']   = 'admin';
        $data['view']              = 'template/dashboard';
        $data['logo']              = $this->my_model->get_single_data('settings_details',array('id' => '1'));
        $data['bilti']             = $this->admin_model->get_single_data('bilti_details', array('id' => $id));
        $data['page_name']         = '/edit_bilti';
        $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
        $data['company_name']     = $this->admin_model->fetch_data('m_consignor_details');
        $data['lorry_no']          = $this->admin_model->fetch_data('m_lorry_owner_details');
        $data['company']          = $this->admin_model->fetch_data('m_consignee_details');
        $this->load->view("/gd_logistics/template/dashboard",$data); 
    }  
     //update_bilti     
    public function update_bilti (){    
      $id = $this->uri->segment(3); 
       $xyz_staff_id  = $_POST['id'];
         if(!empty($_FILES['policy_file']['name'])){  
           $file_to_upload = 'policy_file';
           $upload_folder  = 'policy_file';
           $filename       = strtolower(str_replace(" ","_",$xyz_staff_id.'_'.$file_to_upload));
           $upload_folder  = 'policy_file';
           $filetypes      = '*';
           $policy_file  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);     
         } 
         if(!empty($policy_file)){
           $data = array('policy_file'=>$policy_file); 
           $this->admin_model->update('bilti_details',$data, array('id'=>$xyz_staff_id));   
         } 
      $data['load_type']             = $this->input->post('load_type',true);   
      $data['copy_type']             = $this->input->post('copy_type',true); 
      $data['kh_address']            = $this->input->post('kh_address',true); 
      $data['from_address']          = $this->input->post('from_address',true);
      $data['from_address_indore']   = $this->input->post('from_address_indore',true); 
      $data['to_addr']             = $this->input->post('to_addr',true); 
      $data['from_addr']             = $this->input->post('from_addr',true);  
      $data['tbb_for']             = $this->input->post('tbb_for',true); 
      $data['to_address']             = $this->input->post('to_address',true); 
      $data['door_dilivery']             = $this->input->post('door_dilivery',true); 
      $data['consignment_copy']             = $this->input->post('consignment_copy',true);  
      $data['e_way_bill_no_two']             = $this->input->post('e_way_bill_no_two',true); 
      $data['e_way_bill_no_three']             = $this->input->post('e_way_bill_no_three',true); 
      $data['insurance_company']     = $this->input->post('insurance_company',true); 
      $data['from_bilti']            = $this->input->post('from_bilti',true); 
      $data['policy_no']             = $this->input->post('policy_no',true);
        $data['to_bilti']            = $this->input->post('to_bilti',true);
        $data['consignor_company_name']= $this->input->post('consignor_company_name',true);
        $data['consignor_gst_no']      = $this->input->post('consignor_gst_no',true);
        $data['consignor_phone_no']    = $this->input->post('consignor_phone_no',true);
          $data['consignor_policy_name'] = $this->input->post('consignor_policy_name',true);
          $data['consignee_address'] = $this->input->post('consignee_address',true);
          $data['consignor_address'] = $this->input->post('consignor_address',true);
         $data['consignor_policy_no'] = $this->input->post('consignor_policy_no',true);
        $data['consignee_company_name']= $this->input->post('consignee_company_name',true);
        $data['consignee_gst_no']      = $this->input->post('consignee_gst_no',true);
        $data['consignee_phone_no']    = $this->input->post('consignee_phone_no',true);
        $data['packages']              = $this->input->post('packages',true);
        $data['packing_type']          = $this->input->post('packing_type',true);
        $data['e_way_bill_no']         = $this->input->post('e_way_bill_no',true);
        $data['invoice_no']            = $this->input->post('invoice_no',true);
        $data['declared_value']        = $this->input->post('declared_value',true);
        $data['valid_upto']            = $this->input->post('valid_upto',true);
        $data['lorry_no']              = $this->input->post('lorry_no',true);
        $data['description']           = $this->input->post('description',true);
        $data['actual_wt']             = $this->input->post('actual_wt',true);
        $data['charge_wt']             = $this->input->post('charge_wt',true);
        $data['vs_code']               = $this->input->post('vs_code',true);
        $data['con_date']              = $this->input->post('con_date',true);
        $data['con_pan_no']            = $this->input->post('con_pan_no',true);
        $data['con_gst_no']            = $this->input->post('con_gst_no',true);
        $data['freight']               = $this->input->post('freight',true);
        $data['rate_one']              = $this->input->post('rate_one',true);
        $data['amount_one']            = $this->input->post('amount_one',true);
        $data['door_delivery']         = $this->input->post('door_delivery',true);  
        $data['rate_two']              = $this->input->post('rate_two',true);
        $data['amount_two']            = $this->input->post('amount_two',true);      
        $data['local_collection']      = $this->input->post('local_collection',true);
        $data['rate_three']            = $this->input->post('rate_three',true);
        $data['amount_three']          = $this->input->post('amount_three',true);
        $data['lr_charge']             = $this->input->post('lr_charge',true);    
        $data['rate_four']             = $this->input->post('rate_four',true);
        $data['amount_four']           = $this->input->post('amount_four',true);
        $data['sub_charge']            = $this->input->post('sub_charge',true);
        $data['rate_five']             = $this->input->post('rate_five',true);
        $data['amount_five']           = $this->input->post('amount_five',true);
        $data['gst_charge']            = $this->input->post('gst_charge',true);
        $data['rate_six']              = $this->input->post('rate_six',true);
        $data['amount_six']            = $this->input->post('amount_six',true);   
        $data['grand_total']           = $this->input->post('grand_total',true);  
        $data['grand_rate']            = $this->input->post('grand_rate',true);    
        $data['grand_amount']          = $this->input->post('grand_amount',true);
        $data['amount_in_word']        = $this->input->post('amount_in_word',true);   
        $data['basis_of_bkg']          = $this->input->post('basis_of_bkg',true); 
        $data['gst_pay']               = $this->input->post('gst_pay',true); 
        $data['for_acknowledment']     = $this->input->post('for_acknowledment',true); 
        $data['updated_at']            = date('Y-m-d H-i-s');   
    $update_bilti = $this->admin_model->update('bilti_details',$data,array('id'=>$id));
    $this->session->set_flashdata('success_message', $update_bilti);
    redirect('admin/bilti');              
      
    } 
    //view_bilti  
  public function view_bilti(){
        $id                        = $this->uri->segment(3);
        $data['controller_name']   = 'bilti';
        $data['view']              = 'bilti/dashboard';
        $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
        $data['bilti']             = $this->admin_model->get_single_data('bilti_details', array('id' => $id));
        $data['page_name']         = '/view_bilti';
         $data['company_name']     = $this->admin_model->fetch_data('m_consignor_details');
        $this->load->view("/gd_logistics/template/dashboard",$data); 
    } 
  //delete_bilti    
  public function delete_bilti(){
    $data = array(
        'is_deleted' => 9,
    );
    $id     = $this->uri->segment(3);
    $result = $this->admin_model->delete('bilti_details',array('id'=>$id),$data); 
    $this->session->set_flashdata('success_message', $result);  
    redirect('admin/bilti');    
  }    
     //add_lorry_challan      
    public function add_lorry_challan(){   
       if(isset($_POST['submit_form'])){ 
       //generate challan id
        // $new_count     = $this->db->query('SELECT lorry_hire_contact_no FROM lorry_challan_details');
        //print_r($new_count);
        //exit;  
        // if ($new_count->num_rows() > 0){
        //   $new_query  = $this->db->query('SELECT MAX(lorry_hire_contact_no) AS lorry_hire_contact_no FROM lorry_challan_details');
        //   $new_result = $new_query->row();   
          // for($i=0;$i<count(100);$i++){
         //  $dd= $new_result->lorry_hire_contact_no + 1;     
          // }  
        // print_r($dd); 
        // exit;  
        //  }else{
        //   $dd= '60001';    
        // }     
      
        $data = [
        'lorry_hire_contact_no' => $this->input->post('lorry_hire_contact_no'),   
        'lorry_type'            => $this->input->post('lorry_type'), 
        'lorry_hire_date'       => $this->input->post('lorry_hire_date'), 
        'from_lorry'            => $this->input->post('from_lorry'),
        'tds'                   => $this->input->post('tds'),
        'shortage'              => $this->input->post('shortage'),
        'damage'                => $this->input->post('damage'),
        'qq_total_amount'       => $this->input->post('qq_total_amount'),
        'to_lorry'              => $this->input->post('to_lorry'),
        'damage_amount'         => $this->input->post('damage_amount'),
        'lorry_no'              => $this->input->post('lorry_no'),
        'challan_no'            => $this->input->post('challan_no'),
        'vs_code'    => $this->input->post('vs_code'),
        'package'=> $this->input->post('package'),
        'actual_weight'      => $this->input->post('actual_weight'),
        'charge_weight'    => $this->input->post('charge_weight'),
        'owner_details'              => $this->input->post('owner_details'),
        'driver_details'          => $this->input->post('driver_details'),
        'broker_details'         => $this->input->post('broker_details'),
        'rate_per_ton'            => $this->input->post('rate_per_ton'),
        'hire_charge_wt'        => $this->input->post('hire_charge_wt'),
        'cash_amount'            => $this->input->post('cash_amount'),
        'cheque_amount'              => $this->input->post('cheque_amount'),
        'cheque_no'           => $this->input->post('cheque_no'),
        'advance_date'             => $this->input->post('advance_date'),
        'final_rate_per_ton'             => $this->input->post('final_rate_per_ton'),
        'final_rate_charge_wt'               => $this->input->post('final_rate_charge_wt'),
        'payment_cash_amount'              => $this->input->post('payment_cash_amount'),
        'payment_cheque_amount'            => $this->input->post('payment_cheque_amount'),
        'payment_cheque_no'            => $this->input->post('payment_cheque_no'),
        'payment_date'               => $this->input->post('payment_date'),
        'lorry_hire'              => $this->input->post('lorry_hire'),
        'lorry_amount_rs'            => $this->input->post('lorry_amount_rs'),
        'other_amount'         => $this->input->post('other_amount'),  
        'other_amount_rs'              => $this->input->post('other_amount_rs'),
        'total_amount'            => $this->input->post('total_amount'),      
        'total_amount_rs'      => $this->input->post('total_amount_rs'),
        'adv_amount'            => $this->input->post('adv_amount'),
        'adv_amount_rs'          => $this->input->post('adv_amount_rs'),
        'net_balance'             => $this->input->post('net_balance'),    
        'net_balance_rs'             => $this->input->post('net_balance_rs'),
        'balance_amount'           => $this->input->post('balance_amount'),
        'ab_balance_rs'            => $this->input->post('ab_balance_rs'),
        'ab_other_amount'             => $this->input->post('ab_other_amount'),
        'ab_total_amount'           => $this->input->post('ab_total_amount'),
        'deduction'            => $this->input->post('deduction'),
        'deduction_amount'              => $this->input->post('deduction_amount'),
        'deduction_net_balance'            => $this->input->post('deduction_net_balance'),   
        'net_deduction_amount'           => $this->input->post('net_deduction_amount'),  
        'rc'            => $this->input->post('rc'),    
        'enclose_insurance'          => $this->input->post('enclose_insurance'),
        'permit'        => $this->input->post('permit'),   
        'pan'          => $this->input->post('pan'),
        'driver_lic'               => $this->input->post('driver_lic'),
       'owner_name'              => $this->input->post('owner_name'), 
       'owner_mobile_no'              => $this->input->post('owner_mobile_no'),
       'owner_alt_mobile_no'              => $this->input->post('owner_alt_mobile_no'),
       'owner_address'              => $this->input->post('owner_address'), 
       'broker_name'              => $this->input->post('broker_name'), 
       'broker_mobile_no'              => $this->input->post('broker_mobile_no'), 
       'broker_alt_mobile_no'              => $this->input->post('broker_alt_mobile_no'), 
       'broker_address'              => $this->input->post('broker_address'),
       'driver_name'              => $this->input->post('driver_name'), 
       'driver_mobile_no'         => $this->input->post('driver_mobile_no'),
       'driver_alt_mobile_no'         => $this->input->post('driver_alt_mobile_no'),
       'driver_address'         => $this->input->post('driver_address'),
       'mode_of_payment'         => $this->input->post('mode_of_payment'),
       'mode_of_payment_one'         => $this->input->post('mode_of_payment_one'),
        'created_at'            => date('Y-m-d H-i-s'),      
        ];
        $add_lorry_challan  = $this->admin_model->insert('lorry_challan_details',$data);
        $this->session->set_flashdata('success_message', $add_lorry_challan);  
        redirect('admin/lorry_challan');        
      }
      $data['controller_name']  = 'admin'; 
      $data['view']             = 'template/dashboard';  
      $data['page_name']        = '/add_lorry_challan';
      $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $data['lorry_hire_contact_no'] =$this->admin_model->get_challan_id();
      $data['broker']           = $this->admin_model->fetch_data('m_broker_details');  
      $this->load->view("gd_logistics/template/dashboard",$data);
    }
     //edit_lorry_challan 
  public function edit_lorry_challan(){
        $id                        = $this->uri->segment(3);
        $data['controller_name']   = 'admin';
        $data['view']              = 'template/dashboard';
        $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
        $data['broker']           = $this->admin_model->fetch_data('m_broker_details');  
        $data['lorry']             = $this->admin_model->get_single_data('lorry_challan_details', array('id' => $id));
        $data['page_name']         = '/edit_lorry_challan';
        $this->load->view("/gd_logistics/template/dashboard",$data); 
    } 
     //lorry_challan  
    public function lorry_challan(){
      $data['controller_name']  = 'admin';
      $data['view']             = 'template/dashboard';
      $data['page_name']        = '/lorry_challan';
      $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $data['lorry']            = $this->admin_model->fetch('lorry_challan_details');  
      $this->load->view("gd_logistics/template/dashboard",$data);
    } 
    //update_lorry_challan  
    public function update_lorry_challan(){  
         $id = $this->uri->segment(3);  
               $data = [
                'lorry_type'       => $this->input->post('lorry_type'),   
                'lorry_hire_contact_no' => $this->input->post('lorry_hire_contact_no'),   
                'lorry_hire_date'       => $this->input->post('lorry_hire_date'), 
                'from_lorry'            => $this->input->post('from_lorry'),
                'qq_total_amount'       => $this->input->post('qq_total_amount'),
                'tds'                   => $this->input->post('tds'),
                'shortage'              => $this->input->post('shortage'), 
                'damage'              => $this->input->post('damage'),
                'damage_amount'       => $this->input->post('damage_amount'),
                'to_lorry'              => $this->input->post('to_lorry'),
                'lorry_no'              => $this->input->post('lorry_no'),
                'challan_no'            => $this->input->post('challan_no'),
                'vs_code'    => $this->input->post('vs_code'),
                'package'=> $this->input->post('package'),
                'actual_weight'      => $this->input->post('actual_weight'),
                'charge_weight'    => $this->input->post('charge_weight'),
                'owner_details'              => $this->input->post('owner_details'),
                'driver_details'          => $this->input->post('driver_details'),
                'broker_details'         => $this->input->post('broker_details'),
                'rate_per_ton'            => $this->input->post('rate_per_ton'),
                'hire_charge_wt'        => $this->input->post('hire_charge_wt'),
                'cash_amount'            => $this->input->post('cash_amount'),
                'cheque_amount'              => $this->input->post('cheque_amount'),
                'cheque_no'           => $this->input->post('cheque_no'),
                'advance_date'             => $this->input->post('advance_date'),
                'final_rate_per_ton'             => $this->input->post('final_rate_per_ton'),
                'final_rate_charge_wt'               => $this->input->post('final_rate_charge_wt'),
                'payment_cash_amount'              => $this->input->post('payment_cash_amount'),
                'payment_cheque_amount'            => $this->input->post('payment_cheque_amount'),
                'payment_cheque_no'            => $this->input->post('payment_cheque_no'),
                'payment_date'               => $this->input->post('payment_date'),
                'lorry_hire'              => $this->input->post('lorry_hire'),
                'lorry_amount_rs'            => $this->input->post('lorry_amount_rs'),
                'other_amount'         => $this->input->post('other_amount'),  
                'other_amount_rs'              => $this->input->post('other_amount_rs'),
                'total_amount'            => $this->input->post('total_amount'),      
                'total_amount_rs'      => $this->input->post('total_amount_rs'),
                'adv_amount'            => $this->input->post('adv_amount'),
                'adv_amount_rs'          => $this->input->post('adv_amount_rs'),
                'net_balance'             => $this->input->post('net_balance'),    
                'net_balance_rs'             => $this->input->post('net_balance_rs'),
                'balance_amount'           => $this->input->post('balance_amount'),
                'ab_balance_rs'            => $this->input->post('ab_balance_rs'),
                'ab_other_amount'             => $this->input->post('ab_other_amount'),
                'ab_total_amount'           => $this->input->post('ab_total_amount'),
                'deduction'            => $this->input->post('deduction'),
                'deduction_amount'              => $this->input->post('deduction_amount'),
                'deduction_net_balance'            => $this->input->post('deduction_net_balance'),   
                'net_deduction_amount'           => $this->input->post('net_deduction_amount'),  
                'rc'            => $this->input->post('rc'),    
                'enclose_insurance'          => $this->input->post('enclose_insurance'),
                'permit'        => $this->input->post('permit'),   
                'pan'          => $this->input->post('pan'),
                'driver_lic'               => $this->input->post('driver_lic'),
               'owner_name'              => $this->input->post('owner_name'), 
               'owner_mobile_no'              => $this->input->post('owner_mobile_no'),
               'owner_alt_mobile_no'              => $this->input->post('owner_alt_mobile_no'),
               'owner_address'              => $this->input->post('owner_address'), 
               'broker_name'              => $this->input->post('broker_name'), 
               'broker_mobile_no'              => $this->input->post('broker_mobile_no'), 
               'broker_alt_mobile_no'              => $this->input->post('broker_alt_mobile_no'), 
               'broker_address'              => $this->input->post('broker_address'),   
               'driver_name'              => $this->input->post('driver_name'), 
               'driver_mobile_no'         => $this->input->post('driver_mobile_no'),
               'driver_alt_mobile_no'         => $this->input->post('driver_alt_mobile_no'),
               'driver_address'         => $this->input->post('driver_address'),
               'mode_of_payment'         => $this->input->post('mode_of_payment'),
               'mode_of_payment_one'         => $this->input->post('mode_of_payment_one'),
        'updated_at'            => date('Y-m-d H-i-s'),        
        ];
    $update_lorry = $this->admin_model->update('lorry_challan_details',$data,array('id'=>$id));
    $this->session->set_flashdata('success_message', $update_bilti); 
    redirect('admin/lorry_challan');           
      
    }   
      //view_lorry_challan
  public function view_lorry_challan(){
        $id                        = $this->uri->segment(3);
        $data['controller_name']   = 'bilti';
        $data['view']              = 'bilti/dashboard';
        $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
        $data['lorry']             = $this->admin_model->get_single_data('lorry_challan_details', array('id' => $id));
        $data['page_name']         = '/view_lorry_challan';  
        $this->load->view("/gd_logistics/template/dashboard",$data); 
    } 
     //delete_lorry_challan    
  public function delete_lorry_challan(){
    $data = array(
        'is_deleted' => 9,
    );
    $id     = $this->uri->segment(3);
    $result = $this->admin_model->delete('lorry_challan_details',array('id'=>$id),$data); 
    $this->session->set_flashdata('success_message', $result);
    redirect('admin/lorry_challan');   
  } 
    //  //view_lorry_challan
    // public function view_lorry_challan(){
    //   $data['controller_name']  = 'admin';
    //   $data['view']             = 'template/dashboard';
    //   $data['page_name']        = '/view_lorry_challan';
    //   $data['info']             = $this->my_model->get_single_data('settings_details',array('id' => '1')); 
    //   $this->load->view("gd_logistics/template/dashboard",$data);
    // }


     //invoice 

    public function add_invoice(){    
        if(isset($_POST['submit_form'])){
           //generate invoice id
        $new_count     = $this->db->query('SELECT bill_no FROM invoice_details');
        if ($new_count->num_rows() > 0){
          $new_query  = $this->db->query('SELECT MAX(bill_no) AS bill_no FROM invoice_details');
          $new_result = $new_query->row();
          $dd= $new_result->bill_no + 1;
        }else{
          $dd= '75001';    
        }
         $data['invoice_no']         = $this->input->post('invoice_no',true);   
         $data['bill_no']            = $dd; 
         $data['tbb_for']            = $this->input->post('tbb_for',true); 
         $data['invoice_bill_date'] = $this->input->post('invoice_bill_date',true);
         $data['payment_status']  = Unpaid;
         $data['owner_name']      = $this->input->post('owner_name',true);  
         $data['detention']      = $this->input->post('detention',true);  
         $data['other_charge']      = $this->input->post('other_charge',true);    
         $data['customer_address']   = $this->input->post('customer_address',true);
         $data['gst_no']             = $this->input->post('gst_no',true);
         $data['booking_station']    = $this->input->post('booking_station',true);
         $data['vs_code']     = $this->input->post('vs_code',true);
         $data['consignment_date']   = $this->input->post('consignment_date',true);
         $data['destination']        = $this->input->post('destination',true);
         $data['truck_no']           = $this->input->post('truck_no',true);
         $data['charge_weight_mt']   = $this->input->post('charge_weight_mt',true);   
         $data['rate']               = $this->input->post('rate',true);  
      
         $data['freight_amount']     = $this->input->post('freight_amount',true); 
         $data['unloading_charge']   = $this->input->post('unloading_charge',true);   
         $data['total_amount']       = $this->input->post('total_amount',true);
         $data['cgst_igst']       = $this->input->post('cgst_igst',true);
         $data['cgst_igst_amount']       = $this->input->post('cgst_igst_amount',true);
         $data['sgst']                = $this->input->post('sgst',true);
         $data['sgst_amount']       = $this->input->post('sgst_amount',true);
         $data['all_total_amount']       = $this->input->post('all_total_amount',true);  
         $data['gst_amount']       = $this->input->post('gst_amount',true);   
         $data['remarks']       = $this->input->post('remarks',true);
         $data['two_total_amount']       = $this->input->post('two_total_amount',true);  
        //  $data['booking_address_nagpur'] = $this->input->post('booking_address_nagpur',true);
        //  $data['booking_address_indore'] = $this->input->post('booking_address_indore',true);
        //  $data['in_words']           = $this->input->post('in_words',true);    
         $data['created_at']            = date('Y-m-d H-i-s');    
         $data['created_mili_second']   = strtotime(date("Y-m-d"));      
         if($this->admin_model->insert('invoice_details',$data)){
            $last_id = $this->db->insert_id();
            // print_r($last_id);
            // exit;  
            $booking_station_one = $_POST['booking_station_one']; 
            $vs_code_one    = $_POST['vs_code_one'];
            $consignment_date_one = $_POST['consignment_date_one'];
            $destination_one = $_POST['destination_one'];
            $truck_no_one = $_POST['truck_no_one'];
            $charge_weight_mt_one = $_POST['charge_weight_mt_one'];
            $rate_one = $_POST['rate_one']; 
            $invoice_no_one = $_POST['invoice_no_one'];   
            $freight_amount_one = $_POST['freight_amount_one']; 
            $unloading_charge_one = $_POST['unloading_charge_one']; 
            $total_amount_one = $_POST['total_amount_one']; 
              for($i = 0; $i < count($booking_station_one); $i++){
                $data1 = array(
                    'booking_station_one' => $booking_station_one[$i],
                    'vs_code_one'         => $vs_code_one[$i],
                    'consignment_date_one'=> $consignment_date_one[$i],
                    'destination_one'     => $destination_one[$i],
                    'truck_no_one'        => $truck_no_one[$i],
                    'charge_weight_mt_one'=> $charge_weight_mt_one[$i],
                    'rate_one'         => $rate_one[$i],
                    'invoice_no_one'   => $invoice_no_one[$i],
                    'freight_amount_one'=>$freight_amount_one[$i],
                    'unloading_charge_one'=> $unloading_charge_one[$i],
                    'total_amount_one' => $total_amount_one[$i],
                    'invoice_id'   => $last_id);         
                    $this->db->insert('invoice_dynamic_details',$data1);
         }

       }   

         $this->session->set_flashdata('success_message', $add_invoice);  
         redirect('admin/invoice');            
       }
     
       $data['controller_name']  = 'admin';
       $data['view']             = 'template/dashboard';    
       $data['page_name']        = '/add_invoice';
       $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
       $data['company_name']     = $this->admin_model->fetch_data('m_consignor_details');
       //$data['invoice_no']         =$this->admin_model->get_invoice_id();
       $data['bill_no']         =$this->admin_model->get_bill_id();
       $this->load->view("gd_logistics/template/dashboard",$data); 
    }
    public function invoice(){ 
      $data['controller_name']  = 'admin';
      $data['view']             = 'template/dashboard';
      $data['page_name']        = '/invoice';
      $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $data['invoice_details']  = $this->admin_model->fetch('invoice_details');
      $data['company_name']     = $this->admin_model->fetch_data('m_consignor_details');
     
      // print_r( $data['company_name']);
      // exit();  
      $this->load->view("gd_logistics/template/dashboard",$data);
    } 

    public function view_invoice(){  
      $id                        = $this->uri->segment(3);
      $data['controller_name']   = 'admin';
      $data['view']              = 'template/dashboard';
      $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $data['info']                = $this->admin_model->get_single_data('invoice_details', array('id' => $id));
      $data['page_name']         = '/view_invoice';  
      $this->load->view("/gd_logistics/template/dashboard",$data); 
    }  

    public function edit_invoice(){  
      $id                        = $this->uri->segment(3); 
      $invoice_id                = $this->uri->segment(3); 
      // print_r($id);
      // exit; 
      $data['controller_name']   = 'admin'; 
      $data['view']              = 'template/dashboard';
      $data['page_name']         = '/edit_invoice';
      $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $data['invoice_details']   = $this->admin_model->get_single_data('invoice_details', array('id' => $id));
      $data['dynamic_invoice_details'] = $this->db->query("SELECT * FROM `invoice_dynamic_details` WHERE `invoice_id` = '$id' AND `is_deleted` = 0")->result_array(); 
      $data['company_name']     = $this->admin_model->fetch_data(' m_consignor_details');
      $data['company']          = $this->admin_model->fetch_data('m_consignee_details'); 
      $data['owner_name']     = $this->admin_model->fetch_data('m_consignor_details');
      $this->load->view("/gd_logistics/template/dashboard",$data);    
     } 

     public function update_invoice(){    
      $id = $this->uri->segment(3);  
            $data = [  
     'bill_no'              => $this->input->post('bill_no'),
     'tbb_for'              => $this->input->post('tbb_for'),
    //  'booking_address_nagpur' => $this->input->post('booking_address_nagpur'),
    //  'booking_address_indore' => $this->input->post('booking_address_indore'),   
    'invoice_bill_date' => $this->input->post('invoice_bill_date'),     
     'owner_name'      => $this->input->post('owner_name'),
    'detention'     => $this->input->post('detention'),  
    'other_charge'     => $this->input->post('other_charge'),
     'customer_address'    => $this->input->post('customer_address'),
     'gst_no'               => $this->input->post('gst_no'), 
     'booking_station'             => $this->input->post('booking_station'),    
     'vs_code'             => $this->input->post('vs_code'),
     'consignment_date'           => $this->input->post('consignment_date'),
     'destination'            => $this->input->post('destination'),
     'truck_no'             => $this->input->post('truck_no'),
     'charge_weight_mt'           => $this->input->post('charge_weight_mt'),
     'rate'            => $this->input->post('rate'),
     'invoice_no'              => $this->input->post('invoice_no'),
     'freight_amount'            => $this->input->post('freight_amount'),   
     'unloading_charge'           => $this->input->post('unloading_charge'),  
     'total_amount'            => $this->input->post('total_amount'),
     'cgst_igst'      => $this->input->post('cgst_igst'),
     'cgst_igst_amount'      => $this->input->post('cgst_igst_amount'),
     'remarks' => $this->input->post('remarks'),
     'sgst'               => $this->input->post('sgst'),
     'sgst_amount'      => $this->input->post('sgst_amount'),
     'all_total_amount'      => $this->input->post('all_total_amount'), 
     'gst_amount'      => $this->input->post('gst_amount'),
     'two_total_amount' => $this->input->post('two_total_amount'),    
    //  'in_words'          => $this->input->post('in_words'),    
     'updated_at'            => date('Y-m-d H-i-s'),          
     ];  
     $update_invoice = $this->admin_model->update('invoice_details',$data,array('id'=>$id));
     $invoice_id = $_POST['invoice_id'];
      //common services
            $booking_station_one = $_POST['booking_station_one']; 
            $vs_code_one    = $_POST['vs_code_one'];
            $consignment_date_one = $_POST['consignment_date_one'];
            $destination_one = $_POST['destination_one'];
            $truck_no_one = $_POST['truck_no_one'];
            $charge_weight_mt_one = $_POST['charge_weight_mt_one'];
            $rate_one = $_POST['rate_one']; 
            $invoice_no_one = $_POST['invoice_no_one'];   
            $freight_amount_one = $_POST['freight_amount_one']; 
            $unloading_charge_one = $_POST['unloading_charge_one']; 
            $total_amount_one = $_POST['total_amount_one']; 
            $form_three_id          = $_POST['form_three_id'];       
           for($i = 0; $i < count($booking_station_one); $i++){
        if(!empty($form_three_id[$i])){
            $data5 = array(
                    'booking_station_one' => $booking_station_one[$i],
                    'vs_code_one'         => $vs_code_one[$i],
                    'consignment_date_one'=> $consignment_date_one[$i],
                    'destination_one'     => $destination_one[$i],
                    'truck_no_one'        => $truck_no_one[$i],
                    'charge_weight_mt_one'=> $charge_weight_mt_one[$i],
                    'rate_one'         => $rate_one[$i],
                    'invoice_no_one'   => $invoice_no_one[$i],
                    'freight_amount_one'=>$freight_amount_one[$i],
                    'unloading_charge_one'=> $unloading_charge_one[$i],
                    'total_amount_one' => $total_amount_one[$i]);
            $this->admin_model->update('invoice_dynamic_details',$data5,array('id' => $form_three_id[$i],'invoice_id'=>$invoice_id));
                // print_r($data);    
        }else{
            $data6 = array(
                    'booking_station_one' => $booking_station_one[$i],
                    'vs_code_one'         => $vs_code_one[$i],
                    'consignment_date_one'=> $consignment_date_one[$i],
                    'destination_one'     => $destination_one[$i],
                    'truck_no_one'        => $truck_no_one[$i],
                    'charge_weight_mt_one'=> $charge_weight_mt_one[$i],
                    'rate_one'         => $rate_one[$i],
                    'invoice_no_one'   => $invoice_no_one[$i],
                    'freight_amount_one'=>$freight_amount_one[$i],
                    'unloading_charge_one'=> $unloading_charge_one[$i],
                    'total_amount_one' => $total_amount_one[$i],
                    'invoice_id'              => $invoice_id);
            $this->db->insert('invoice_dynamic_details',$data6);      
        }     
        }     
     $this->session->set_flashdata('success_message', $update_invoice);  
     redirect('admin/invoice');          
   
     }    
    
     public function delete_invoice(){ 
      $data = array(
        'is_deleted' => 9,
    );
      $id          = $this->uri->segment(3);
      $invoice_id  = $this->uri->segment(3);
      $result     = $this->admin_model->delete('invoice_details',array('id'=>$id),$data);
      $result     = $this->admin_model->delete('invoice_dynamic_details',array('invoice_id'=>$invoice_id),$data);
      $this->session->set_flashdata('success_message', $result);  
      redirect('admin/invoice');     
  } 

  //delete_comm      
  public function delete_comm(){     
    $data = array(
        'is_deleted' => 9,
    );
    $id                    = $this->uri->segment(3); 
    $main_id               = $this->admin_model->get_single_data('invoice_dynamic_details', array('id' => $id)); 
    $invoice_id            = $main_id->invoice_id;  
    $this->admin_model->delete($data,'invoice_dynamic_details', array('id' => $id));
    redirect(base_url('admin/edit_invoice/'.$invoice_id));     
  }   

  // add payment Receipt
  public function add_payment_receipt(){
    if(isset($_POST['submit_form'])){
       //generate invoice id
       $new_count     = $this->db->query('SELECT receipt_no FROM payment_receipt_details');
       if ($new_count->num_rows() > 0){
         $new_query  = $this->db->query('SELECT MAX(receipt_no) AS receipt_no FROM payment_receipt_details');
         $new_result = $new_query->row();
         $dd= $new_result->receipt_no + 1; 
       }else{
         $dd= '40001';
       }
        $data['receipt_no']                = $dd;  
   
    $data['owner_name']                = $this->input->post('owner_name',true);
    $data['customer_address']          = $this->input->post('customer_address',true);
    $data['gst_no']                    = $this->input->post('gst_no',true);
    $data['ttb_for']                   = $this->input->post('ttb_for',true);
    $data['from_payment_receipt']      = $this->input->post('from_payment_receipt',true);
    $data['receipt_type']              = $this->input->post('receipt_type',true);
    $data['receipt_date']              = $this->input->post('receipt_date',true);
    $data['to_payment_receipt']        = $this->input->post('to_payment_receipt',true);
    $data['vs_code']                   = $this->input->post('vs_code',true);   
    $data['date']                      = $this->input->post('date',true);
    $data['wt']                        = $this->input->post('wt',true);
    $data['package']                   = $this->input->post('package',true);
    $data['bill_no']                   = $this->input->post('bill_no',true);    
     $data['bill_date']                = $this->input->post('bill_date',true);
     $data['cash']                     = $this->input->post('cash',true);
     $data['cheque']                   = $this->input->post('cheque',true);      
     $data['rtgs']                     = $this->input->post('rtgs',true);
     $data['bb_date']                  = $this->input->post('bb_date',true);
     $data['bank_name']                = $this->input->post('bank_name',true);
     $data['payment_type']             = $this->input->post('payment_type',true);
     $data['payment_rs_one']           = $this->input->post('payment_rs_one',true);
     $data['payment_rs_two']           = $this->input->post('payment_rs_two',true);
     $data['payment_rs_three']         = $this->input->post('payment_rs_three',true);
     $data['payment_rs_four']          = $this->input->post('payment_rs_four',true);   
     $data['payment_rs_five']          = $this->input->post('payment_rs_five',true);    
     $data['payment_rs_six']           = $this->input->post('payment_rs_six',true);     
    
    //  $data['in_words']              = $this->input->post('in_words',true);  
     $data['created_at']               = date('Y-m-d H-i-s');   
     $data['created_mili_second']   = strtotime(date("Y-m-d"));  
    
     $add_payment_receipt  = $this->admin_model->insert('payment_receipt_details',$data);
     $this->session->set_flashdata('success_message', $add_payment_receipt);  
     redirect('admin/payment_receipt');         
   }
   $data['controller_name']  = 'admin';
   $data['view']             = 'template/dashboard';
   $data['page_name']        = '/add_payment_receipt';
   $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
   $data['company_name']     = $this->admin_model->fetch_data('m_consignor_details');
   $data['receipt_no']         =$this->admin_model->get_receipt_id();
   $this->load->view("gd_logistics/template/dashboard",$data);
}
     //payment Receipt
    public function payment_receipt(){
      $data['controller_name']  = 'admin';
      $data['view']             = 'template/dashboard';
      $data['page_name']        = '/payment_receipt';
      $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $data['info']  = $this->admin_model->fetch('payment_receipt_details');
      $this->load->view("gd_logistics/template/dashboard",$data);
    }
// view payment receipt
     public function view_payment_receipt(){
      $id                        = $this->uri->segment(3);
      $data['controller_name']   = 'admin';
      $data['view']              = 'template/dashboard';
      $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
      $data['info']   = $this->admin_model->get_single_data('payment_receipt_details', array('id' => $id));
      $data['page_name']         = '/view_payment_receipt';  
      $this->load->view("/gd_logistics/template/dashboard",$data);  
    }
     //  edit payment Receipt
  public function edit_payment_receipt(){
    $id                        = $this->uri->segment(3);
    $data['controller_name']   = 'admin';
    $data['view']              = 'template/dashboard';
    $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
    $data['info']   = $this->admin_model->get_single_data('payment_receipt_details', array('id' => $id));
    $data['page_name']         = '/edit_payment_receipt';
    $data['company_name']     = $this->admin_model->fetch_data('m_consignor_details');
    $this->load->view("/gd_logistics/template/dashboard",$data);   
   } 
     //  update payment receipt  
     public function update_payment_receipt(){  
      $id = $this->uri->segment(3);  
      $data = [
     'owner_name'                => $this->input->post('owner_name'),
     'customer_address'          => $this->input->post('customer_address'),
     'gst_no'                    => $this->input->post('gst_no'),
     'ttb_for'                   => $this->input->post('ttb_for'),
     'receipt_no'              => $this->input->post('receipt_no'),  
     'receipt_type'            => $this->input->post('receipt_type'),
     'receipt_date'            => $this->input->post('receipt_date'),
     'from_payment_receipt'    => $this->input->post('from_payment_receipt'),  
     'to_payment_receipt'      => $this->input->post('to_payment_receipt'),
     'vs_code'                  => $this->input->post('vs_code'), 
     'mode_of_payment'         => $this->input->post('mode_of_payment'),
     'date'                    => $this->input->post('date'), 
     'wt'                      => $this->input->post('wt'),
     'package'                 => $this->input->post('package'),
     'bill_no'                 => $this->input->post('bill_no'),    
     'bill_date'               => $this->input->post('bill_date'),
     'cash'                    => $this->input->post('cash'),
     'cheque'                  => $this->input->post('cheque'),
     'rtgs'                    => $this->input->post('rtgs'),
     'bb_date'                 => $this->input->post('bb_date'),
     'bank_name'               => $this->input->post('bank_name'),
     'payment_type'            => $this->input->post('payment_type'),
     'payment_rs_one'          => $this->input->post('payment_rs_one'),   
     'payment_ps_one'          => $this->input->post('payment_ps_one'), 
     'payment_rs_two'          => $this->input->post('payment_rs_two'),   
     'payment_ps_two'          => $this->input->post('payment_ps_two'), 
     'payment_rs_three'        => $this->input->post('payment_rs_three'),   
     'payment_ps_three'        => $this->input->post('payment_ps_three'), 
     'payment_rs_four'         => $this->input->post('payment_rs_four'),   
     'payment_ps_four'         => $this->input->post('payment_ps_four'), 
     'payment_rs_five'         => $this->input->post('payment_rs_five'),   
     'payment_ps_five'         => $this->input->post('payment_ps_five'), 
     'payment_rs_six'          => $this->input->post('payment_rs_six'),   
     'payment_ps_six'          => $this->input->post('payment_ps_six'),     
     'updated_at'            => date('Y-m-d H-i-s'),      
     ];
     $update_payment_receipt = $this->admin_model->update('payment_receipt_details',$data,array('id'=>$id));
     $this->session->set_flashdata('success_message', $update_payment_receipt);
     redirect('admin/payment_receipt');          
   
     }  
      // delete payment Receipt
     public function delete_payment_receipt(){
      $data = array(
        'is_deleted' => 9,
      )
    ;
      $id         = $this->uri->segment(3);
      $result     = $this->admin_model->delete('payment_receipt_details' ,$data, array('id'=>$id));
      $this->session->set_flashdata('success_message', $result);
      redirect('admin/payment_receipt');
  }  
  public function invoice_report()
	{
		
		$start_date = $_GET['start_date'];
		$end_date = $_GET['end_date'];
		$data['controller_name'] = 'admin';
		$data['view'] = 'template/dashboard';
		$data['page_name'] = '/invoice_report';
    $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
		$data['report'] = $this->admin_model->invoice_report('invoice_details', $start_date, $end_date);
   // print_r($data['report']);
  
		$data['invoice_details']  = $this->admin_model->fetch('invoice_details');
		$this->load->view("gd_logistics/template/dashboard", $data);
	}

	//name_client
	public function name_client()
	{
		$name = $_GET['name'];
		$data['controller_name'] = 'admin';
		$data['view'] = 'template/dashboard';
		$data['page_name'] = '/invoice_report';
    $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
		$data['report'] = $this->admin_model->name_client($name);
    
		$data['invoice_details']  = $this->admin_model->fetch('invoice_details');

		$this->load->view("gd_logistics/template/dashboard", $data);
	}

  //gst_report  
  public function gst_report(){
    $start_date               = $_GET['start_date'];
    $end_date                 = $_GET['end_date'];
    $data['controller_name']  = 'admin';
    $data['view']             = 'template/dashboard';
    $data['page_name']        = '/gst_report';
    $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
    $data['owner_name']     = $this->admin_model->fetch_data('m_consignor_details');
    $data['report']           = $this->admin_model->invoice_report('invoice_details',$start_date,$end_date);
  
    $this->load->view("gd_logistics/template/dashboard",$data);
  }
 //gst_name_client          
 public function gst_name_client(){ 
  $name                     = $_GET['name'];
  $data['controller_name']  = 'admin';
  $data['view']             = 'template/dashboard';
  $data['page_name']        = '/invoice_report';
  $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
  $data['owner_name']       = $this->admin_model->fetch_data('m_consignor_details');
  $data['report']           = $this->admin_model->name_client('invoice_details',$name);
  // print_r( $data['owner_name']);
  // exit();

  $this->load->view("gd_logistics/template/dashboard",$data);        
} 
public function get_bilti(){ 
   $get_leave = $_GET['id'];
   $data['from_bilti']=$this->admin_model->search($get_leave);  
   echo json_encode($data);  
}
//bilti_cns_report
public function bilti_cns_report(){  
    $start_date               = $_GET['start_date'];
    $end_date                 = $_GET['end_date'];
    $name                     = $_GET['name'];
    $data['controller_name']  = 'admin';
    $data['view']             = 'template/dashboard';
    $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
    $data['page_name']        = '/bilti_report';   
    $data['report']           = $this->admin_model->bilti_cns_report('bilti_details',$start_date,$end_date,$name);
  
    $this->load->view("gd_logistics/template/dashboard",$data); 
  }
  //lorry_hire_payment_report  
public function lorry_hire_payment_report(){        
  $name                     = $_GET['name'];
  $data['controller_name']  = 'admin';
  $data['view']             = 'template/dashboard';
  $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
  $data['page_name']        = '/lorry_hire_payment_report';   
  $data['report']           = $this->admin_model->lorry_hire_payment_report('lorry_challan_details',$name);

  $this->load->view("gd_logistics/template/dashboard",$data);
}
 //payment_receipt_report 
 public function payment_receipt_report(){     
  $name                     = $_GET['name'];
  $data['controller_name']  = 'admin';
  $data['view']             = 'template/dashboard';
  $data['page_name']        = '/payment_receipt_report'; 
  $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));  
  $data['report']           = $this->admin_model->payment_receipt_report('payment_receipt_details',$name);

  $this->load->view("gd_logistics/template/dashboard",$data);
}
  //tbb_for_report
public function tbb_for_report(){
    $name                     = $_GET['name'];
    $data['controller_name']  = 'admin';
    $data['view']             = 'template/dashboard';
    $data['page_name']        = '/bilti_report';
    $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
    $data['report']           = $this->admin_model->tbb_for_report('bilti_details',$name);   
    $this->load->view("gd_logistics/template/dashboard",$data);
  }

//consignment_update    
public function consignment_update(){    
   if(isset($_POST['submit_form'])){  
   $id = $_POST['id'];      
   if(!empty($id)){
   $data = [
   'ee_id' =>$this->input->post('ee_id'),
   'vs_code' => $this->input->post('vs_code'),
   'consignment_date' => $this->input->post('consignment_date'),    
   'consignment_time' => $this->input->post('consignment_time'),
   'consignment_from' => $this->input->post('consignment_from'),
   'consignment_to' => $this->input->post('consignment_to'),
   'lorry_no' => $this->input->post('lorry_no'),
   'consignment_status' => $this->input->post('consignment_status'),
   'updated_at'    => date('Y-m-d H-i-s'),     
   ];
   
   $order_count = $this->db->query("SELECT * FROM  consignment_update_details where `status`= 8 and ee_id= ".$this->input->post('ee_id'))->num_rows();
    // print_r($order_count);
    // exit();
    if($order_count < 9){   
   $result  = $this->admin_model->update('consignment_update_details',array('status'=>8),array('ee_id'=>$this->input->post('ee_id')));
   $result = $this->admin_model->insert('consignment_update_details',$data);  
    }else{
      $this->session->set_flashdata('success_message', 'Your limit is expire');
      redirect('admin/consignment_update'); 
    }    
   }else{  
       //generate invoice id
       $new_count     = $this->db->query('SELECT ee_id FROM consignment_update_details');
       if ($new_count->num_rows() > 0){
         $new_query  = $this->db->query('SELECT MAX(ee_id) AS ee_id FROM consignment_update_details');
         $new_result = $new_query->row();
         $dd= $new_result->ee_id + 1;     
       }else{
         $dd= '1';     
       } 
   
   $data = [ 
      'ee_id' =>$dd,
      'vs_code' => $this->input->post('vs_code'), 
      'consignment_date' => $this->input->post('consignment_date'),
      'consignment_time' => $this->input->post('consignment_time'),
      'consignment_from' => $this->input->post('consignment_from'),
      'consignment_to' => $this->input->post('consignment_to'),
      'lorry_no' => $this->input->post('lorry_no'),
      'consignment_status' => $this->input->post('consignment_status'), 
   'created_at'    => date('Y-m-d H-i-s'),
   ];  
   $result = $this->admin_model->insert('consignment_update_details',$data);
   }
   $this->session->set_flashdata('success_message', $result);
   redirect('admin/consignment_update');     
 }    
 $data['controller_name']  = 'admin';          
 $data['view']             = 'template/dashboard';
 $data['page_name']        = '/consignment_update'; 
 $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
 $data['info']             = $this->admin_model->fetch_one('consignment_update_details');
//  print_r($data['info'] );
//  exit();
 $aa = $this->db->query("SELECT vs_code as `vs_code!=` FROM `consignment_update_details`")->result_array();
  //print_r($aa);
 //exit();
$bb=$this->db->select('*'); 
//print_r($bb);
//exit();
$bb->where(array('is_deleted !='=> 9));     
foreach($aa as $nab){
  $bb->where($nab);
}
$data['vs_code'] = $bb->get('bilti_details')->result_array();  


 $this->load->view("/gd_logistics/template/dashboard",$data);        
 } 
 
//  $this->db->query("SELECT * FROM  consignment_update_details order by `id` DESC GROUP BY 1")->result();

 public function get_con_kh_data(){ 
  $qq = $_GET['id']; 
  $uu = $this->db->query("SELECT * FROM `consignment_update_details` WHERE ee_id = $qq")->result_array();
  // print_r($uu);  
  // exit(); 
  echo json_encode($uu);
  
}
 //index  
 public function track_consignment(){
   $data['controller_name']  = 'admin';
   $data['view']             = 'template/track_consignment';
   $data['page_name']        = '/track_consignment';
   $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
   $this->load->view("gd_logistics/template/track_consignment",$data);  
 }  
 //consignment_report 
public function consignment_report(){
 $name                     = $_GET['name'];
 $data['controller_name']  = 'admin';
 $data['view']             = 'template/consignment_report'; 
 $data['page_name']        = '/consignment_report';
 $data['info_one']             = $this->admin_model->get_single_data('settings_details',array('id' => '1'));
 $data['report']           = $this->admin_model->one_name_client('consignment_update_details',$name);
 $this->load->view("gd_logistics/template/consignment_report",$data);  
}   
// public function abc(){
  
// }  
// public function vs_details()              
//    {
//       $vs_code = $_GET['vs_code'];
//       $response = $this->admin_model->bilti_data($vs_code);   
//       echo json_encode($response); 
//    }
 
   public function vs_details(){   
    $get_vs = $_GET['id'];   
    $from_bilti=$this->admin_model->search_vs($get_vs); 
    $co = $from_bilti->tbb_for;
    $cee_id = $from_bilti->consignee_company_name;
    $con_id = $from_bilti->consignor_company_name;
    $where = array('id'=>$cee_id);
    $cee = $this->db->where($where)->get('m_consignee_details')->row(); 
    $where = array('id'=>$con_id);
    $con = $this->db->where($where)->get('m_consignor_details')->row();   
    $data = array($cee, $con, $co);
    echo json_encode($data);  
 }

 	

 
	public function profit_loss(){
		$data['controller_name']  = 'admin';
		$data['view']             = 'template/profit_loss';
		$data['page_name']        = '/profit_loss';  
//

	
			if(isset($_GET['search'])){
				$start_date = $_GET['start_date'];  
				$end_date = $_GET['end_date'];
				if (($start_date != '') and ($end_date != '')) {
					$query = $this->db->query("SELECT bilti_details.*, lorry_challan_details.*, invoice_details.* FROM bilti_details 
       										   JOIN lorry_challan_details ON lorry_challan_details.vs_code = bilti_details.vs_code
       										   JOIN invoice_details ON invoice_details.vs_code = bilti_details.vs_code 
                                               WHERE bilti_details.created_at BETWEEN '".$start_date."' AND '".$end_date." 23:59:59'")->result();
					$data['pl'] = $query;
//					exit();
				}
			}else {
				$query = $this->db->query("SELECT bilti_details.*, lorry_challan_details.*, invoice_details.* FROM bilti_details 
       										   JOIN lorry_challan_details ON lorry_challan_details.vs_code = bilti_details.vs_code
       										   JOIN invoice_details ON invoice_details.vs_code = bilti_details.vs_code")->result();
				$data['pl'] = $query;
//					print_r($query);
			}



//			$query1 = $this->db->select('vs_code,con_date,grand_amount')->from('bilti_details')->get_compiled_select();
//			// Second query
//			$query2 = $this->db->select('lorry_hire_contact_no,lorry_hire_date,total_amount_rs')->from('lorry_challan_details')->get_compiled_select();
//			// Combine queries using UNION
//			$query3 = $this->db->select('bill_no,total_amount')->from('invoice_details')->get_compiled_select();
//
//			$data['pl_data1'] = $this->db->query($query1)->result();
//			$data['pl_data2'] = $this->db->query($query2)->result();
//			$data['pl_data3'] = $this->db->query($query3)->result();

		$this->load->view("gd_logistics/template/Dashboard",$data);
	}
}

