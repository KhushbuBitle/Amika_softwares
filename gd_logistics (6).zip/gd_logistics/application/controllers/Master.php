<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Master extends MY_Controller{
    public function __construct() {
      parent::__construct();
      //LOAD ALL REQUIRED MODEL
      $this->load->model('Master_model', 'master_model');
   /*  $check = $this->master_model->check_login();   
      if ($check == 0) {
         redirect('login/logout');                             
      }*/                 
    }      
//consignor    
public function consignor(){   
  if(isset($_POST['submit_form'])){ 
  $id = $_POST['id'];     
  if(!empty($id)){
  $data = [
  'customer_code' => $this->input->post('customer_code'),  
  'customer_name' => $this->input->post('customer_name'),
  'mobile_no'     => $this->input->post('mobile_no'),
  'contact_person'=> $this->input->post('contact_person'),
  'owner_name'    => $this->input->post('owner_name'),
  'gst_no'        => $this->input->post('gst_no'),
  'email_id'      => $this->input->post('email_id'),  
  'address'       => $this->input->post('address'), 
  'alternate_no'  => $this->input->post('alternate_no'), 
  'updated_at'    => date('Y-m-d H-i-s'),    
  ];
  $result  = $this->master_model->update('m_consignor_details',$data,array('id'=>$id));      
  }else{ 
  //generate staff id
        $new_count     = $this->db->query('SELECT customer_code FROM m_consignor_details');
        if ($new_count->num_rows() > 0){
          $new_query  = $this->db->query('SELECT MAX(customer_code) AS customer_code FROM m_consignor_details');
          $new_result = $new_query->row();
          $dd         = $new_result->customer_code + 1;
        }else{
          $dd  = '11';                      
        }   
  $data = [
  'customer_code' => $dd,  
  'customer_name' => $this->input->post('customer_name'),
  'mobile_no'     => $this->input->post('mobile_no'),
  'contact_person'=> $this->input->post('contact_person'),
  'owner_name'    => $this->input->post('owner_name'),
  'gst_no'        => $this->input->post('gst_no'),
  'email_id'      => $this->input->post('email_id'),  
  'address'       => $this->input->post('address'),
  'alternate_no'  => $this->input->post('alternate_no'),   
  'created_at'    => date('Y-m-d H-i-s'),
  ];  
  $result = $this->master_model->insert('m_consignor_details',$data);
  }
  $this->session->set_flashdata('success_message', $result);
  redirect('master/consignor');     
}    
$data['controller_name']  = 'master';          
$data['view']             = 'master/dashboard';
$data['page_name']        = '/consignor'; 
$data['customer_code']    = $this->master_model->get_customer_code();
$data['info_one']             = $this->master_model->get_single_data('settings_details',array('id' => '1'));
$data['info']             = $this->master_model->fetch('m_consignor_details');
$this->load->view("/gd_logistics/master/dashboard",$data);   
}    
//lorry_owner            
public function lorry_owner(){      
  if(isset($_POST['submit_form'])){    
  $id = $_POST['id'];           
  if(!empty($id)){
    if(!empty($_FILES['insurance_pdf']['name'])){
           $file_to_upload = 'insurance_pdf';
           $upload_folder  = 'insurance_pdf';
           $filename       = strtolower(str_replace(" ","_",$id.'_'.$file_to_upload));
           $upload_folder  = 'insurance_pdf';
           $filetypes      = '*';
           $insurance_pdf  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);  
        }
        if(!empty($insurance_pdf)){
          $data = array('insurance_pdf'=>$insurance_pdf);
          $this->master_model->update('m_lorry_owner_details',$data, array('id'=>$id));
        }  
        if(!empty($_FILES['fitnes_pdf']['name'])){
           $file_to_upload = 'fitnes_pdf';
           $upload_folder  = 'fitnes_pdf';
           $filename       = strtolower(str_replace(" ","_",$id.'_'.$file_to_upload));
           $upload_folder  = 'fitnes_pdf';
           $filetypes      = '*';
           $fitnes_pdf  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);  
        }
        if(!empty($fitnes_pdf)){
          $data = array('fitnes_pdf'=>$fitnes_pdf);
          $this->master_model->update('m_lorry_owner_details',$data, array('id'=>$id));
        }
        if(!empty($_FILES['pancard_pdf']['name'])){
           $file_to_upload = 'pancard_pdf';
           $upload_folder  = 'pancard_pdf';
           $filename       = strtolower(str_replace(" ","_",$id.'_'.$file_to_upload));
           $upload_folder  = 'pancard_pdf';
           $filetypes      = '*';
           $pancard_pdf  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);  
        }
        if(!empty($pancard_pdf)){
          $data = array('pancard_pdf'=>$pancard_pdf);
          $this->master_model->update('m_lorry_owner_details',$data, array('id'=>$id)); 
        } 
         if(!empty($_FILES['aadhar_pdf']['name'])){
           $file_to_upload = 'aadhar_pdf';   
           $upload_folder  = 'aadhar_pdf';
           $filename       = strtolower(str_replace(" ","_",$id.'_'.$file_to_upload));
           $upload_folder  = 'aadhar_pdf';
           $filetypes      = '*';
           $aadhar_pdf  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);  
        }
        if(!empty($aadhar_pdf)){
          $data = array('aadhar_pdf'=>$aadhar_pdf);
          $this->master_model->update('m_lorry_owner_details',$data, array('id'=>$id));
        } 
        
  $data['lorry_no'] = $this->input->post('lorry_no', true);
  $data['chesis_no'] = $this->input->post('chesis_no',true);
  $data['insurance_no'] = $this->input->post('insurance_no',true);
  $data['expiry_date'] = $this->input->post('expiry_date',true);
  $data['engine_no'] = $this->input->post('engine_no',true);
  $data['fitness_expire_date'] = $this->input->post('fitness_expire_date',true);
  $data['fitness_no'] = $this->input->post('fitness_no',true);
  $data['owner_name'] = $this->input->post('owner_name',true);
  $data['owner_no'] = $this->input->post('owner_no',true);
  $data['address'] = $this->input->post('address',true);
  $data['alternate_no']=$this->input->post('alternate_no',true);
  $data['pan_no'] = $this->input->post('pan_no',true);
  $data['aadhar_no'] = $this->input->post('aadhar_no',true);
  $data['rc'] = $this->input->post('rc',true);
  $data['permit'] = $this->input->post('permit',true); 

  $result  = $this->master_model->update('m_lorry_owner_details',$data,array('id'=>$id)); 
  }else{   
     if(!empty($_FILES['insurance_pdf']['name'])){
           $id = $_POST['id'];
           $file_to_upload = 'insurance_pdf';
           // $upload_folder  = 'insurance_pdf';
           $filename       = strtolower(str_replace(" ","_",$id.'_'.$file_to_upload));
           $upload_folder  = 'insurance_pdf';
           $filetypes      = '*';
           $insurance_pdf  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);  
           $data['insurance_pdf'] = $insurance_pdf;
        } 
        if(!empty($_FILES['fitnes_pdf']['name'])){    
           $id = $_POST['id'];
           $file_to_upload = 'fitnes_pdf';
           // $upload_folder  = 'fitnes_pdf';
           $filename       = strtolower(str_replace(" ","_",$id.'_'.$file_to_upload));
           $upload_folder  = 'fitnes_pdf';
           $filetypes      = '*';
           $fitnes_pdf  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);  
           $data['fitnes_pdf'] = $fitnes_pdf;
        }   
        if(!empty($_FILES['pancard_pdf']['name'])){    
           $id = $_POST['id'];
           $file_to_upload = 'pancard_pdf';
           $filename       = strtolower(str_replace(" ","_",$id.'_'.$file_to_upload));
           $upload_folder  = 'pancard_pdf';
           $filetypes      = '*';
           $pancard_pdf  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);  
           $data['pancard_pdf'] = $pancard_pdf;
        } 
        if(!empty($_FILES['aadhar_pdf']['name'])){    
           $id = $_POST['id'];
           $file_to_upload = 'aadhar_pdf';   
           $filename       = strtolower(str_replace(" ","_",$id.'_'.$file_to_upload));
           $upload_folder  = 'aadhar_pdf';
           $filetypes      = '*';
           $aadhar_pdf  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);  
           $data['aadhar_pdf'] = $aadhar_pdf;
        }    
  $data['lorry_no'] = $this->input->post('lorry_no', true);
  $data['chesis_no'] = $this->input->post('chesis_no',true);
  $data['insurance_no'] = $this->input->post('insurance_no',true);
  $data['expiry_date'] = $this->input->post('expiry_date',true);
  $data['engine_no'] = $this->input->post('engine_no',true); 
  $data['fitness_expire_date'] = $this->input->post('fitness_expire_date',true);
  $data['fitness_no'] = $this->input->post('fitness_no',true);
  $data['owner_name'] = $this->input->post('owner_name',true);
  $data['owner_no'] = $this->input->post('owner_no',true);
  $data['address'] = $this->input->post('address',true);
  $data['alternate_no']=$this->input->post('alternate_no',true);
  $data['pan_no'] = $this->input->post('pan_no',true);
  $data['aadhar_no'] = $this->input->post('aadhar_no',true); 
  $data['rc'] = $this->input->post('rc',true);
  $data['permit'] = $this->input->post('permit',true); 
  $result = $this->master_model->insert('m_lorry_owner_details',$data);
  }
  $this->session->set_flashdata('success_message', $result);
  redirect('master/lorry_owner');   
}  
$data['controller_name']  = 'master';          
$data['view']             = 'master/dashboard';   
$data['page_name']        = '/lorry_owner'; 
$data['info_one']             = $this->master_model->get_single_data('settings_details',array('id' => '1'));
$data['info']             = $this->master_model->fetch('m_lorry_owner_details');
$this->load->view("/gd_logistics/master/dashboard",$data);         
}  
//broker        
public function broker(){   
  if(isset($_POST['submit_form'])){
  $id = $_POST['id'];    
  if(!empty($id)){
  $data['broker_code']   = $this->input->post('broker_code');
  $data['broker_name']   = $this->input->post('broker_name');
  $data['state_name'] = $this->input->post('state_name');
  $data['mobile_no'] = $this->input->post('mobile_no');
  $data['alt_mobile_no'] = $this->input->post('alt_mobile_no');
  $data['contact_person'] = $this->input->post('contact_person');
  $data['lorry_type'] = $this->input->post('lorry_type');
  $data['address'] = $this->input->post('address');
  $data['bank_name'] = $this->input->post('bank_name');
  $data['account_no'] = $this->input->post('account_no');
  $data['ifsc_code'] = $this->input->post('ifsc_code');
  $man = explode(',',$data['state_name']);           
  $i=0;
  foreach($man as $key){
    $man[$i++] = "_".$key."_";    
  }
  $mi = implode(',',$man);     
   //print_r($mi);
   //exit;  
  $data['state_name']=$mi;
  $data['updated_at'] = date('Y-m-d H-i-s');
  $result  = $this->master_model->update('m_broker_details',$data,array('id'=>$id));
  }else{
 
    //generate staff id
    $new_count     = $this->db->query('SELECT broker_code FROM m_broker_details');
    if ($new_count->num_rows() > 0){
      $new_query  = $this->db->query('SELECT MAX(broker_code) AS broker_code FROM m_broker_details');
      $new_result = $new_query->row();
      $dd         = $new_result->broker_code + 1;
    }else{
      $dd  = '11';                      
    }   
  $data['broker_code'] = $dd;
  $data['state_name'] = $this->input->post('state_name'); 
  $data['broker_name'] = $this->input->post('broker_name');
  $data['mobile_no'] = $this->input->post('mobile_no');
  $data['alt_mobile_no'] = $this->input->post('alt_mobile_no');
  $data['contact_person'] = $this->input->post('contact_person');
  $data['lorry_type'] = $this->input->post('lorry_type');
  $data['address'] = $this->input->post('address');
  $data['bank_name'] = $this->input->post('bank_name');
  $data['account_no'] = $this->input->post('account_no');
  $data['ifsc_code'] = $this->input->post('ifsc_code');  
 
  $man = explode(',',$data['state_name']);         
  $i=0;
  foreach($man as $key){
    $man[$i++] = "_".$key."_";   
  }
  $mi = implode(',',$man);      
   //print_r($mi);
   //exit;
  $data['state_name']=$mi;
  $data['created_at'] = date('Y-m-d H-i-s');  
  $result = $this->master_model->insert('m_broker_details',$data);  
  }     
  $this->session->set_flashdata('success_message', $result);
  redirect('master/broker');     
}  
$data['controller_name']  = 'master';         
$data['view']             = 'master/dashboard';
$data['broker_code']      = $this->master_model->get_broker_code();
$data['page_name']        = '/broker';  
$data['info_one']             = $this->master_model->get_single_data('settings_details',array('id' => '1'));
$data['info']             = $this->master_model->fetch('m_broker_details');
$data['state']            = $this->master_model->fetch_data('state');
$this->load->view("/gd_logistics/master/dashboard",$data);   
}  
//consignee    
public function consignee(){   
  if(isset($_POST['submit_form'])){ 
  $id = $_POST['id'];     
  if(!empty($id)){
  $data = [
  'customer_code' => $this->input->post('customer_code'),
  'company_name' => $this->input->post('company_name'),
  'mobile_no'     => $this->input->post('mobile_no'),
  'contact_person'=> $this->input->post('contact_person'),
  'owner_name'    => $this->input->post('owner_name'),
  'gst_no'        => $this->input->post('gst_no'),
  'email_id'      => $this->input->post('email_id'),  
  'address'       => $this->input->post('address'), 
  'alternate_no'  => $this->input->post('alternate_no'), 
  'updated_at'    => date('Y-m-d H-i-s'),    
  ];
  $result  = $this->master_model->update('m_consignee_details',$data,array('id'=>$id));      
  }else{ 
  //generate staff id
        $new_count     = $this->db->query('SELECT customer_code FROM m_consignee_details');
        if ($new_count->num_rows() > 0){
          $new_query  = $this->db->query('SELECT MAX(customer_code) AS customer_code FROM m_consignee_details');
          $new_result = $new_query->row();
          $dd         = $new_result->customer_code + 1; 
        }else{
          $dd  = '11';                      
        }   
  $data = [
  'customer_code' => $dd,  
  'company_name' => $this->input->post('company_name'),
  'mobile_no'     => $this->input->post('mobile_no'),
  'contact_person'=> $this->input->post('contact_person'),
  'owner_name'    => $this->input->post('owner_name'),
  'gst_no'        => $this->input->post('gst_no'),
  'email_id'      => $this->input->post('email_id'),  
  'address'       => $this->input->post('address'),
  'alternate_no'  => $this->input->post('alternate_no'),   
  'created_at'    => date('Y-m-d H-i-s'),  
  ];  
  $result = $this->master_model->insert('m_consignee_details',$data);
  }
  $this->session->set_flashdata('success_message', $result);
  redirect('master/consignee');     
}    
$data['controller_name']  = 'master';          
$data['view']             = 'master/dashboard';
$data['page_name']        = '/consignee'; 
$data['info_one']             = $this->master_model->get_single_data('settings_details',array('id' => '1'));
$data['customer_code']    = $this->master_model->get_consignee_code();
$data['logo']             = $this->my_model->get_single_data('settings_details',array('id' => '1'));
$data['info']             = $this->master_model->fetch('m_consignee_details');
$this->load->view("/gd_logistics/master/dashboard",$data);   
} 

    
}
?>