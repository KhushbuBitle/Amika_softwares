<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Challan extends MY_Controller{
  public function __construct() {
    parent::__construct();
    //LOAD ALL REQUIRED MODEL 
    $this->load->model('Challan_model', 'challan_model');
    /*$check = $this->staff_model->check_login();   
    if ($check == 0) {
       redirect('login/logout');                                         
    } */      
  }
    public function index(){
      $data['controller_name']  = 'challan'; 
      $data['view']             = 'lorry_challan/dashboard';
      $data['page_name']        = '/add_lorry_challan';
      $this->load->view("gd_logistics/lorry_challan/dashboard",$data);  
    }     
   
  
}
?>