<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Staff extends MY_Controller{
  public function __construct() {
    parent::__construct();
    //LOAD ALL REQUIRED MODEL 
    $this->load->model('staff_model', 'staff_model');
    /*$check = $this->staff_model->check_login();   
    if ($check == 0) {
       redirect('login/logout');                          
    } */      
  }
    public function index(){
      $data['controller_name']  = 'staff'; 
      $data['view']             = 'staff/dashboard';
      $data['page_name']        = '/staff';
      $data['logo']             = $this->my_model->get_single_data('settings_details',array('id' => '1'));
      $data['info']             = $this->staff_model->fetch('staff_details');
      $this->load->view("gd_logistics/staff/dashboard",$data);  
    }  
    //add_staff 
    public function add_staff(){
    if(isset($_POST['submit_form'])){ 
          $staff_id             = $_POST['staff_id']; 
    //generate staff id
    $new_count     = $this->db->query('SELECT staff_id FROM staff_details');
    if ($new_count->num_rows() > 0){
      $new_query  = $this->db->query('SELECT MAX(staff_id) AS staff_id FROM staff_details');
      $new_result = $new_query->row();
      $dd= $new_result->staff_id + 1;
    }else{
      $dd= '10001';
    }
      $data['staff_id']       = $dd;                       
      $data['first_name']      =$this->input->post('first_name', true);
      $data['middle_name']    =$this->input->post('middle_name', true);
      $data['last_name']      =$this->input->post('last_name', true);
      $data['mobile_no']      =$this->input->post('mobile_no', true);
      $data['email']          =$this->input->post('email', true);
      $data['gender']         =$this->input->post('gender', true);
      $data['aadhar_no']      =$this->input->post('aadhar_no', true);
      $data['address']        =$this->input->post('address', true);
      $data['created_at']     =date('Y-m-d H-i-s');   
      //profile_pic 
      if(!empty($_FILES['profile_pic']['name'])){
        $xyz_staff_id = $_POST['id']; 
        $file_to_upload = 'profile_pic';
        $filename = strtolower(str_replace(" ","_",$xyz_staff_id.'_'.$file_to_upload));
        $upload_folder = 'staff_profile_pic';
        $filetypes = '*';
        $profile_pic = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);
        $data['profile_pic'] = $profile_pic;          
      }  
      if ($this->db->insert('staff_details',$data)){
        $user_id    = $dd;
        $first_name = $this->input->post('first_name'); 
        $last_name  = $this->input->post('last_name');
        $mobile_no  = $this->input->post('mobile_no'); 
        $username   = $this->input->post('mobile_no');   
        $user_role  = 'staff';  
        $user_data  = array(
          'user_id'    => $user_id,
          'first_name' => $first_name,  
          'last_name'  => $last_name,
          'mobile_no'  => $mobile_no,
          'username'   => $username,
          'password'   => $this->password_generation($username),
          'user_role'  => $user_role,
        );
        if ($this->db->insert('users',$user_data)){
           redirect('staff');
                return "Staff Successfully Registered!";
            }else{
                return "Staff Created but username create to failed!";
            }
        }else{
            return "Data Insert To Failed!";
        }
      }
        $data['controller_name']  = 'staff'; 
        $data['logo']             = $this->my_model->get_single_data('settings_details',array('id' => '1'));
        $data['view']             = 'staff/dashboard';
        $data['page_name']        = '/add_staff';
        $this->load->view("gd_logistics/staff/dashboard",$data);
    } 
  //password_generation
  public function password_generation($username){
    $password = password_hash($username, PASSWORD_DEFAULT);
    return $password;
    }  
  //edit_staff  
  public function edit_staff(){
        $id                        = $this->uri->segment(3);
        $data['controller_name']   = 'staff';
        $data['view']              = 'staff/dashboard';
        $data['logo']              = $this->my_model->get_single_data('settings_details',array('id' => '1'));
        $data['info']              = $this->staff_model->get_single_data('staff_details', array('id' => $id));
        $data['page_name']         = '/edit_staff';
        $this->load->view("/gd_logistics/staff/dashboard",$data); 
    } 
    //update_staff
  public function update_staff(){
      $id                     = $this->uri->segment(3);
      $data['first_name']     =$this->input->post('first_name', true);
      $data['middle_name']    =$this->input->post('middle_name', true);
      $data['last_name']      =$this->input->post('last_name', true);
      $data['mobile_no']      =$this->input->post('mobile_no', true);
      $data['email']          =$this->input->post('email', true);
      $data['gender']         =$this->input->post('gender', true);
      $data['aadhar_no']      =$this->input->post('aadhar_no', true);
      $data['address']        =$this->input->post('address', true);
      $data['updated_at']     =date('Y-m-d H-i-s');  
         //profile_pic
         $xyz_staff_id               = $_POST['id'];
         if(!empty($_FILES['profile_pic']['name'])){
           $file_to_upload = 'profile_pic';
           $upload_folder  = 'profile_pic';
           $filename       = strtolower(str_replace(" ","_",$xyz_staff_id.'_'.$file_to_upload));
           $upload_folder  = 'staff_profile_pic';
           $filetypes      = '*';
           $profile_pic  = $this->my_model->upload_file($file_to_upload, $filename, $upload_folder, $filetypes);     
         }
         if(!empty($profile_pic)){
           $data = array('profile_pic'=>$profile_pic);
           $this->staff_model->update('staff_details',$data, array('id'=>$xyz_staff_id));
         }
         $result = $this->staff_model->update('staff_details',$data,array('id'=>$id));
         $this->session->set_flashdata('success_message', $result);
         redirect('staff');   
    }  
    //delete_staff
    public function delete_staff(){
      $data = array(
        'is_deleted' => 9,
    );
      $staff_id    = $this->uri->segment(3);
      $user_id    = $this->uri->segment(3);
      $result     = $this->staff_model->delete('staff_details', array('staff_id'=>$staff_id),$data);
      $result     = $this->staff_model->delete('users', array('user_id'=>$user_id, 'user_role'=>'staff'),$data);
      $this->session->set_flashdata('success_message', $result);
      redirect('staff');
  } 
  //view_staff   
  public function view_staff(){
        $id                        = $this->uri->segment(3);
        $data['controller_name']   = 'staff';
        $data['view']              = 'staff/dashboard';
        $data['logo']              = $this->my_model->get_single_data('settings_details',array('id' => '1'));
        $data['info']              = $this->staff_model->get_single_data('staff_details', array('id' => $id));
        $data['page_name']         = '/view_staff';
        $this->load->view("/gd_logistics/staff/dashboard",$data); 
    }    
  
}
?>