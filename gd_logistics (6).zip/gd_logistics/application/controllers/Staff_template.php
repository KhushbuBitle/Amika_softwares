<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Staff_template extends MY_Controller{
  public function __construct() {
    parent::__construct();
    //LOAD ALL REQUIRED MODEL
    $this->load->model('Staff_template_model', 'staff_template_model');
    $check = $this->staff_template_model->check_login();
        if ($check == 0) {
            redirect('login/logout');    
        }    
    }
    //index
    public function index(){
      $data['controller_name']  = 'staff_template';
      $data['view']             = 'staff_template/dashboard';
      $data['page_name']        = '/body';
      $this->load->view("gd_logistics/staff_template/dashboard",$data);
    }
}
?>
