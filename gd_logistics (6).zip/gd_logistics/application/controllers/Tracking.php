  <?php defined('BASEPATH') OR exit('No direct script access allowed');
  class Tracking extends MY_Controller{  
    public function __construct() {
      parent::__construct();
      //LOAD ALL REQUIRED MODEL 
      // $this->load->model('Tracking_model','tracking_model');
      /*$check = $this->staff_model->check_login();       
      if ($check == 0) {
        redirect('login/logout');                                      
      } */      
    }
      //index  
      public function index(){
          $data['controller_name']  = 'tracking';  
          $data['view']             = 'template/track_consignment';
          $data['page_name']        = '/track_consignment';
          $data['logo']             = $this->my_model->get_single_data('settings_details',array('id' => '1')); 
          $this->load->view("gd_logistics/template/track_consignment",$data);       
        }  
        //consignment_report 
      public function consignment_report(){
        $name                     = $_GET['name'];   
        $data['controller_name']  = 'tracking';
        $data['view']             = 'template/consignment_report';  
        $data['page_name']        = '/consignment_report';
        //$data['report']           = $this->admin_model->one_name_client('consignment_update_details',$name);
        $data['report']           = $this->db->query("SELECT * From consignment_update_details Where vs_code like '".$name."'")->result();
        $this->load->view("gd_logistics/template/consignment_report",$data);   
      }  
    
  }
  ?>