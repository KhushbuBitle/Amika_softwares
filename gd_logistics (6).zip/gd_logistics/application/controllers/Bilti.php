<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Bilti extends MY_Controller{  
  public function __construct() {
    parent::__construct();
    //LOAD ALL REQUIRED MODEL 
    $this->load->model('Bilti_model', 'bilti_model');
    /*$check = $this->staff_model->check_login();
    if ($check == 0) {
       redirect('login/logout');                           
    } */      
  }
    public function add_bilti(){
      $data['controller_name']  = 'bilti';  
      $data['view']             = 'bilti/dashboard';
      $data['page_name']        = '/add_bilti';
      // $data['logo']             = $this->my_model->get_single_data('settings_details',array('id' => '1'));
      $this->load->view("/gd_logistics/bilti/dashboard",$data);   
    }    
     
  
}
?>