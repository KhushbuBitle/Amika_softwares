<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class MY_Controller extends CI_Controller {
    public function __construct() {
        ob_start();
        parent::__construct();
        error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
        $this->load->model('MY_Model', 'my_model');
        if (isset($_SERVER['HTTPS'])) {
            $protocol = "https://";
        } else {
            $protocol = "http://";  
        } 
    }
    // get_single_data    
    public function get_single_data(){
      $id=$this->uri->segment(3);
      $table_name=$this->uri->segment(4);
      $result=$this->my_model->get_single_data($table_name,array('id'=>$id));
      echo json_encode($result);
    }
    //get_client_data
    public function get_client_data(){
        $mobile_no = $_POST['mobile_no'];
        $type = $_POST['type'];
        $table_name = 'client_details';
        if($type == 'mobile_no'){
            $column_name = 'mobile_no';     
            $id = $mobile_no ;
        }
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result); 
    } 
    // delete_data
    public function delete_data(){  
        $data = array(
          'is_deleted' => 9,
        );
        $id=$this->uri->segment(3);  
        $table_name=$this->uri->segment(4);
        $result=$this->my_model->delete($table_name,array('id'=>$id),$data);
        echo json_encode($result);
      }   
     public function seees($tbl,$id){
        $data= $this->db->query("SELECT  * FROM `$tbl` WHERE `id`='".$id."' ");
        foreach ($data->result() as $row1)
        {
            return $msetting=$row1->name;
        } 
    }  
    public function seees_customer_name($tbl,$id){
      $data= $this->db->query("SELECT  * FROM `$tbl` WHERE `id`='".$id."' ");
      foreach ($data->result() as $row1)
      {
          return $msetting=$row1->customer_name; 
      } 
  }
  public function seees_consignee_name($tbl,$id){
    $data= $this->db->query("SELECT  * FROM `$tbl` WHERE `id`='".$id."' ");
    foreach ($data->result() as $row1)
    {
        return $msetting=$row1->company_name; 
    } 
}
  public function seees_vs_code($tbl,$id){
    $data= $this->db->query("SELECT  * FROM `$tbl` WHERE `id`='".$id."' ");
    foreach ($data->result() as $row1)
    {
        return $msetting=$row1->vs_code; 
    } 
}
  public function seees_owner_name($tbl,$id){
    $data= $this->db->query("SELECT  * FROM `$tbl` WHERE `id`='".$id."' ");
    foreach ($data->result() as $row1)
    {
        return $msetting=$row1->owner_name; 
    } 
}
  public function seees_broker_name($tbl,$id){
    $data= $this->db->query("SELECT  * FROM `$tbl` WHERE `id`='".$id."' ");
    foreach ($data->result() as $row1)
    {
        return $msetting=$row1->broker_name; 
    } 
}
  public function get_consignor_data(){
        $id = $_POST['id'];
        $table_name = 'm_consignor_details';
        $column_name = 'id';
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result);
    } 
    public function get_consignee_data(){
        $id = $_POST['id'];
        $table_name = 'm_consignee_details';
        $column_name = 'id';
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result); 
    }    
    //get_lorry_owner_data       
    public function get_lorry_owner_data(){
        $lorry_no = $_POST['lorry_no'];
        $type = $_POST['type'];
        $table_name = 'm_lorry_owner_details';  
        if($type == 'lorry_no'){
            $column_name = 'lorry_no';       
            $id = $lorry_no ; 
        }
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result);   
    }
    //get_bilti_data   
    public function get_bilti_data(){ 
        $vs_code = $_POST['vs_code'];
        $type = $_POST['type'];
        $table_name = 'bilti_details';   
        if($type == 'vs_code'){
            $column_name = 'vs_code';     
            $id = $vs_code ; 
        }
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result);   
    }
     //get_bilti_data_payment   
     public function get_bilti_data_payment(){ 
        $vs_code = $_POST['vs_code'];
        $type = $_POST['type'];
        $table_name = 'bilti_details';   
        if($type == 'vs_code'){
            $column_name = 'vs_code';     
            $id = $vs_code ; 
        }
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result);   
    }
     //get_invoice_bill_data   
     public function get_invoice_bill_data(){ 
        $bill_no = $_POST['bill_no'];
        $type = $_POST['type'];
        $table_name = 'invoice_details';    
        if($type == 'bill_no'){
            $column_name = 'bill_no';     
            $id = $bill_no ; 
        }
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result);   
    }
     //get_invoice_data_payment   
     public function get_invoice_data_payment(){ 
        $vs_code = $_POST['vs_code'];
        $type = $_POST['type'];
        $table_name = 'invoice_details';   
        if($type == 'vs_code'){
            $column_name = 'vs_code';     
            $id = $vs_code ; 
        }
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result);   
    }
    //get_broker_data 
     public function get_broker_data(){
        $id = $_POST['id'];
        $table_name = 'm_broker_details';
        $column_name = 'id';
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result);
    } 
    //get_consignor_owner_data 
     public function get_consignor_owner_data(){
        $id = $_POST['id'];
        $as = explode("/", $id);
        $id = $as[0];
        $table_name = $as[1];
        $column_name = 'id';
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result); 
    }   
    //get_bilti_consignment_data   
    public function get_bilti_consignment_data(){
        $vs_code = $_POST['vs_code'];
        $type = $_POST['type'];
        $table_name = 'bilti_details';   
        if($type == 'vs_code'){
            $column_name = 'vs_code';     
            $id = $vs_code ; 
        }
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result);    
    } 
   //get_bilti_consignment_data_one    
    public function get_bilti_consignment_data_one(){
        $vs_code_one = $_POST['vs_code_one'];
        $type = $_POST['type'];
        $table_name = 'bilti_details';   
        if($type == 'vs_code_one'){
            $column_name = 'vs_code';      
            $id = $vs_code_one ;  
        }
        $result=$this->my_model->get_single_data($table_name,array($column_name=>$id));
        echo json_encode($result);    
    }  

    


     
    
  }
?>