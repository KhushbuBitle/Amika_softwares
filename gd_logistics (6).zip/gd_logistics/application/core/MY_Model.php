<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MY_Model extends CI_Model {
    public function __construct() {
        $this->bilti = "bilti_details";
        parent::__construct();
        $this->load->dbutil();
        $this->load->helper('file');
        $this->load->helper('download');
        $this->load->library('upload');
        $this->upload_path = $this->config->item('upload_folder');
    }  
    // insert 
    public function insert($table,$data_array){
        $data= $this->db->insert($table, $data_array);
        if($data != ''){
          return "Data Inserted Successfully!" ;
        }else{
           return "Data Not Inserted Successfully!" ;
        }   
    }    
    // update  
    public function update($table,$data_array,$condition=''){
        $this->db->where($condition);
        $data=  $this->db->update($table, $data_array);
        if($data != ''){
          return "Data Updated Successfully!" ;
        }else{
           return "Data Not Updated Successfully!" ;
        }
    }  
    // get_data_arr
    public function get_data_arr($table,$field='',$condition='',$group='',$order='',$limit='',$result=''){
        if($field != '')
        $this->db->select($field);
        if($condition != '')
        $this->db->where($condition);
        if($order != '')
        $this->db->order_by($order);
        if($limit != '')
        $this->db->limit($limit);
        if($group != '')
        $this->db->group_by($group);
        if($result != '')
        {
            $return =  $this->db->get($table)->row_array();
        }else{
            $return =  $this->db->get($table)->result_array();
        }
        return $return;
    }
    //where_get_num_rows
    public function where_get_num_rows($where, $table)
    {
        return $this->db->where($where)->get($table)->num_rows();
    }
    //where_get_result
    public function where_get_result($where, $table)
    {
        return $this->db->where($where)->get($table)->result();
    }
    //get table data
    public function fetch($tbl)
    {
        $test=$this->db->where('is_deleted !=',9)
        ->get($tbl);
        return $test->result();
    }  
    //get table data 
    public function fetch_one($tbl)
    {
        $where = array('is_deleted !='=>9,'status !='=>8);
        $test= $this->db->where($where) 

        ->get($tbl);
        return $test->result();
    }  
    //get table data from another table
    public function fetch_data($tbl)
    {
        $test=$this->db
        ->where('is_deleted !=',9)
        ->get($tbl);
        return $test->result_array();   
    }  

        
    // delete   
    // public function delete_old($table,$condition=''){
    //     if($condition != '')
    //     $this->db->where($condition);
    //     if($this->db->delete($table)){
    //         return "Deleted Successfully!" ;
    //     }else{
    //         return "Deletion Failed!" ;
    //     }
    // }     
    // delete   
    public function delete($table,$condition='',$data){
        if($condition != '')
        $this->db->where($condition);
        if($this->db->update($table,$data)){
            return "Deleted Successfully!" ;
        }else{
            return "Deletion Failed!";    
        }    
    }  
    // get_single_data
    public function get_single_data($tablename,$condition){
        $this->db->where($condition);
        return $this->db->get($tablename)->row();
    }
    // get_multiple_data
    public function get_multiple_data($tablename,$condition){
        $this->db->where($condition);
        return $this->db->get($tablename)->result_array();
    }
    //check_privious_password
    public function check_privious_password($password_new, $username) {
        $this->db->select('password');
        $this->db->from('users');
        $this->db->where('username', $username);
        $query = $this->db->get();
        $result = $query->row();
        $hashpassword = $result->password;
        if (password_verify($password_new, $hashpassword)) {
            // $this->info($username);
            return 0;
        } else {
            return 1;
        }
    }
    //force_change_password
    public function force_change_password($username, $password, $first_login) {
        $data = array('password' => password_hash($password, PASSWORD_DEFAULT), 'first_login' => $first_login,);
        return $this->db->where('username', $username)->update('users', $data);
    }
    // upload_file
    public function upload_file($file_to_upload,$filename,$upload_folder,$filetypes) {
        $path = $_SERVER['DOCUMENT_ROOT'] .'/'. $this->upload_path.'/'.$upload_folder;
        if (!is_dir($path)) {
            mkdir($path, 0777, TRUE);
        }
        $ext = pathinfo($_FILES[$file_to_upload]['name'], PATHINFO_EXTENSION);
        $config['file_name'] = str_replace(' ', '', $filename).'_'.mt_rand(1000, 1000000).'.'.$ext;
        $config['upload_path'] = $_SERVER['DOCUMENT_ROOT'] .'/'. $this->upload_path.'/'.$upload_folder.'';
        $config['allowed_types'] = $filetypes;
        $config['file_ext_tolower'] = TRUE;
        $config['max_size'] = '80960';
        $this->upload->initialize($config);
        if($this->upload->do_upload($file_to_upload)){
            return $config['file_name'];
        }else{
            return '';
        }   
    }
    //get_user
    public function get_user($data,$tbl){
        // print_r($data); exit;
        $test= $this->db
        ->where($data)
        ->get($tbl)->result();
                    //   print_r($this->db->last_query()); exit;
        return $test;                     
    }
    //order_by_name
    public function order_by_name($tbl,$conds,$col,$dir){
    $test = $this->db->where($conds)
    ->group_by($col,$dir)
    ->get($tbl);
    return $test->result();    
    }  
    public function fetch_($tbl){
        $test=$this->db
        // ->where('is_deleted',0)
        // ->where('is_active',1)
        ->get($tbl);
        return $test->result();
    }
    public function editupdate($data,$tbl,$id){
        $this->db->where('id',$id);
        $data = $this->db->update($tbl,$data);
        if($data){
            return true;
        }else{
            return false;
        }
    }
}